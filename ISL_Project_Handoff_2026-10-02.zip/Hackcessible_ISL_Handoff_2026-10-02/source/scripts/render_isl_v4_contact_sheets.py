"""Render fixed-set skeleton comparisons as static images for quick visual review.

Each panel overlays one reference frame (blue) and the corresponding
text-conditioned prediction (orange). Hand/body topology colors are consistent
across clips. The coordinate limits are shared across every condition and frame
of a clip so a prediction cannot look animated only because of autoscaling.

Usage:
    python scripts/render_isl_v4_contact_sheets.py artifacts/V4/manifest_minilm_position_motion.json \
        --edges artifacts/V4/skeleton_edges.npy --out-dir artifacts/V4/contact_sheets
"""

from __future__ import annotations

import argparse
import json
import textwrap
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def resolve(base: Path, value: str) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else (base / path).resolve()


def load_pose(base: Path, spec: str | dict) -> np.ndarray:
    if isinstance(spec, str):
        path, key = resolve(base, spec), None
    else:
        path, key = resolve(base, spec["path"]), spec.get("key", spec.get("pose_key"))
    loaded = np.load(path, allow_pickle=False)
    if isinstance(loaded, np.lib.npyio.NpzFile):
        with loaded as archive:
            if key is None:
                key = "pose" if "pose" in archive.files else archive.files[0]
            pose = archive[key].copy()
    else:
        pose = loaded
    pose = np.asarray(pose, dtype=np.float32)
    if pose.ndim == 2 and pose.shape[-1] % 3 == 0:
        pose = pose.reshape(pose.shape[0], -1, 3)
    if pose.ndim != 3 or pose.shape[-1] < 2 or not np.isfinite(pose).all():
        raise ValueError(f"Expected finite (frames, points, coords>=2) array, got {pose.shape} at {path}")
    return pose


def load_confidence(base: Path, spec: str | dict, pose_shape: tuple[int, ...]) -> np.ndarray:
    if isinstance(spec, str):
        return np.ones(pose_shape[:2], dtype=np.float32)
    path = resolve(base, spec["path"])
    key = spec.get("confidence_key")
    loaded = np.load(path, allow_pickle=False)
    if not isinstance(loaded, np.lib.npyio.NpzFile):
        return np.ones(pose_shape[:2], dtype=np.float32)
    with loaded as archive:
        key = key or ("confidence" if "confidence" in archive.files else None)
        if key is None or key not in archive.files:
            return np.ones(pose_shape[:2], dtype=np.float32)
        confidence = np.asarray(archive[key], dtype=np.float32).copy()
    if confidence.ndim == 3 and confidence.shape[-1] == 1:
        confidence = confidence[..., 0]
    if confidence.shape != pose_shape[:2] or not np.isfinite(confidence).all():
        raise ValueError(f"Reference confidence shape mismatch for {path}: {confidence.shape} vs {pose_shape[:2]}")
    return np.clip(confidence, 0.0, 1.0)


def edge_group(a: int, b: int) -> str:
    if a < 33 and b < 33:
        return "body"
    if 33 <= a < 54 and 33 <= b < 54:
        return "left hand"
    if 54 <= a < 75 and 54 <= b < 75:
        return "right hand"
    return "cross-group"


def draw_pose(ax, pose: np.ndarray, frame: int, edges: np.ndarray, color: str,
              shared_limits: tuple[float, float, float, float], alpha: float,
              linestyle: str, confidence: np.ndarray) -> None:
    group_colors = {"body": color, "left hand": color, "right hand": color, "cross-group": color}
    xy = pose[frame, :, :2]
    for a, b in edges:
        if max(int(a), int(b)) >= len(xy):
            continue
        if confidence[frame, a] < 0.15 or confidence[frame, b] < 0.15:
            continue
        ax.plot(xy[[a, b], 0], xy[[a, b], 1], color=group_colors[edge_group(int(a), int(b))],
                alpha=alpha, linewidth=0.65, linestyle=linestyle, solid_capstyle="round")
    visible = confidence[frame] >= 0.15
    ax.scatter(xy[visible, 0], xy[visible, 1], s=2.0, c=color, alpha=alpha, linewidths=0)
    xmin, xmax, ymin, ymax = shared_limits
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymax, ymin)  # MediaPipe image coordinates increase downward.
    ax.set_aspect("equal", adjustable="box")
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)


def build(manifest_path: Path, edges_path: Path, out_dir: Path) -> list[Path]:
    manifest_path = manifest_path.resolve()
    base = manifest_path.parent
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    samples_by_uid = {str(row["uid"]): row for row in manifest.get("samples", [])}
    fixed_uids = [str(uid) for uid in manifest.get("fixed_unseen_set", {}).get("uids", [])]
    if not fixed_uids:
        raise ValueError("Manifest has no fixed_unseen_set.uids")
    missing = [uid for uid in fixed_uids if uid not in samples_by_uid]
    if missing:
        raise ValueError(f"Fixed set samples missing from manifest: {missing}")
    edges = np.asarray(np.load(edges_path, allow_pickle=False), dtype=np.int64)
    if edges.ndim != 2 or edges.shape[1] != 2:
        raise ValueError(f"Expected skeleton edges shaped (E,2), got {edges.shape}")
    frame_indices = [0, 12, 24, 36, 47]
    colors = {"reference": "#2271b2", "true_text": "#d95f02", "shuffled_text": "#7b3294"}
    loaded_samples = []
    for uid in fixed_uids:
        row = samples_by_uid[uid]
        ref = load_pose(base, row["reference"])
        confidence = load_confidence(base, row["reference"], ref.shape)
        true = load_pose(base, row["predictions"]["true_text"])
        shuffled = load_pose(base, row["predictions"]["shuffled_text"])
        if ref.shape != true.shape or ref.shape != shuffled.shape:
            raise ValueError(f"Shape mismatch for {uid}: reference={ref.shape}, true={true.shape}, shuffled={shuffled.shape}")
        if max(frame_indices) >= ref.shape[0] or edges.size and int(edges.max()) >= ref.shape[1]:
            raise ValueError(f"Frame/topology outside sequence for {uid}: shape={ref.shape}, edges={edges.shape}")
        loaded_samples.append((uid, row.get("text", ""), ref, true, shuffled, confidence))

    out_dir.mkdir(parents=True, exist_ok=True)
    outputs = []
    for condition, prediction_index in (("true_text", 3), ("shuffled_text", 4)):
        fig, axes = plt.subplots(len(loaded_samples), len(frame_indices), figsize=(10.2, 1.55 * len(loaded_samples)),
                                 squeeze=False, facecolor="white")
        fig.subplots_adjust(left=0.285, right=0.995, top=0.965, bottom=0.025, hspace=0.18, wspace=0.015)
        for column, frame in enumerate(frame_indices):
            axes[0, column].set_title(f"Frame {frame + 1}/48", fontsize=8, pad=5)
        for row_index, (uid, sentence, reference, true, shuffled, confidence) in enumerate(loaded_samples):
            prediction = (true, shuffled)[condition == "shuffled_text"]
            stack = np.concatenate([reference[:, :, :2], true[:, :, :2], shuffled[:, :, :2]], axis=0)
            xlo, ylo = np.percentile(stack, 1, axis=(0, 1))
            xhi, yhi = np.percentile(stack, 99, axis=(0, 1))
            pad_x = max((xhi - xlo) * 0.08, 1e-3)
            pad_y = max((yhi - ylo) * 0.08, 1e-3)
            limits = (float(xlo - pad_x), float(xhi + pad_x), float(ylo - pad_y), float(yhi + pad_y))
            label = f"{uid}\n" + "\n".join(textwrap.wrap(str(sentence), width=40)[:2])
            axes[row_index, 0].text(-0.08, 0.5, label, transform=axes[row_index, 0].transAxes,
                                    ha="right", va="center", fontsize=5.6, color="#222222", clip_on=False)
            for column, frame in enumerate(frame_indices):
                ax = axes[row_index, column]
                draw_pose(ax, reference, frame, edges, colors["reference"], limits, 0.9, "-", confidence)
                draw_pose(ax, prediction, frame, edges, colors[condition], limits, 0.82, "--", confidence)
                ax.set_facecolor("#fbfbfb")
        fig.suptitle(f"V4 fixed cohort · {condition.replace('_', ' ')} predictions\nBlue = reference · {colors[condition]} = prediction · shared per-clip scale",
                     fontsize=10, y=0.995)
        out_path = out_dir / f"{condition}_overlay.png"
        fig.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="white")
        plt.close(fig)
        outputs.append(out_path)
    return outputs


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--edges", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    outputs = build(args.manifest, args.edges, args.out_dir)
    print("\n".join(str(path.resolve()) for path in outputs))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
