"""Confidence-guarded canonicalization for iSign V3's compact body+hands pose.

This module is copied verbatim into the standalone Kaggle notebook by
`build_isl_v3_notebook.py`. It avoids accepting missing/low-confidence points
as anchors and reports a stable anchor mode or an explicit exclusion reason.
"""

from __future__ import annotations

import numpy as np

POINT_INDICES = np.asarray(list(range(33)) + list(range(501, 543)), dtype=np.int64)
TMAX, POINTS = 48, 75
ANCHOR_INDICES = {"nose": 0, "left_shoulder": 11, "right_shoulder": 12,
                  "left_hip": 23, "right_hip": 24}


def canonicalize_one(raw_pose, raw_confidence, min_anchor_conf=0.15):
    raw_pose = np.asarray(raw_pose, dtype=np.float32)
    raw_confidence = np.asarray(raw_confidence, dtype=np.float32)
    if raw_pose.ndim != 3 or raw_pose.shape[1:] != (576, 3):
        return None, None, {"reason": f"invalid_pose_shape:{tuple(raw_pose.shape)}"}
    if raw_confidence.shape != raw_pose.shape[:2]:
        return None, None, {"reason": f"invalid_confidence_shape:{tuple(raw_confidence.shape)}"}
    if raw_pose.shape[0] < 2:
        return None, None, {"reason": f"too_few_pose_frames:{raw_pose.shape[0]}"}

    valid_coords = np.isfinite(raw_pose).all(axis=-1)
    safe_pose = np.nan_to_num(raw_pose, nan=0.0, posinf=0.0, neginf=0.0)
    point_conf = np.clip(np.nan_to_num(raw_confidence, nan=0.0, posinf=0.0, neginf=0.0), 0.0, 1.0)
    confident = {
        name: (point_conf[:, index] >= float(min_anchor_conf)) & valid_coords[:, index]
        for name, index in ANCHOR_INDICES.items()
    }

    nose, left_shoulder, right_shoulder = (
        safe_pose[:, 0, :], safe_pose[:, 11, :], safe_pose[:, 12, :]
    )
    shoulder_center = (left_shoulder + right_shoulder) * 0.5
    shoulder_width = np.linalg.norm(left_shoulder[:, :2] - right_shoulder[:, :2], axis=-1)
    nose_scale = np.linalg.norm(nose[:, :2] - shoulder_center[:, :2], axis=-1)
    hips_center = (safe_pose[:, 23, :] + safe_pose[:, 24, :]) * 0.5
    hip_width = np.linalg.norm(safe_pose[:, 23, :2] - safe_pose[:, 24, :2], axis=-1)
    eps = 1e-4

    shoulder_pair = confident["left_shoulder"] & confident["right_shoulder"]
    primary = confident["nose"] & shoulder_pair & np.isfinite(nose_scale) & (nose_scale > eps)
    shoulder_mode = shoulder_pair & np.isfinite(shoulder_width) & (shoulder_width > eps)

    left_nose_scale = np.linalg.norm(nose[:, :2] - left_shoulder[:, :2], axis=-1)
    right_nose_scale = np.linalg.norm(nose[:, :2] - right_shoulder[:, :2], axis=-1)
    nose_left_mode = confident["nose"] & confident["left_shoulder"] & np.isfinite(left_nose_scale) & (left_nose_scale > eps)
    nose_right_mode = confident["nose"] & confident["right_shoulder"] & np.isfinite(right_nose_scale) & (right_nose_scale > eps)
    hip_mode = confident["left_hip"] & confident["right_hip"] & np.isfinite(hip_width) & (hip_width > eps)

    available = {
        "nose_shoulders": int(primary.sum()),
        "shoulder_width": int(shoulder_mode.sum()),
        "nose_left_shoulder": int(nose_left_mode.sum()),
        "nose_right_shoulder": int(nose_right_mode.sum()),
        "hip_width": int(hip_mode.sum()),
    }
    finite_anchor_counts = {name: int(valid_coords[:, idx].sum()) for name, idx in ANCHOR_INDICES.items()}
    confident_anchor_counts = {name: int(confident[name].sum()) for name in ANCHOR_INDICES}
    details = {
        "threshold": float(min_anchor_conf),
        "finite_anchor_counts": finite_anchor_counts,
        "confident_anchor_counts": confident_anchor_counts,
        "primary_scale_valid_count": available["nose_shoulders"],
        "available_anchor_frame_counts": available,
    }

    if available["nose_shoulders"] >= 2:
        mode = "nose_shoulders"
        anchor_ok = primary | shoulder_mode
        direct = primary
        center = shoulder_center
        scale = np.where(primary, nose_scale, shoulder_width * 0.5)
    elif available["shoulder_width"] >= 2:
        mode = "shoulder_width"
        anchor_ok = shoulder_mode
        direct = np.zeros(raw_pose.shape[0], dtype=bool)
        center = shoulder_center
        scale = shoulder_width * 0.5
    elif max(available["nose_left_shoulder"], available["nose_right_shoulder"]) >= 2:
        # Keep one shoulder side for the whole clip so the anchor center cannot
        # jump laterally when left/right confidence alternates frame to frame.
        side = "left" if available["nose_left_shoulder"] >= available["nose_right_shoulder"] else "right"
        if side == "left":
            mode, anchor_ok, center, scale = "nose_left_shoulder", nose_left_mode, left_shoulder, left_nose_scale
        else:
            mode, anchor_ok, center, scale = "nose_right_shoulder", nose_right_mode, right_shoulder, right_nose_scale
        direct = np.zeros(raw_pose.shape[0], dtype=bool)
    elif available["hip_width"] >= 2:
        mode = "hip_width"
        anchor_ok = hip_mode
        direct = np.zeros(raw_pose.shape[0], dtype=bool)
        center = hips_center
        scale = hip_width * 0.5
    else:
        details.update({
            "anchor_mode": None,
            "direct_anchor_frames": 0,
            "fallback_anchor_frames": 0,
            "interpolated_anchor_frames": int(raw_pose.shape[0]),
            "total_anchor_frames": 0,
            "reason": "fewer_than_two_frames_with_any_consistent_confident_anchor_mode",
        })
        return None, None, details

    anchor_ok &= np.isfinite(scale) & (scale > eps) & np.isfinite(center).all(axis=-1)
    good = np.flatnonzero(anchor_ok)
    if len(good) < 2:
        details.update({
            "anchor_mode": mode,
            "direct_anchor_frames": int((anchor_ok & direct).sum()),
            "fallback_anchor_frames": int((anchor_ok & ~direct).sum()),
            "interpolated_anchor_frames": int(raw_pose.shape[0] - len(good)),
            "total_anchor_frames": int(len(good)),
            "reason": "selected_anchor_mode_has_fewer_than_two_valid_frames",
        })
        return None, None, details

    frame_ix = np.arange(raw_pose.shape[0])
    center_interp = np.stack([np.interp(frame_ix, good, center[good, axis]) for axis in range(3)], axis=-1)
    scale_interp = np.exp(np.interp(frame_ix, good, np.log(scale[good].clip(eps))))
    reliability = np.full(raw_pose.shape[0], 0.5, dtype=np.float32)
    reliability[anchor_ok & direct] = 1.0
    reliability[anchor_ok & ~direct] = 0.75

    selected_pose = safe_pose[:, POINT_INDICES, :].copy()
    selected_conf = point_conf[:, POINT_INDICES].copy() * valid_coords[:, POINT_INDICES]
    canonical = (selected_pose - center_interp[:, None, :]) / scale_interp[:, None, None]
    selected_conf *= reliability[:, None]
    canonical = np.nan_to_num(canonical, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
    details.update({
        "anchor_mode": mode,
        "direct_anchor_frames": int((anchor_ok & direct).sum()),
        "fallback_anchor_frames": int((anchor_ok & ~direct).sum()),
        "interpolated_anchor_frames": int(raw_pose.shape[0] - len(good)),
        "total_anchor_frames": int(len(good)),
        "median_scale": float(np.median(scale[good])),
        "reason": None,
    })
    return canonical, selected_conf.astype(np.float32), details
