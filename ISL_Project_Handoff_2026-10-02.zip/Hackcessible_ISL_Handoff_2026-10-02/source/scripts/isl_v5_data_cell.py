# Freeze a source-disjoint fresh test and load only the selected pose files.
from collections import OrderedDict

SEED, V2_LIMIT, FRESH_TRAIN_TARGET, FRESH_TEST_TARGET = 17, 2048, 8000, 500
FRESH_MIN_COVERAGE = 0.98
TMAX, LMAX, BATCH = 48, 40, 32
MAX_EPOCHS, PATIENCE, VELOCITY_WEIGHT = 30, 6, 0.05
RUN_KEY_EXPECTED = '711ff3100b0f'

class HttpRangeFile:
    BLOCK = 1024 * 1024
    def __init__(self, url, token, size, session, max_blocks=96):
        self.url, self.token, self.size, self.pos, self.session = url, token, size, 0, session
        self.cache, self.max_blocks = OrderedDict(), int(max_blocks)
    def seekable(self): return True
    def readable(self): return True
    def tell(self): return self.pos
    def seek(self, offset, whence=0):
        pos = offset if whence == 0 else (self.pos + offset if whence == 1 else self.size + offset if whence == 2 else None)
        if pos is None or pos < 0: raise ValueError('Invalid ZIP seek.')
        self.pos = pos; return pos
    def _block(self, index):
        if index not in self.cache:
            start = index * self.BLOCK; end = min(start + self.BLOCK, self.size) - 1
            response = self.session.get(self.url, headers={'Authorization': f'Bearer {self.token}', 'Range': f'bytes={start}-{end}', 'Accept-Encoding': 'identity'}, allow_redirects=True, stream=True, timeout=(30, 120))
            if response.status_code != 206:
                status = response.status_code; response.close()
                raise RuntimeError(f'Range request returned HTTP {status}; refusing a full-shard download.')
            data = b''.join(response.iter_content(chunk_size=256 * 1024)); response.close()
            if len(data) != end - start + 1: raise RuntimeError(f'Short ZIP range: wanted {end-start+1} bytes, got {len(data)}.')
            self.cache[index] = data
            while len(self.cache) > self.max_blocks: self.cache.popitem(last=False)
        self.cache.move_to_end(index)
        return self.cache[index]
    def read(self, size=-1):
        if size is None or size < 0: size = self.size - self.pos
        size = min(size, max(0, self.size - self.pos)); result = bytearray()
        while size:
            index, offset = divmod(self.pos, self.BLOCK); block = self._block(index)
            take = min(size, len(block) - offset); result.extend(block[offset:offset+take]); self.pos += take; size -= take
        return bytes(result)

class ConcatRangeFile:
    def __init__(self, files):
        self.files = files; self.sizes = [item.size for item in files]; self.starts = []; total = 0
        for size in self.sizes: self.starts.append(total); total += size
        self.size, self.pos = total, 0
    def seekable(self): return True
    def tell(self): return self.pos
    def seek(self, offset, whence=0):
        pos = offset if whence == 0 else (self.pos + offset if whence == 1 else self.size + offset if whence == 2 else None)
        if pos is None or pos < 0: raise ValueError('Invalid concatenated ZIP seek.')
        self.pos = pos; return pos
    def read(self, size=-1):
        if size is None or size < 0: size = self.size - self.pos
        size = min(size, max(0, self.size - self.pos)); result = bytearray()
        while size:
            i = max(j for j, start in enumerate(self.starts) if start <= self.pos)
            local = self.pos - self.starts[i]; take = min(size, self.sizes[i] - local)
            self.files[i].seek(local); result.extend(self.files[i].read(take)); self.pos += take; size -= take
        return bytes(result)

range_session = requests.Session()
range_files = [HttpRangeFile(hf_hub_url(REPO_ID, name, repo_type='dataset', revision=repo_info.sha), HF_TOKEN, file_sizes[name], range_session) for name in POSE_PARTS]
archive = ConcatRangeFile(range_files)
with zipfile.ZipFile(archive, 'r') as zf:
    pose_names = [name for name in zf.namelist() if name.lower().endswith('.pose')]
pose_by_file = {Path(name).name: name for name in pose_names}
print('Official pose archive members:', len(pose_names), '| ranged-read LRU:', 96, 'MiB per shard.')

def source_group_from_uid(uid):
    """Conservative iSign source ID parser; returns (source_id, rule, valid)."""
    uid = str(uid).strip()
    match = re.fullmatch(r'(?P<core>.+)--(?P<seq>\d+)', uid)
    if match:
        core = match.group('core')
        return (core, 'inferred_youtube11_double_dash_sequence', True) if len(core) == 11 and re.fullmatch(r'[A-Za-z0-9_-]{11}', core) else (None, 'invalid_double_dash_core', False)
    match = re.fullmatch(r'(?P<core>.+)-(?P<seq>\d+)', uid)
    if match:
        core = match.group('core')
        return (core, 'documented_hex12_id-sequence', True) if len(core) == 12 and re.fullmatch(r'[0-9a-fA-F]{12}', core) else (None, 'invalid_hex12_sequence_core', False)
    match = re.fullmatch(r'(?P<core>.+)_e(?P<seq>\d+)', uid)
    if match:
        core = match.group('core')
        return (core, 'inferred_def_example_suffix', True) if len(core) == 11 and re.fullmatch(r'[A-Za-z0-9_-]{11}', core) else (None, 'invalid_example_core', False)
    match = re.fullmatch(r'(?P<core>.+)_d', uid)
    if match:
        core = match.group('core')
        return (core, 'inferred_def_description_suffix', True) if len(core) == 11 and re.fullmatch(r'[A-Za-z0-9_-]{11}', core) else (None, 'invalid_description_core', False)
    # `_w` may be part of an 11-character YouTube ID, so it is never stripped.
    if len(uid) == 11 and re.fullmatch(r'[A-Za-z0-9_-]{11}', uid):
        return uid, 'bare_youtube_id', True
    if len(uid) == 12 and re.fullmatch(r'[0-9a-fA-F]{12}', uid):
        return uid, 'bare_hex12_id', True
    return None, 'unsupported_uid_source_id_grammar', False

def conservative_source_aliases(uid, source_id=None):
    """Keep whole UIDs and every length-validated plausible source core reserved."""
    uid = str(uid).strip(); aliases = {uid}
    if source_id is not None and str(source_id).strip(): aliases.add(str(source_id).strip())
    parsed, _, valid = source_group_from_uid(uid)
    if valid:
        aliases.add(parsed)
        # For id--N, the official generic id-N grammar also admits the
        # literal 12-character source candidate id-. Reserve it as an alias
        # without asserting that it is the authoritative source ID.
        if re.fullmatch(r'.+--\d+', uid) and len(parsed) == 11:
            aliases.add(parsed + '-')
    # Unsupported 11-character-core-N rows are not eligible primary IDs, but
    # reserve their plausible core when protecting the legacy V2 roster.
    single_dash = re.fullmatch(r'(?P<core>.+)-\d+', uid)
    if single_dash:
        core = single_dash.group('core')
        if len(core) == 11 and re.fullmatch(r'[A-Za-z0-9_-]{11}', core):
            aliases.add(core)
    match = re.fullmatch(r'(?P<core>.+)_e\d+', uid) or re.fullmatch(r'(?P<core>.+)_d', uid)
    if match and len(match.group('core')) == 11 and re.fullmatch(r'[A-Za-z0-9_-]{11}', match.group('core')):
        aliases.add(match.group('core'))
    # `_w` is ambiguous; reserve a stripped alias only when its source ID validates.
    if uid.endswith('_w'):
        candidate = uid[:-2]
        if (len(candidate) == 11 and re.fullmatch(r'[A-Za-z0-9_-]{11}', candidate)) or (len(candidate) == 12 and re.fullmatch(r'[0-9a-fA-F]{12}', candidate)):
            aliases.add(candidate)
    return aliases

_uid_parser_examples = {}  # Example dataset identifiers omitted from this archive copy.
for _uid, _expected in _uid_parser_examples.items():
    _actual, _rule, _valid = source_group_from_uid(_uid)
    assert _valid and _actual == _expected, (_uid, _actual, _rule)
print('UID parser examples passed:', _uid_parser_examples)

metadata = metadata.copy()
assert {'uid', 'text'}.issubset(metadata.columns), f'Official CSV columns changed: {list(metadata.columns)}'
metadata['uid'] = metadata['uid'].astype(str).str.strip()
metadata['text'] = metadata['text'].fillna('').astype(str).str.strip()
if metadata['uid'].duplicated().any():
    raise RuntimeError(f'Official metadata contains {int(metadata.uid.duplicated().sum())} duplicate UIDs; refusing ambiguous joins.')

source_parse = [source_group_from_uid(uid) for uid in metadata['uid']]
metadata['parsed_source_video_id'] = [item[0] for item in source_parse]
metadata['source_uid_rule'] = [item[1] for item in source_parse]
metadata['source_uid_supported'] = [item[2] for item in source_parse]
if 'video_id' in metadata.columns:
    metadata['source_video_id'] = metadata['video_id'].fillna('').astype(str).str.strip()
    metadata['source_video_id_provenance'] = 'official_csv_video_id'
    metadata['source_uid_mismatch'] = metadata['source_uid_supported'] & (metadata['parsed_source_video_id'] != metadata['source_video_id'])
    metadata['source_uid_supported'] = metadata['source_video_id'].ne('')
    metadata.loc[metadata['source_uid_supported'], 'source_uid_rule'] = 'official_csv_video_id'
else:
    metadata['source_video_id'] = metadata['parsed_source_video_id']
    metadata['source_video_id_provenance'] = 'uid_suffix_parser_v1'
    metadata['source_uid_mismatch'] = False
if metadata['source_video_id'].fillna('').eq('').any():
    metadata.loc[metadata['source_video_id'].fillna('').eq(''), 'source_uid_supported'] = False
if metadata['source_uid_mismatch'].any():
    mismatch_examples = metadata.loc[metadata['source_uid_mismatch'], ['uid','parsed_source_video_id','source_video_id']].head(10).to_dict(orient='records')
    print('Explicit official video_id overrides UID inference after conflict audit; mismatch rows:', int(metadata['source_uid_mismatch'].sum()), '| examples:', mismatch_examples)

token_pattern = re.compile(r"[a-z0-9]+(?:'[a-z0-9]+)?", re.IGNORECASE)
def text_key(text): return ' '.join(token_pattern.findall(str(text).lower()))

eligible = metadata.copy()
eligible = eligible[eligible['text'].str.split().str.len().between(3, LMAX)]
eligible = eligible[~eligible['text'].str.match(r'(?i)^(page|unit|chapter)\s+\d+\s*$')]
eligible = eligible[eligible['uid'].map(lambda uid: uid + '.pose' in pose_by_file)].copy()
eligible['text_key'] = eligible['text'].map(text_key)
eligible['source_video_id'] = eligible['source_video_id'].fillna('').astype(str)

# Reproduce the old V2 sampled roster exactly, including its historical grouping rule.
v2_candidates = eligible.copy()
v2_candidates['legacy_video_id'] = v2_candidates['uid'].str.replace(r'-\d+$', '', regex=True)
v2_candidates = v2_candidates.drop_duplicates('legacy_video_id').reset_index(drop=True)
if len(v2_candidates) < V2_LIMIT:
    raise RuntimeError(f'Only {len(v2_candidates)} legacy V2 candidates are available; need {V2_LIMIT}.')
selected_v2 = v2_candidates.sample(n=V2_LIMIT, random_state=SEED).reset_index(drop=True)
run_key = hashlib.sha256('|'.join(selected_v2['uid']).encode()).hexdigest()[:12]
assert run_key == RUN_KEY_EXPECTED, f'V2 roster hash changed: {run_key} != {RUN_KEY_EXPECTED}'
selected_v2['source_video_id'] = [
    str(source_id) if supported and str(source_id).strip() else 'unresolved_uid:' + str(uid)
    for source_id, supported, uid in zip(selected_v2['source_video_id'], selected_v2['source_uid_supported'], selected_v2['uid'])
]
selected_v2['source_aliases'] = [
    sorted(conservative_source_aliases(uid, source_id))
    for uid, source_id in zip(selected_v2['uid'], selected_v2['source_video_id'])
]
required_v2_columns={'uid','text','text_key','source_video_id','source_uid_rule','source_uid_supported','source_aliases'}
assert required_v2_columns.issubset(selected_v2.columns), f'Legacy V2 roster is missing required audit columns: {sorted(required_v2_columns-set(selected_v2.columns))}'
assert selected_v2['source_aliases'].map(bool).all(), 'Every V2 UID must have at least one reserved source alias.'

cache_candidates = list(Path('/kaggle/input').rglob('isign_pose_cache_' + run_key))
assert cache_candidates, 'Attach the verified Hackcessible iSign Pose Cache V2 dataset.'
CACHE_DIR = cache_candidates[0]
cached_paths = list(CACHE_DIR.rglob('*.npz'))
cached_by_uid = {path.stem: path for path in cached_paths}
selected_v2_uids = set(selected_v2['uid'])
assert len(cached_by_uid) == 2046 and set(cached_by_uid).issubset(selected_v2_uids), 'V2 cache must be the verified exact 2,046-file roster.'
old_source_ids = set(selected_v2['source_video_id'])
old_text_keys = set(selected_v2['text_key'])
old_source_aliases = set().union(*(set(row.source_aliases) for row in selected_v2.itertuples()))
old_uid_to_row = selected_v2.set_index('uid').to_dict(orient='index')
print('Official CSV shape/columns:', metadata.shape, list(metadata.columns))
print('Source ID provenance:', metadata['source_video_id_provenance'].iloc[0], '| UID parse families:', metadata['source_uid_rule'].value_counts().to_dict())
print('Unsupported metadata UIDs quarantined:', int((~metadata['source_uid_supported']).sum()), '| V2 source groups reserved:', len(old_source_ids), '| V2 captions reserved:', len(old_text_keys))
print('Exact V2 roster:', len(selected_v2), '| V2 cache:', len(cached_by_uid), '| run key:', run_key)

# Select test first: one caption per source, unique captions, and no source/text overlap with any V2 row.
if 'video_id' in metadata.columns:
    test_family_mask = eligible['source_uid_supported']
else:
    test_family_mask = eligible['source_uid_rule'].isin({'inferred_youtube11_double_dash_sequence','documented_hex12_id-sequence'})
fresh_candidates = eligible[eligible['source_uid_supported'] & test_family_mask & ~eligible['text_key'].isin(old_text_keys)].copy()
fresh_candidates['test_rank'] = [hashlib.sha256(f'{SEED}:fresh-test:{row.source_video_id}:{row.uid}'.encode()).hexdigest() for row in fresh_candidates.itertuples()]
fresh_candidates = fresh_candidates.sort_values(['test_rank', 'uid'], kind='mergesort')
fresh_test_rows, test_sources, test_texts, test_source_aliases = [], set(), set(), set()
for record in fresh_candidates.to_dict(orient='records'):
    source_id, caption = record['source_video_id'], record['text_key']
    aliases = conservative_source_aliases(record['uid'], source_id)
    if aliases & old_source_aliases or aliases & test_source_aliases or source_id in test_sources or caption in test_texts:
        continue
    record['source_aliases'] = sorted(aliases)
    fresh_test_rows.append(record); test_sources.add(source_id); test_texts.add(caption); test_source_aliases.update(aliases)
    if len(fresh_test_rows) == FRESH_TEST_TARGET: break
if len(fresh_test_rows) != FRESH_TEST_TARGET:
    raise RuntimeError(f'Only {len(fresh_test_rows)} fresh source/caption-disjoint test rows exist; need {FRESH_TEST_TARGET}.')

# Pick 8,000 fresh train clips after freezing test groups. Round-robin across source videos, max 8 clips/source.
train_candidates = eligible[
    eligible['source_uid_supported']
    & ~eligible['text_key'].isin(old_text_keys | test_texts)
].copy()
train_candidates = train_candidates[
    train_candidates.apply(lambda row: not (conservative_source_aliases(row['uid'], row['source_video_id']) & (old_source_aliases | test_source_aliases)), axis=1)
].copy()
by_source = defaultdict(list)
for record in train_candidates.to_dict(orient='records'):
    record['source_aliases'] = sorted(conservative_source_aliases(record['uid'], record['source_video_id']))
    by_source[record['source_video_id']].append(record)
source_order = sorted(by_source, key=lambda source: (hashlib.sha256(f'{SEED}:fresh-train-source:{source}'.encode()).hexdigest(), source))
for source in source_order:
    by_source[source].sort(key=lambda record: (hashlib.sha256(f'{SEED}:fresh-train-uid:{record["uid"]}'.encode()).hexdigest(), record['uid']))
fresh_train_rows = []
for depth in range(8):
    for source in source_order:
        if depth < len(by_source[source]):
            fresh_train_rows.append(by_source[source][depth])
            if len(fresh_train_rows) == FRESH_TRAIN_TARGET: break
    if len(fresh_train_rows) == FRESH_TRAIN_TARGET: break
if len(fresh_train_rows) != FRESH_TRAIN_TARGET:
    raise RuntimeError(f'Only {len(fresh_train_rows)} fresh source-disjoint train rows are available under the 8/source cap; need {FRESH_TRAIN_TARGET}.')
fresh_train_sources = {record['source_video_id'] for record in fresh_train_rows}
fresh_train_texts = {record['text_key'] for record in fresh_train_rows}
fresh_train_aliases = set().union(*(set(record['source_aliases']) for record in fresh_train_rows))
assert not (old_source_aliases & test_source_aliases or old_source_aliases & fresh_train_aliases or fresh_train_aliases & test_source_aliases)
assert not (old_text_keys & test_texts or fresh_train_texts & test_texts)
assert len({record['uid'] for record in fresh_train_rows}) == FRESH_TRAIN_TARGET
print('Fresh selection:', len(fresh_train_rows), 'train /', len(fresh_test_rows), 'test | sources:', len(fresh_train_sources), '/', len(test_sources))
print('Selection audit: source overlap old/train/test = 0; exact normalized caption overlap old/train/test = 0')
predecode_test_uids=sorted(str(record['uid']) for record in fresh_test_rows)
fixed_uids=sorted(predecode_test_uids,key=lambda uid:(hashlib.sha256(f'{SEED}:{uid}'.encode()).hexdigest(),uid))[:12]

# Persist the immutable selected roster before any network decoding. Decode failures
# are recorded against these rows; selections are never silently replaced.
def selection_record(record):
    aliases=record.get('source_aliases')
    if not isinstance(aliases,(list,tuple,set,np.ndarray)) or not len(aliases):
        aliases=conservative_source_aliases(record['uid'],record.get('source_video_id'))
    if not aliases:
        raise RuntimeError(f"Selected UID lacks conservative source aliases: {record.get('uid')}")
    return {'uid':str(record['uid']),'source_video_id':str(record['source_video_id']),'source_aliases':sorted({str(value) for value in aliases}),'source_uid_rule':str(record.get('source_uid_rule','unknown')),'text':str(record['text']),'normalized_caption_key':str(record['text_key'])}
PREDECODE_SELECTION_PATH=Path('/kaggle/working/isl_v5_selection_manifest_predecode.json')
PREDECODE_SELECTION_PATH.write_text(json.dumps({'seed':SEED,'v2_run_key':run_key,'fresh_test_rule':'primary UID families only when official video_id is absent; candidate aliases and normalized captions disjoint; deterministic UID hash rank','fresh_train_rule':'source/caption disjoint from reserved V2 and fresh test; deterministic source/UID hash order; max 8 clips per source','minimum_fresh_coverage':FRESH_MIN_COVERAGE,'fixed_unseen_set':{'selection_rule':'sha256_rank_by_uid','uids':fixed_uids},'selected_v2':[selection_record(record) for record in selected_v2.to_dict(orient='records')],'fresh_train':[selection_record(record) for record in fresh_train_rows],'fresh_test':[selection_record(record) for record in fresh_test_rows]},indent=2))
print('Persisted fixed selection roster before decoding:',PREDECODE_SELECTION_PATH,'| rows:',V2_LIMIT+FRESH_TRAIN_TARGET+FRESH_TEST_TARGET)

def decode_member(zf, uid):
    pose = Pose.read(zf.read(pose_by_file[uid + '.pose']))
    data = np.asarray(pose.body.data, dtype=np.float32)
    conf = np.asarray(pose.body.confidence, dtype=np.float32)
    if data.ndim == 4 and conf.ndim == 3:
        if data.shape[1] != conf.shape[1]: raise ValueError('person_axis')
        person = int(np.nanmean(conf, axis=(0, 2)).argmax()); data = data[:, person]; conf = conf[:, person]
    elif data.ndim == 4 and data.shape[1] == 1:
        data = data[:, 0]
        if conf.ndim == 3: conf = conf[:, 0]
    if data.ndim != 3 or conf.ndim != 2 or data.shape[0] < 2 or data.shape[-1] != 3 or data.shape[-2] != 576:
        raise ValueError('shape')
    if conf.shape != data.shape[:2]: raise ValueError('confidence_shape')
    t = data.shape[0]; positions = np.linspace(0.0, 1.0, TMAX, dtype=np.float32); q = positions * (t - 1)
    lo = np.floor(q).astype(np.int64); hi = np.minimum(lo + 1, t - 1); blend = (q - lo)[:, None]
    flat = np.nan_to_num(data.reshape(t, -1), nan=0.0, posinf=0.0, neginf=0.0)
    confidence = np.clip(np.nan_to_num(conf, nan=0.0, posinf=0.0, neginf=0.0), 0.0, 1.0)
    return (flat[lo] * (1.0 - blend) + flat[hi] * blend).astype(np.float32), (confidence[lo] * (1.0 - blend) + confidence[hi] * blend).astype(np.float32), int(t)

working_cache = Path('/kaggle/working/isign_pose_cache_v5'); working_cache.mkdir(parents=True, exist_ok=True)
original_train_records = []
original_test_records = []
load_exclusions = []
rows_loaded, pose_paths = [], []
for record in selected_v2.to_dict(orient='records'):
    enriched = dict(record); enriched['split_source'] = 'v2_reservoir'; enriched['source_uid_rule'] = str(record['source_uid_rule'])
    original_train_records.append(enriched)
for record in fresh_train_rows: original_train_records.append({**record, 'split_source': 'fresh_train'})
for record in fresh_test_rows: original_test_records.append({**record, 'split_source': 'fresh_test'})

def exclusion_record(record, side, reason):
    return {'uid': str(record['uid']), 'source_video_id': str(record['source_video_id']), 'source_aliases': sorted(conservative_source_aliases(record['uid'], record.get('source_video_id'))), 'text': str(record['text']), 'original_split': side,
            'anchor_mode': 'unavailable_before_canonicalization', 'threshold': 0.15,
            'finite_anchor_counts': {'nose': 0, 'left_shoulder': 0, 'right_shoulder': 0},
            'confident_anchor_counts': {'nose': 0, 'left_shoulder': 0, 'right_shoulder': 0},
            'primary_scale_valid_count': 0, 'direct_anchor_frames': 0, 'fallback_anchor_frames': 0,
            'interpolated_anchor_frames': 0, 'unresolved_anchor_frames': TMAX, 'total_anchor_frames': 0,
            'resampled_frame_count': TMAX, 'reason': reason}

for record in selected_v2.to_dict(orient='records'):
    if record['uid'] not in cached_by_uid:
        load_exclusions.append(exclusion_record(record, 'train', 'selected_v2_pose_missing_from_verified_cache'))
        continue
    path = cached_by_uid[record['uid']]
    try:
        with np.load(path) as saved:
            if np.asarray(saved['pose']).shape != (TMAX, 1728) or np.asarray(saved['confidence']).shape != (TMAX, 576): raise ValueError('cached_shape')
            raw_count = int(saved['raw_frame_count']) if 'raw_frame_count' in saved else None
    except Exception as exc:
        load_exclusions.append(exclusion_record(record, 'train', 'selected_v2_cache_error:' + type(exc).__name__))
        continue
    rows_loaded.append({**record, 'source_aliases': sorted(conservative_source_aliases(record['uid'], record['source_video_id'])), 'raw_frame_count': raw_count, 'resampling_policy': 'uniform_linear_48_endpoints_included; original_count_unavailable_in_v2_cache', 'split_source': 'v2_reservoir'})
    pose_paths.append(path)

fresh_decode_rows = [
    *[{**record, 'split_source': 'fresh_train'} for record in fresh_train_rows],
    *[{**record, 'split_source': 'fresh_test'} for record in fresh_test_rows],
]
decode_session = requests.Session()
decode_errors = Counter(); range_decodes = 0; reused_v5_cache = 0; transient_retry_attempts = 0
def decode_member_with_retry(zf, uid, max_attempts=3):
    global transient_retry_attempts
    for attempt in range(1,max_attempts+1):
        try: return decode_member(zf,uid)
        except Exception as exc:
            message=str(exc)
            transient=isinstance(exc,(requests.RequestException,TimeoutError,ConnectionError)) or any(f'HTTP {status}' in message for status in (429,500,502,503,504))
            if not transient or attempt==max_attempts: raise
            transient_retry_attempts+=1
            wait_seconds=min(2**(attempt-1),4)
            print(f'Transient pose-range failure for {uid}; retry {attempt+1}/{max_attempts} in {wait_seconds}s: {type(exc).__name__}',flush=True)
            time.sleep(wait_seconds)
with zipfile.ZipFile(archive, 'r') as zf:
    fresh_decode_rows.sort(key=lambda row: (zf.getinfo(pose_by_file[row['uid'] + '.pose']).header_offset, row['uid']))
    for n, record in enumerate(fresh_decode_rows, start=1):
        uid = str(record['uid']); side = 'train' if record['split_source'] == 'fresh_train' else 'validation'
        cache_path = working_cache / (uid + '.npz')
        try:
            if cache_path.exists():
                with np.load(cache_path) as saved:
                    flat = np.asarray(saved['pose'], dtype=np.float32).copy(); conf = np.asarray(saved['confidence'], dtype=np.float32).copy()
                    raw_count = int(saved['raw_frame_count'])
                if flat.shape != (TMAX, 1728) or conf.shape != (TMAX, 576): raise ValueError('working_cache_shape')
                reused_v5_cache += 1
            else:
                flat, conf, raw_count = decode_member_with_retry(zf, uid)
                tmp = cache_path.with_suffix('.npz.tmp')
                with open(tmp, 'wb') as handle: np.savez_compressed(handle, pose=flat, confidence=conf, raw_frame_count=np.asarray(raw_count))
                tmp.replace(cache_path); range_decodes += 1
            rows_loaded.append({**record, 'raw_frame_count': raw_count, 'resampling_policy': 'uniform_linear_48_endpoints_included', 'split_source': 'fresh_train' if side == 'train' else 'fresh_test'})
            pose_paths.append(cache_path)
        except Exception as exc:
            decode_errors[type(exc).__name__ + ':' + str(exc)[:80]] += 1
            load_exclusions.append(exclusion_record(record, side, 'fresh_pose_decode_error:' + type(exc).__name__))
        if n % 256 == 0 or n == len(fresh_decode_rows):
            print(f'Decoded {n}/{len(fresh_decode_rows)} fresh clips; range decodes={range_decodes}, working-cache hits={reused_v5_cache}, exclusions={len(load_exclusions)}', flush=True)

rows = pd.DataFrame(rows_loaded).reset_index(drop=True)
rows['source_video_id'] = rows['source_video_id'].astype(str)
assert rows.uid.is_unique and len(rows) == len(pose_paths)
loaded_fresh_train_count = int(np.sum(rows['split_source'] == 'fresh_train'))
loaded_fresh_test_count = int(np.sum(rows['split_source'] == 'fresh_test'))
min_fresh_train = int(math.ceil(FRESH_MIN_COVERAGE * FRESH_TRAIN_TARGET))
min_fresh_test = int(math.ceil(FRESH_MIN_COVERAGE * FRESH_TEST_TARGET))
assert loaded_fresh_train_count >= min_fresh_train, f'Fresh training decode coverage {loaded_fresh_train_count}/{FRESH_TRAIN_TARGET} is below {FRESH_MIN_COVERAGE:.0%}; selection manifest and failure list are preserved; refusing to continue.'
assert loaded_fresh_test_count >= min_fresh_test, f'Fresh test decode coverage {loaded_fresh_test_count}/{FRESH_TEST_TARGET} is below {FRESH_MIN_COVERAGE:.0%}; selection manifest and failure list are preserved; refusing to continue.'
loaded_test_sources = set(rows.loc[rows['split_source'] == 'fresh_test', 'source_video_id'])
loaded_train_sources = set(rows.loc[rows['split_source'] != 'fresh_test', 'source_video_id'])
assert loaded_train_sources.isdisjoint(loaded_test_sources), 'Source-video leakage after loading.'
loaded_train_aliases = set().union(*(set(value) for value in rows.loc[rows['split_source'] != 'fresh_test', 'source_aliases']))
loaded_test_aliases = set().union(*(set(value) for value in rows.loc[rows['split_source'] == 'fresh_test', 'source_aliases']))
assert loaded_train_aliases.isdisjoint(loaded_test_aliases), 'Conservative source-alias leakage after loading.'
print('Loaded effective rows:', len(rows), '| training reservoir:', int((rows.split_source != 'fresh_test').sum()), '| fresh test:', int((rows.split_source == 'fresh_test').sum()))
print('V5 pose loads:', range_decodes, 'fresh archive decodes,', reused_v5_cache, 'working-cache hits; transient retries:',transient_retry_attempts,'; failures:', dict(decode_errors))
print('V2 cached data reused:', len(cached_by_uid), '| fresh selected original:', len(fresh_train_rows), 'train /', len(fresh_test_rows), 'test')

# Load the frozen V4 MiniLM model for a paired baseline on the same fresh test examples.
v4_checkpoint_candidates = list(Path('/kaggle/input').rglob('minilm_position_motion.pt'))
assert v4_checkpoint_candidates, 'Attach the private V4 checkpoint artifact dataset containing minilm_position_motion.pt.'
V4_CHECKPOINT_PATH = v4_checkpoint_candidates[0]
V4_CHECKPOINT_SHA256 = hashlib.sha256(V4_CHECKPOINT_PATH.read_bytes()).hexdigest()
v4_checkpoint = torch.load(V4_CHECKPOINT_PATH, map_location='cpu', weights_only=False)
assert v4_checkpoint.get('arm') == 'minilm_position_motion' and v4_checkpoint.get('frozen_text_encoder') == 'sentence-transformers/all-MiniLM-L6-v2'
assert np.asarray(v4_checkpoint['normalizer_mean']).shape == (75, 3) and np.asarray(v4_checkpoint['normalizer_std']).shape == (75, 3)
assert len(v4_checkpoint['point_indices']) == 75 and v4_checkpoint['time_steps'] == TMAX
print('Frozen V4 checkpoint SHA256:', V4_CHECKPOINT_SHA256, '| architecture:', v4_checkpoint['format'])
