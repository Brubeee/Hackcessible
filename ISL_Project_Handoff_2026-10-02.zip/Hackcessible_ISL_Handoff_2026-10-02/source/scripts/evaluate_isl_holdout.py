"""Evaluate a fixed set of text-to-pose holdouts and write a JSON/Markdown report.

The manifest keeps the selected unseen UIDs, their source-video groups, exact
text, references, and predictions together. Predictions can include true-text,
shuffled-text, zero-pose, and training-frame-mean conditions. This evaluator
reports pose fit and motion separately; it cannot establish sign intelligibility.

Run from the repository root:
    python scripts/evaluate_isl_holdout.py artifacts/holdout_manifest.json

See the module-level ``MANIFEST_EXAMPLE`` below for the supported input shape.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np


MANIFEST_EXAMPLE = {
    "schema_version": 1,
    "dataset": "iSign",
    "split": {
        "strategy": "source-video-disjoint",
        "group_field": "source_video_id",
        "train": [{"uid": "train-1", "source_video_id": "video-a", "text": "..."}],
        "validation": [{"uid": "heldout-1", "source_video_id": "video-b", "text": "..."}],
    },
    "fixed_unseen_set": {
        "seed": 17,
        "count": 1,
        "selection_rule": "sha256_rank_by_uid",
        "uids": ["heldout-1"],
    },
    "training_uids_used": ["train-1"],
    "early_stop_uids": ["internal-val-1"],
    "paired_condition_comparisons": [
        {"name": "new model vs frozen V4", "left_condition": "true_text", "right_condition": "v4_model_true", "scope": "all_samples"}
    ],
    "normalizer": {"path": "train_normalizer.npz", "mean_key": "mean", "std_key": "std"},
    "samples": [
        {
            "uid": "heldout-1",
            "source_video_id": "video-b",
            "text": "A sentence held out from training.",
            "reference": {"path": "references/heldout-1.npz", "pose_key": "pose", "confidence_key": "confidence"},
            "counterfactual_text": "A different sentence assigned to this same clip.",
            "predictions": {
                "true_text": "predictions/heldout-1.true.npy",
                "shuffled_text": "predictions/heldout-1.shuffled.npy",
                "zero_pose": "baselines/heldout-1.zero.npy",
                "train_frame_mean": "baselines/heldout-1.frame_mean.npy",
            },
        }
    ],
}


DEFAULT_GROUPS = [
    {"name": "POSE_LANDMARKS", "start": 0, "count": 33},
    {"name": "FACE_LANDMARKS", "start": 33, "count": 468},
    {"name": "LEFT_HAND_LANDMARKS", "start": 501, "count": 21},
    {"name": "RIGHT_HAND_LANDMARKS", "start": 522, "count": 21},
    {"name": "POSE_WORLD_LANDMARKS", "start": 543, "count": 33},
]


def _resolve(base: Path, value: str | Path) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else (base / path).resolve()


def _load_np(path: Path, key: str | None = None, *, reshape_pose: bool = True) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    if not path.is_file():
        raise FileNotFoundError(f"Array file does not exist: {path}")
    loaded = np.load(path, allow_pickle=False)
    if isinstance(loaded, np.lib.npyio.NpzFile):
        with loaded as archive:
            names = list(archive.files)
            if key is None:
                if len(names) != 1:
                    raise ValueError(f"{path} has keys {names}; specify an array key")
                key = names[0]
            if key not in names:
                raise ValueError(f"{path} has keys {names}; requested {key!r}")
            array = archive[key].copy()
            extras = {name: archive[name].copy() for name in names if name != key}
    else:
        array = loaded
        extras = {}
    array = np.asarray(array)
    if not np.issubdtype(array.dtype, np.number) or not np.isfinite(array).all():
        raise ValueError(f"{path} must contain finite numeric values")
    if reshape_pose:
        if array.ndim == 2 and array.shape[-1] % 3 == 0:
            array = array.reshape(array.shape[0], array.shape[-1] // 3, 3)
        if array.ndim == 4 and array.shape[1] == 1:
            array = array[:, 0]
        if array.ndim != 3 or array.shape[-1] < 2:
            raise ValueError(f"Expected (frames, points, coordinates>=2), got {array.shape} in {path}")
    return array.astype(np.float32, copy=False), extras


def _load_reference(base: Path, spec: str | dict[str, Any]) -> tuple[np.ndarray, np.ndarray | None]:
    if isinstance(spec, str):
        spec = {"path": spec}
    if not isinstance(spec, dict) or not spec.get("path"):
        raise ValueError("Each sample's reference must be a path or an object with a path")
    path = _resolve(base, spec["path"])
    pose, extras = _load_np(path, spec.get("pose_key", "pose"))
    confidence = extras.get(spec.get("confidence_key", "confidence"))
    confidence_path = spec.get("confidence_path")
    if confidence_path:
        confidence, _ = _load_np(_resolve(base, confidence_path), spec.get("confidence_array_key"), reshape_pose=False)
    if confidence is not None:
        if confidence.ndim == 3 and confidence.shape[-1] == 1:
            confidence = confidence[..., 0]
        if confidence.shape != pose.shape[:2] or not np.isfinite(confidence).all():
            raise ValueError(f"Reference confidence must have shape {pose.shape[:2]}, got {confidence.shape}")
        confidence = np.clip(confidence.astype(np.float32), 0.0, 1.0)
    return pose, confidence


def _load_prediction(base: Path, spec: str | dict[str, Any]) -> np.ndarray:
    if isinstance(spec, str):
        spec = {"path": spec}
    if not isinstance(spec, dict) or not spec.get("path"):
        raise ValueError("Prediction conditions must be paths or objects with a path")
    array, _ = _load_np(_resolve(base, spec["path"]), spec.get("key"))
    return array


def _load_normalizer(base: Path, spec: Any) -> tuple[np.ndarray, np.ndarray] | None:
    if spec is None:
        return None
    if not isinstance(spec, dict) or not spec.get("path"):
        raise ValueError("normalizer must have a path and optional mean_key/std_key")
    path = _resolve(base, spec["path"])
    mean, _ = _load_np(path, spec.get("mean_key", "mean"), reshape_pose=False)
    std, _ = _load_np(path, spec.get("std_key", "std"), reshape_pose=False)
    # Normalizer vectors are often saved flat while poses are (frames, points, coords).
    if mean.ndim == 3 and mean.shape[0] == 1:
        mean = mean[0]
    if std.ndim == 3 and std.shape[0] == 1:
        std = std[0]
    if mean.ndim == 1 and mean.size % 3 == 0:
        mean = mean.reshape(-1, 3)
    if std.ndim == 1 and std.size % 3 == 0:
        std = std.reshape(-1, 3)
    if mean.shape != std.shape or not np.isfinite(mean).all() or not np.isfinite(std).all():
        raise ValueError(f"Invalid normalizer arrays: mean {mean.shape}, std {std.shape}")
    if np.any(std <= 0):
        raise ValueError("Normalizer standard deviations must be positive")
    return mean.astype(np.float32), std.astype(np.float32)


def _load_groups(base: Path, spec: Any, point_count: int) -> list[dict[str, Any]]:
    if spec is None:
        groups = DEFAULT_GROUPS
    else:
        path = _resolve(base, spec) if isinstance(spec, (str, Path)) else None
        data = json.loads(path.read_text(encoding="utf-8")) if path else spec
        groups = data.get("components") if isinstance(data, dict) else data
        if not isinstance(groups, list):
            raise ValueError("topology must be a JSON path or list/object with components")
    normalized = []
    for group in groups:
        if not isinstance(group, dict) or not isinstance(group.get("start"), int) or not isinstance(group.get("count"), int):
            raise ValueError(f"Invalid component definition: {group!r}")
        start, count = group["start"], group["count"]
        if start < 0 or count <= 0 or start + count > point_count:
            raise ValueError(f"Component range is outside 0..{point_count}: {group!r}")
        normalized.append({"name": group.get("name", f"points_{start}_{start+count}"), "start": start, "count": count})
    normalized.sort(key=lambda row: row["start"])
    cursor = 0
    for group in normalized:
        if group["start"] != cursor:
            raise ValueError(f"Components must cover each point exactly once; gap/overlap at point {cursor}")
        cursor += group["count"]
    if cursor != point_count:
        raise ValueError(f"Components cover {cursor} points, but arrays have {point_count}")
    return normalized


def _objective_spec(manifest: dict[str, Any], groups: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Load the predeclared objective used for paired comparisons, if supplied."""
    objective = manifest.get("objective")
    if not isinstance(objective, dict):
        return None
    weights = objective.get("group_weights")
    coefficient = objective.get("velocity_coefficient")
    if not isinstance(weights, dict) or not isinstance(coefficient, (int, float)):
        return None
    names = [group["name"] for group in groups]
    try:
        normalized_weights = {name: float(weights[name]) for name in names}
    except (KeyError, TypeError, ValueError):
        return None
    coefficient = float(coefficient)
    if not math.isfinite(coefficient) or coefficient < 0:
        return None
    if any(not math.isfinite(value) or value < 0 for value in normalized_weights.values()):
        return None
    if not math.isclose(sum(normalized_weights.values()), 1.0, rel_tol=0.0, abs_tol=1e-6):
        return None
    return {"group_weights": normalized_weights, "velocity_coefficient": coefficient}


def _normalize(array: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    try:
        return (array - mean[None, ...]) / std[None, ...]
    except ValueError as exc:
        raise ValueError(f"Normalizer shape {mean.shape} cannot broadcast to pose {array.shape}") from exc


def _resample(sequence: np.ndarray, frame_count: int) -> np.ndarray:
    old = np.linspace(0.0, 1.0, sequence.shape[0], dtype=np.float64)
    new = np.linspace(0.0, 1.0, frame_count, dtype=np.float64)
    flat = sequence.reshape(sequence.shape[0], -1)
    return np.stack([np.interp(new, old, flat[:, i]) for i in range(flat.shape[1])], axis=1).reshape(
        frame_count, *sequence.shape[1:]
    ).astype(np.float32)


def _weighted_quantile(values: np.ndarray, weights: np.ndarray, quantile: float) -> float | None:
    values = np.asarray(values).ravel()
    weights = np.asarray(weights).ravel()
    valid = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    if not valid.any():
        return None
    values, weights = values[valid], weights[valid]
    order = np.argsort(values)
    values, weights = values[order], weights[order]
    cumulative = np.cumsum(weights)
    index = min(int(np.searchsorted(cumulative, quantile * cumulative[-1], side="left")), len(values) - 1)
    return float(values[index])


def _pair_metrics(reference: np.ndarray, prediction: np.ndarray, confidence: np.ndarray | None,
                  normalizer: tuple[np.ndarray, np.ndarray] | None) -> dict[str, Any]:
    if reference.shape != prediction.shape:
        raise ValueError(f"Reference/prediction shape mismatch: {reference.shape} vs {prediction.shape}")
    conf = np.ones(reference.shape[:2], dtype=np.float32) if confidence is None else confidence
    coord_weights = np.broadcast_to(conf[..., None], reference.shape)
    diff = prediction - reference
    denom = float(coord_weights.sum())
    valid_point_frames = int(np.count_nonzero(conf > 0))
    result: dict[str, Any] = {
        "shape": list(reference.shape),
        "confidence_weight_sum": float(conf.sum()),
        "confidence_valid_point_frame_count": valid_point_frames,
        "confidence_point_frame_count": int(conf.size),
        "confidence_coverage_fraction": float(valid_point_frames / conf.size) if conf.size else None,
        "raw_rmse": float(np.sqrt(np.mean(np.square(diff)))),
        "raw_mae": float(np.mean(np.abs(diff))),
        "confidence_weighted_raw_rmse": float(np.sqrt((np.square(diff) * coord_weights).sum() / denom)) if denom else None,
        "confidence_weighted_raw_mae": float((np.abs(diff) * coord_weights).sum() / denom) if denom else None,
    }
    if normalizer is not None:
        mean, std = normalizer
        z_prediction = _normalize(prediction, mean, std)
        z_reference = _normalize(reference, mean, std)
        z_diff = z_prediction - z_reference
        z_denom = denom
        result["train_normalized_confidence_weighted_mse"] = float((np.square(z_diff) * coord_weights).sum() / z_denom) if z_denom else None
        result["train_normalized_confidence_weight_sum"] = z_denom
        result["train_normalized_confidence_weighted_rmse"] = math.sqrt(result["train_normalized_confidence_weighted_mse"]) if z_denom else None
        result["train_normalized_rmse"] = float(np.sqrt(np.mean(np.square(z_diff))))
        if reference.shape[0] > 1:
            delta_conf_for_loss = np.minimum(conf[1:], conf[:-1])
            velocity_error = np.diff(z_prediction, axis=0) - np.diff(z_reference, axis=0)
            velocity_weights = np.broadcast_to(delta_conf_for_loss[..., None], velocity_error.shape)
            velocity_denom = float(velocity_weights.sum())
            result["train_normalized_confidence_weighted_velocity_mse"] = (
                float((np.square(velocity_error) * velocity_weights).sum() / velocity_denom)
                if velocity_denom else None
            )
            result["train_normalized_confidence_weighted_velocity_weight_sum"] = velocity_denom
        else:
            result["train_normalized_confidence_weighted_velocity_mse"] = None
            result["train_normalized_confidence_weighted_velocity_weight_sum"] = 0.0

    # Motion descriptors show how much the sequence moves; they do not assess sign semantics.
    ref_delta = np.diff(reference, axis=0)
    pred_delta = np.diff(prediction, axis=0)
    ref_magnitude = np.linalg.norm(ref_delta, axis=-1)
    pred_magnitude = np.linalg.norm(pred_delta, axis=-1)
    delta_conf = np.minimum(conf[1:], conf[:-1])
    result["motion"] = {
        "reference_median": float(np.median(ref_magnitude)) if ref_magnitude.size else 0.0,
        "prediction_median": float(np.median(pred_magnitude)) if pred_magnitude.size else 0.0,
        "reference_p90": float(np.percentile(ref_magnitude, 90)) if ref_magnitude.size else 0.0,
        "prediction_p90": float(np.percentile(pred_magnitude, 90)) if pred_magnitude.size else 0.0,
        "median_ratio_prediction_to_reference": (
            float(np.median(pred_magnitude) / np.median(ref_magnitude))
            if ref_magnitude.size and float(np.median(ref_magnitude)) > 1e-6 else None
        ),
        "magnitude_mae": float(np.mean(np.abs(pred_magnitude - ref_magnitude))) if ref_magnitude.size else 0.0,
        "confidence_weighted_magnitude_mae": float((np.abs(pred_magnitude - ref_magnitude) * delta_conf).sum() / delta_conf.sum()) if delta_conf.sum() else None,
        "confidence_weighted_prediction_mean_magnitude": float((pred_magnitude * delta_conf).sum() / delta_conf.sum()) if delta_conf.sum() else None,
        "confidence_weighted_reference_mean_magnitude": float((ref_magnitude * delta_conf).sum() / delta_conf.sum()) if delta_conf.sum() else None,
        "confidence_weighted_prediction_magnitude_sum": float((pred_magnitude * delta_conf).sum()) if delta_conf.sum() else 0.0,
        "confidence_weighted_reference_magnitude_sum": float((ref_magnitude * delta_conf).sum()) if delta_conf.sum() else 0.0,
        "confidence_weight_sum": float(delta_conf.sum()),
        "confidence_weighted_motion_ratio_prediction_to_reference": (
            float((pred_magnitude * delta_conf).sum() / (ref_magnitude * delta_conf).sum())
            if (ref_magnitude * delta_conf).sum() > 1e-8 else None
        ),
        "confidence_weighted_median_ratio_prediction_to_reference": (
            float(_weighted_quantile(pred_magnitude, delta_conf, 0.5) / _weighted_quantile(ref_magnitude, delta_conf, 0.5))
            if delta_conf.sum() and (_weighted_quantile(ref_magnitude, delta_conf, 0.5) or 0.0) > 1e-6 else None
        ),
    }
    return result


def _aggregate(rows: list[dict[str, Any]]) -> dict[str, Any]:
    numeric_keys = sorted({key for row in rows for key, value in row.items() if isinstance(value, (int, float)) and value is not None})
    summary: dict[str, Any] = {"examples": len(rows), "macro_mean": {}, "metric_valid_counts": {}}
    for key in numeric_keys:
        values = [float(row[key]) for row in rows if isinstance(row.get(key), (int, float)) and row[key] is not None]
        if values:
            summary["macro_mean"][key] = float(np.mean(values))
            summary.setdefault("macro_median", {})[key] = float(np.median(values))
        summary["metric_valid_counts"][key] = len(values)
    motion_keys = sorted({key for row in rows for key, value in row.get("motion", {}).items() if isinstance(value, (int, float)) and value is not None})
    if motion_keys:
        summary["motion_macro_mean"] = {}
        for key in motion_keys:
            values = [float(row["motion"][key]) for row in rows if isinstance(row.get("motion", {}).get(key), (int, float)) and row["motion"][key] is not None]
            if values:
                summary["motion_macro_mean"][key] = float(np.mean(values))
        pred_sum = sum(float(row["motion"].get("confidence_weighted_prediction_magnitude_sum", 0.0)) for row in rows)
        ref_sum = sum(float(row["motion"].get("confidence_weighted_reference_magnitude_sum", 0.0)) for row in rows)
        motion_weight = sum(float(row["motion"].get("confidence_weight_sum", 0.0)) for row in rows)
        summary["motion_pooled"] = {
            "confidence_weight_sum": motion_weight,
            "confidence_weighted_mean_prediction_magnitude": pred_sum / motion_weight if motion_weight else None,
            "confidence_weighted_mean_reference_magnitude": ref_sum / motion_weight if motion_weight else None,
            "prediction_to_reference_mean_magnitude_ratio": pred_sum / ref_sum if ref_sum > 1e-8 else None,
        }
    return summary


def _id_and_group(entry: Any, group_field: str | None) -> tuple[str, str | None, str | None]:
    if isinstance(entry, str):
        return entry, None, None
    if not isinstance(entry, dict) or not entry.get("uid"):
        raise ValueError(f"Split rows must be UID strings or objects containing uid: {entry!r}")
    group = entry.get(group_field) if group_field else None
    return str(entry["uid"]), str(group) if group is not None else None, entry.get("text")


def _canonical_text(value: str) -> str:
    # Match the V5 selection key: case-fold and retain word tokens while
    # ignoring punctuation, so punctuation-only variants collide in the audit.
    return " ".join(re.findall(r"[a-z0-9]+(?:'[a-z0-9]+)?", value.lower(), flags=re.IGNORECASE))


def _uid_video_base(uid: str) -> str | None:
    """Return a candidate iSign source ID from a recognized trailing UID suffix.

    The official iSign card describes UIDs as a video ID plus a within-video
    sequence. This artifact also has endings such as ``_e2`` and ``_d``. These
    are treated as possible segment/task suffixes for a collision warning only;
    the manifest's source IDs are never silently rewritten.
    """
    match = re.match(r"^(.+?)(?:_e\d+|_d|--\d+|-\d+)$", uid)
    return match.group(1) if match else None


def _split_audit(manifest: dict[str, Any], samples: list[dict[str, Any]]) -> dict[str, Any]:
    split = manifest.get("split")
    if not isinstance(split, dict):
        return {"status": "unverified", "reason": "manifest has no split metadata"}
    group_field = split.get("group_field")
    train_rows = split.get("train", []) or []
    val_rows = split.get("validation", split.get("holdout", [])) or []
    if not isinstance(train_rows, list) or not isinstance(val_rows, list):
        raise ValueError("split.train and split.validation must be lists")
    train = [_id_and_group(row, group_field) for row in train_rows]
    val = [_id_and_group(row, group_field) for row in val_rows]
    train_ids = {row[0] for row in train}
    val_ids = {row[0] for row in val}
    train_groups = {row[1] for row in train if row[1] is not None}
    val_groups = {row[1] for row in val if row[1] is not None}
    train_texts = {_canonical_text(row[2]) for row in train if row[2]}
    val_texts = {_canonical_text(row[2]) for row in val if row[2]}
    sample_ids = {str(row.get("uid", "")) for row in samples}
    val_by_uid = {uid: group for uid, group, _ in val}
    eval_train_overlap = sorted(sample_ids & train_ids)
    eval_val_missing = sorted(sample_ids - val_ids) if val_ids else []
    eval_group_mismatch = sorted(
        str(row["uid"]) for row in samples
        if str(row.get("uid", "")) in val_by_uid
        and row.get(group_field) is not None
        and val_by_uid[str(row["uid"])] is not None
        and str(row[group_field]) != val_by_uid[str(row["uid"])]
    ) if group_field else []
    val_texts_by_uid = {uid: _canonical_text(text) for uid, _, text in val if text}
    validation_text_mismatch = sorted(
        str(row["uid"]) for row in samples
        if str(row.get("uid", "")) in val_texts_by_uid and row.get("text")
        and _canonical_text(str(row["text"])) != val_texts_by_uid[str(row["uid"])]
    )
    uid_overlap = sorted(train_ids & val_ids)
    group_overlap = sorted(train_groups & val_groups)
    duplicate_train_uids = sorted({uid for uid, _, _ in train if sum(row[0] == uid for row in train) > 1})
    duplicate_val_uids = sorted({uid for uid, _, _ in val if sum(row[0] == uid for row in val) > 1})
    checked = bool(train_rows and val_rows)
    groups_complete = bool(group_field) and all(group is not None for _, group, _ in train + val)

    # Check whether suffix-bearing UIDs reveal repeated candidate video IDs that
    # are absent from the declared source_video_id groups.
    candidate_train: dict[str, list[str]] = defaultdict(list)
    candidate_val: dict[str, list[str]] = defaultdict(list)
    candidate_uid_count = 0
    declared_candidate_mismatches: list[str] = []
    for uid, group, _ in train:
        base = _uid_video_base(uid)
        if base is not None:
            candidate_uid_count += 1
            candidate_train[base].append(uid)
            if group is not None and group != base:
                declared_candidate_mismatches.append(uid)
    for uid, group, _ in val:
        base = _uid_video_base(uid)
        if base is not None:
            candidate_uid_count += 1
            candidate_val[base].append(uid)
            if group is not None and group != base:
                declared_candidate_mismatches.append(uid)
    candidate_video_overlaps = sorted(set(candidate_train) & set(candidate_val))
    candidate_video_overlap_rows = {
        "train": sum(len(candidate_train[base]) for base in candidate_video_overlaps),
        "validation": sum(len(candidate_val[base]) for base in candidate_video_overlaps),
    }
    meta_by_uid = {str(row["uid"]): row for row in train_rows + val_rows if isinstance(row, dict) and row.get("uid")}

    def alias_set(records: list[Any]) -> tuple[set[str], list[str]]:
        values: set[str] = set()
        missing: list[str] = []
        for record in records:
            if not isinstance(record, dict) or not isinstance(record.get("source_aliases"), (list, tuple, set)):
                missing.append(str(record.get("uid", "<unknown>")) if isinstance(record, dict) else "<non-object-row>")
                continue
            values.update(str(value) for value in record["source_aliases"] if value is not None and str(value))
        return values, missing

    original_train_rows = split.get("original_train", []) or []
    original_validation_rows = split.get("original_validation", []) or []
    effective_train_aliases, effective_train_alias_missing = alias_set(train_rows)
    effective_val_aliases, effective_val_alias_missing = alias_set(val_rows)
    original_train_aliases, original_train_alias_missing = alias_set(original_train_rows)
    original_val_aliases, original_val_alias_missing = alias_set(original_validation_rows)
    original_v2_rows = [row for row in original_train_rows if isinstance(row, dict) and row.get("split_source") == "v2_reservoir"]
    original_fresh_train_rows = [row for row in original_train_rows if isinstance(row, dict) and row.get("split_source") == "fresh_train"]
    v2_aliases, v2_alias_missing = alias_set(original_v2_rows)
    fresh_train_aliases, fresh_train_alias_missing = alias_set(original_fresh_train_rows)

    def resolve_effective_rows(name: str) -> tuple[list[tuple[str, str | None, str | None]], list[str], bool]:
        value = manifest.get(name)
        if value is None:
            return [], [], False
        if not isinstance(value, list):
            raise ValueError(f"{name} must be a list of UIDs or row objects")
        result, unknown = [], []
        for item in value:
            uid = str(item if isinstance(item, str) else item.get("uid", ""))
            metadata = item if isinstance(item, dict) else meta_by_uid.get(uid)
            if not uid or metadata is None:
                unknown.append(uid or repr(item))
                continue
            result.append(_id_and_group(metadata, group_field))
        return result, unknown, True

    fit, fit_unknown, fit_declared = resolve_effective_rows("training_uids_used")
    early, early_unknown, early_declared = resolve_effective_rows("early_stop_uids")
    fit_ids = {row[0] for row in fit}
    early_ids = {row[0] for row in early}
    fit_alias_rows = [meta_by_uid[uid] for uid in fit_ids if uid in meta_by_uid]
    early_alias_rows = [meta_by_uid[uid] for uid in early_ids if uid in meta_by_uid]
    fit_aliases, fit_alias_missing = alias_set(fit_alias_rows)
    early_aliases, early_alias_missing = alias_set(early_alias_rows)
    alias_intersections = {
        "effective_train__validation": sorted(effective_train_aliases & effective_val_aliases),
        "original_train__validation": sorted(original_train_aliases & original_val_aliases),
        "v2_reservoir__fresh_train": sorted(v2_aliases & fresh_train_aliases),
        "v2_reservoir__fresh_test": sorted(v2_aliases & original_val_aliases),
        "fresh_train__fresh_test": sorted(fresh_train_aliases & original_val_aliases),
        "training_reservoir__fresh_test": sorted(original_train_aliases & original_val_aliases),
        "fit__early_stop": sorted(fit_aliases & early_aliases),
        "fit__validation": sorted(fit_aliases & effective_val_aliases),
        "early_stop__validation": sorted(early_aliases & effective_val_aliases),
    }
    alias_missing_by_partition = {
        "effective_train": effective_train_alias_missing,
        "effective_validation": effective_val_alias_missing,
        "original_train": original_train_alias_missing,
        "original_validation": original_val_alias_missing,
        "v2_reservoir": v2_alias_missing,
        "fresh_train": fresh_train_alias_missing,
        "fit": fit_alias_missing,
        "early_stop": early_alias_missing,
    }
    alias_rows_available = all(not missing for missing in alias_missing_by_partition.values())
    source_alias_fail = any(alias_intersections.values())
    declared_alias_intersections = split.get("source_alias_audit", {}).get("intersections", {})
    declared_alias_comparison_map = {
        "v2_reservoir__fresh_train": "v2_reservoir__fresh_train",
        "v2_reservoir__fresh_test": "v2_reservoir__fresh_test",
        "fresh_train__fresh_test": "fresh_train__fresh_test",
        "training_reservoir__fresh_test": "training_reservoir__fresh_test",
        "fit__early_stop": "fit__early_stop",
        "fit__fresh_test": "fit__validation",
        "early_stop__fresh_test": "early_stop__validation",
    }
    declared_alias_comparisons = {}
    for declared_key, computed_key in declared_alias_comparison_map.items():
        declared_values = declared_alias_intersections.get(declared_key)
        declared_alias_comparisons[declared_key] = {
            "declared_available": isinstance(declared_values, list),
            "matches_recomputed": (
                sorted(str(value) for value in declared_values) == alias_intersections[computed_key]
                if isinstance(declared_values, list) else None
            ),
        }
    alias_declaration_mismatch = any(
        result["matches_recomputed"] is False for result in declared_alias_comparisons.values()
    )
    source_alias_fail = source_alias_fail or alias_declaration_mismatch
    fit_groups = {row[1] for row in fit if row[1] is not None}
    early_groups = {row[1] for row in early if row[1] is not None}
    fit_texts = {_canonical_text(row[2]) for row in fit if row[2]}
    early_texts = {_canonical_text(row[2]) for row in early if row[2]}
    fit_candidate_bases = {base for uid, _, _ in fit if (base := _uid_video_base(uid)) is not None}
    early_candidate_bases = {base for uid, _, _ in early if (base := _uid_video_base(uid)) is not None}
    validation_candidate_bases = {base for uid, _, _ in val if (base := _uid_video_base(uid)) is not None}
    fit_early_candidate_overlap = sorted(fit_candidate_bases & early_candidate_bases)
    fit_validation_candidate_overlap = sorted(fit_candidate_bases & validation_candidate_bases)
    early_validation_candidate_overlap = sorted(early_candidate_bases & validation_candidate_bases)
    sample_candidate_by_uid = {
        str(row.get("uid", "")): _uid_video_base(str(row.get("uid", "")))
        for row in samples
    }
    fixed_fit_candidate_overlap_uids = sorted(
        uid for uid, base in sample_candidate_by_uid.items() if base and base in fit_candidate_bases
    )
    fixed_early_candidate_overlap_uids = sorted(
        uid for uid, base in sample_candidate_by_uid.items() if base and base in early_candidate_bases
    )
    fixed_unseen_ids = {
        str(uid) for uid in manifest.get("fixed_unseen_set", {}).get("uids", [])
    }
    fixed_unseen_fit_candidate_overlap_uids = sorted(
        uid for uid in fixed_unseen_ids
        if sample_candidate_by_uid.get(uid) and sample_candidate_by_uid[uid] in fit_candidate_bases
    )
    fixed_unseen_early_candidate_overlap_uids = sorted(
        uid for uid in fixed_unseen_ids
        if sample_candidate_by_uid.get(uid) and sample_candidate_by_uid[uid] in early_candidate_bases
    )
    fit_outside_outer_train = sorted(fit_ids - train_ids)
    early_outside_outer_train = sorted(early_ids - train_ids)
    fit_early_uid_overlap = sorted(fit_ids & early_ids)
    fit_early_group_overlap = sorted(fit_groups & early_groups)
    fixed_fit_uid_overlap = sorted(sample_ids & fit_ids)
    fixed_early_uid_overlap = sorted(sample_ids & early_ids)
    fixed_fit_group_overlap = sorted(
        str(row["uid"]) for row in samples
        if row.get(group_field) is not None and str(row[group_field]) in fit_groups
    ) if group_field else []
    fixed_early_group_overlap = sorted(
        str(row["uid"]) for row in samples
        if row.get(group_field) is not None and str(row[group_field]) in early_groups
    ) if group_field else []
    fit_caption_overlap = sorted(
        str(row["uid"]) for row in samples
        if row.get("text") and _canonical_text(str(row["text"])) in fit_texts
    )
    early_caption_overlap = sorted(
        str(row["uid"]) for row in samples
        if row.get("text") and _canonical_text(str(row["text"])) in early_texts
    )
    source_uid_parser = split.get("source_uid_parser", {})
    if not isinstance(source_uid_parser, dict):
        source_uid_parser = {}
    source_id_provenance = str(split.get("source_video_id_provenance", "unknown"))
    official_source_id_used = (
        source_uid_parser.get("official_video_id_column_used") is True
        or source_id_provenance.lower().startswith("official")
    )
    source_fail = bool(uid_overlap or group_overlap or eval_train_overlap or eval_val_missing or eval_group_mismatch or duplicate_train_uids or duplicate_val_uids)
    if source_fail or source_alias_fail:
        source_video_status = "fail"
    elif candidate_video_overlaps or fit_early_candidate_overlap or fit_validation_candidate_overlap or early_validation_candidate_overlap:
        source_video_status = "fail"
    elif checked and groups_complete and official_source_id_used:
        source_video_status = "pass"
    elif checked and groups_complete:
        source_video_status = "unverified_inferred_source_ids"
    else:
        source_video_status = "unverified"
    fit_fail = bool(fit_outside_outer_train or fixed_fit_uid_overlap or fixed_fit_group_overlap or fit_caption_overlap)
    early_fail = bool(early_outside_outer_train or fit_early_uid_overlap or fit_early_group_overlap or fixed_early_uid_overlap or fixed_early_group_overlap or early_caption_overlap)
    candidate_source_fail = bool(
        candidate_video_overlaps or fit_early_candidate_overlap
        or fit_validation_candidate_overlap or early_validation_candidate_overlap
    )
    if source_fail or source_alias_fail or candidate_source_fail or fit_fail or early_fail or validation_text_mismatch:
        status = "fail"
    elif checked and groups_complete and official_source_id_used and fit_declared and early_declared and not fit_unknown and not early_unknown:
        status = "pass"
    elif checked:
        status = "partial"
    else:
        status = "unverified"
    signer_field = split.get("signer_field", "signer_id")
    has_signer = any(isinstance(row, dict) and row.get(signer_field) is not None for row in train_rows + val_rows)
    exact_text_check_available = bool(train_texts or val_texts)
    return {
        "status": status,
        "source_video_disjointness_status": source_video_status,
        "source_identity_provenance": source_id_provenance,
        "source_identity_authority_status": "official_video_id" if official_source_id_used else "inferred_or_unverified",
        "uid_suffix_video_id_audit": {
            "status": "fail_likely_source_video_overlap_requires_reconciliation" if (candidate_video_overlaps or fit_early_candidate_overlap or fit_validation_candidate_overlap or early_validation_candidate_overlap) else "pass_no_overlap_found",
            "rule": "candidate base strips terminal _eN, _d, --N, or -N; used only as a warning until reconciled with authoritative metadata",
            "official_video_id_column_used": source_uid_parser.get("official_video_id_column_used"),
            "source_identity_authoritative": official_source_id_used,
            "rows_with_recognized_uid_suffix": candidate_uid_count,
            "declared_source_id_differs_from_candidate_base_count": len(declared_candidate_mismatches),
            "cross_split_candidate_source_video_count": len(candidate_video_overlaps),
            "cross_split_candidate_rows": candidate_video_overlap_rows,
            "gradient_fit_internal_early_stop_candidate_overlap_count": len(fit_early_candidate_overlap),
            "gradient_fit_outer_validation_candidate_overlap_count": len(fit_validation_candidate_overlap),
            "early_stop_outer_validation_candidate_overlap_count": len(early_validation_candidate_overlap),
            "evaluated_sample_gradient_fit_candidate_overlap_count": len(fixed_fit_candidate_overlap_uids),
            "evaluated_sample_early_stop_candidate_overlap_count": len(fixed_early_candidate_overlap_uids),
            "fixed_qualitative_sample_gradient_fit_candidate_overlap_count": len(fixed_unseen_fit_candidate_overlap_uids),
            "fixed_qualitative_sample_early_stop_candidate_overlap_count": len(fixed_unseen_early_candidate_overlap_uids),
            "overlapping_candidate_source_ids": candidate_video_overlaps[:100],
            "example_uids": {
                "train": [uid for base in candidate_video_overlaps[:10] for uid in candidate_train[base]],
                "validation": [uid for base in candidate_video_overlaps[:10] for uid in candidate_val[base]],
            },
            "overlap_examples": {
                "gradient_fit_internal_early_stop_source_ids": fit_early_candidate_overlap[:25],
                "gradient_fit_outer_validation_source_ids": fit_validation_candidate_overlap[:25],
                "early_stop_outer_validation_source_ids": early_validation_candidate_overlap[:25],
                "evaluated_sample_gradient_fit_uids": fixed_fit_candidate_overlap_uids[:25],
                "evaluated_sample_early_stop_uids": fixed_early_candidate_overlap_uids[:25],
                "fixed_qualitative_gradient_fit_uids": fixed_unseen_fit_candidate_overlap_uids,
                "fixed_qualitative_early_stop_uids": fixed_unseen_early_candidate_overlap_uids,
            },
            "interpretation": "The manifest parser retained apparent segment/task suffixes in source_video_id. iSign documentation describes within-video sequence IDs and multiple DEF clips from one source video; until this UID parsing is reconciled, the split fails a clean source-video-disjointness audit.",
        },
        "source_alias_audit": {
            "status": "fail" if source_alias_fail else ("pass" if alias_rows_available else "unverified"),
            "intersections": alias_intersections,
            "intersection_counts": {name: len(values) for name, values in alias_intersections.items()},
            "declared_manifest_comparisons": declared_alias_comparisons,
            "declared_manifest_mismatch": alias_declaration_mismatch,
            "rows_missing_source_aliases": alias_missing_by_partition,
            "interpretation": "Recomputed from each split record's exported source_aliases, including the predecode roster when supplied.",
        },
        "strategy": split.get("strategy"),
        "group_field": group_field,
        "train_count": len(train_ids),
        "validation_count": len(val_ids),
        "evaluated_count": len(sample_ids),
        "train_validation_uid_overlap_count": len(uid_overlap),
        "evaluated_train_uid_overlap_count": len(eval_train_overlap),
        "evaluated_uid_missing_from_validation_count": len(eval_val_missing),
        "train_validation_group_overlap_count": len(group_overlap),
        "group_ids_complete": groups_complete if group_field else False,
        "duplicate_train_uid_count": len(duplicate_train_uids),
        "duplicate_validation_uid_count": len(duplicate_val_uids),
        "evaluated_source_group_mismatch_count": len(eval_group_mismatch),
        "train_validation_text_overlap_count": len(train_texts & val_texts) if exact_text_check_available else None,
        "fixed_sample_original_train_caption_overlap_count": sum(bool(row.get("text") and _canonical_text(str(row["text"])) in train_texts) for row in samples),
        "training_uids_used_count": len(fit_ids),
        "training_uids_used_declared": fit_declared,
        "training_uids_used_outside_outer_train_count": len(fit_outside_outer_train),
        "training_uids_unresolved_count": len(fit_unknown),
        "fixed_sample_gradient_fit_uid_overlap_count": len(fixed_fit_uid_overlap),
        "fixed_sample_gradient_fit_source_group_overlap_count": len(fixed_fit_group_overlap),
        "fixed_sample_gradient_fit_caption_overlap_count": len(fit_caption_overlap),
        "gradient_fit_subset_status": "fail" if fit_fail else ("pass" if fit_declared and not fit_unknown else "unverified"),
        "early_stop_uids_count": len(early_ids),
        "early_stop_uids_declared": early_declared,
        "early_stop_uids_outside_outer_train_count": len(early_outside_outer_train),
        "early_stop_uids_unresolved_count": len(early_unknown),
        "gradient_fit_early_stop_uid_overlap_count": len(fit_early_uid_overlap),
        "gradient_fit_early_stop_source_group_overlap_count": len(fit_early_group_overlap),
        "fixed_sample_early_stop_uid_overlap_count": len(fixed_early_uid_overlap),
        "fixed_sample_early_stop_caption_overlap_count": len(early_caption_overlap),
        "early_stop_disjointness_status": "fail" if early_fail else ("pass" if early_declared and not early_unknown else "unverified"),
        "fixed_sample_validation_text_mismatch_count": len(validation_text_mismatch),
        "fixed_sample_sentence_disjointness": "fail" if fit_caption_overlap or early_caption_overlap else ("pass" if fit_declared and early_declared and all(row.get("text") for row in samples) and not fit_unknown and not early_unknown else "unverified"),
        "text_overlap_interpretation": "reported for review; repeated captions can be legitimate across distinct videos",
        "signer_disjointness": "checked" if has_signer else "unknown: signer IDs absent from manifest",
        "overlap_examples": {"uids": uid_overlap[:10], "groups": group_overlap[:10], "evaluated_train_uids": eval_train_overlap[:10], "eval_missing_from_validation": eval_val_missing[:10], "eval_group_mismatch": eval_group_mismatch[:10], "gradient_fit_uid": fixed_fit_uid_overlap[:10], "gradient_fit_groups": fixed_fit_group_overlap[:10], "gradient_fit_caption": fit_caption_overlap[:10], "early_stop_caption": early_caption_overlap[:10], "validation_text_mismatch": validation_text_mismatch[:10]},
    }


def _counterfactual_audit(manifest: dict[str, Any], samples: list[dict[str, Any]]) -> dict[str, Any]:
    split = manifest.get("split", {})
    validation = split.get("validation", []) if isinstance(split, dict) else []
    train = split.get("train", []) if isinstance(split, dict) else []
    validation_by_uid = {
        str(row.get("uid")): row for row in validation
        if isinstance(row, dict) and row.get("uid")
    }
    fit_rows_by_uid = {
        str(row.get("uid")): row for row in train
        if isinstance(row, dict) and row.get("uid")
    }
    fit_uids = manifest.get("training_uids_used", split.get("training_uids_used", []))
    fit_texts = set()
    for item in fit_uids or []:
        uid = str(item if isinstance(item, str) else item.get("uid", ""))
        row = fit_rows_by_uid.get(uid) or (item if isinstance(item, dict) else None)
        if row and row.get("text"):
            fit_texts.add(_canonical_text(str(row["text"])))
    shuffled_samples = [row for row in samples if "shuffled_text" in row.get("predictions", {})]
    if not shuffled_samples:
        return {"status": "not_applicable", "checked_count": 0}
    issues = {name: [] for name in (
        "missing_counterfactual_text", "same_as_true_text", "missing_or_invalid_donor_uid",
        "donor_text_mismatch", "same_source_video_donor", "gradient_fit_caption_overlap",
    )}
    for sample in shuffled_samples:
        uid = str(sample.get("uid", ""))
        counter_text = sample.get("counterfactual_text")
        true_text = sample.get("text")
        donor_uid = str(sample.get("counterfactual_source_uid", ""))
        donor = validation_by_uid.get(donor_uid)
        if not counter_text:
            issues["missing_counterfactual_text"].append(uid)
            continue
        counter_key = _canonical_text(str(counter_text))
        if true_text and counter_key == _canonical_text(str(true_text)):
            issues["same_as_true_text"].append(uid)
        if counter_key in fit_texts:
            issues["gradient_fit_caption_overlap"].append(uid)
        if not donor_uid or donor_uid == uid or donor is None:
            issues["missing_or_invalid_donor_uid"].append(uid)
        elif _canonical_text(str(donor.get("text", ""))) != counter_key:
            issues["donor_text_mismatch"].append(uid)
        elif sample.get("source_video_id") and donor.get("source_video_id") is not None and str(sample["source_video_id"]) == str(donor["source_video_id"]):
            issues["same_source_video_donor"].append(uid)
    has_coverage = bool(validation_by_uid and fit_texts)
    failed = any(issues.values())
    return {
        "status": "fail" if failed else ("pass" if has_coverage else "unverified"),
        "checked_count": len(shuffled_samples),
        "issues": {name: {"count": len(uids), "uids": uids[:10]} for name, uids in issues.items()},
        "interpretation": "checks shuffled captions against declared validation donors and effective gradient-fit captions; does not establish semantic fairness of the counterfactual pairing",
    }


def _canonicalization_exclusion_audit(manifest: dict[str, Any], samples: list[dict[str, Any]]) -> dict[str, Any]:
    split = manifest.get("split", {})
    canonicalization = manifest.get("canonicalization", {})
    exclusions = manifest.get("canonicalization_exclusions")
    if exclusions is None:
        exclusions = split.get("canonicalization_exclusions") if isinstance(split, dict) else None
    if exclusions is None and isinstance(canonicalization, dict):
        exclusions = canonicalization.get("exclusions")
    if exclusions is None:
        exclusions = []
    if not isinstance(exclusions, list) or not isinstance(split, dict):
        return {"status": "fail", "reason": "exclusions or split metadata has an invalid shape"}
    original_train = split.get("original_train")
    original_validation = split.get("original_validation")
    if not isinstance(original_train, list) or not isinstance(original_validation, list):
        if not exclusions and original_train is None and original_validation is None:
            return {"status": "not_applicable", "excluded_count": 0,
                    "reason": "no canonicalization exclusions or original split audit supplied"}
        return {"status": "unverified", "excluded_count": len(exclusions),
                "reason": "pre-filter original split membership was not supplied"}
    effective_train = split.get("train", []) or []
    effective_validation = split.get("validation", []) or []
    if not isinstance(effective_train, list) or not isinstance(effective_validation, list):
        return {"status": "fail", "excluded_count": len(exclusions),
                "reason": "effective split membership has an invalid shape"}
    group_field = split.get("group_field")
    try:
        train_tuples = [_id_and_group(row, group_field) for row in original_train]
        val_tuples = [_id_and_group(row, group_field) for row in original_validation]
        effective_train_tuples = [_id_and_group(row, group_field) for row in effective_train]
        effective_val_tuples = [_id_and_group(row, group_field) for row in effective_validation]
    except (TypeError, ValueError, AttributeError) as exc:
        return {"status": "fail", "excluded_count": len(exclusions),
                "reason": f"invalid split row: {exc}"}
    original_train_meta = {uid: (group, text) for uid, group, text in train_tuples}
    original_val_meta = {uid: (group, text) for uid, group, text in val_tuples}
    effective_train_ids = {uid for uid, _, _ in (_id_and_group(row, group_field) for row in effective_train)}
    effective_val_ids = {uid for uid, _, _ in (_id_and_group(row, group_field) for row in effective_validation)}
    sample_ids = {str(row.get("uid", "")) for row in samples}
    fit_raw = manifest.get("training_uids_used", []) or []
    early_raw = manifest.get("early_stop_uids", []) or []
    def declared_ids(rows: Any) -> set[str]:
        if not isinstance(rows, list):
            return set()
        return {str(row if isinstance(row, str) else row.get("uid", "")) for row in rows if isinstance(row, (str, dict))}
    fit_ids = declared_ids(fit_raw)
    early_ids = declared_ids(early_raw)
    excluded_ids = [str(row.get("uid", "")) if isinstance(row, dict) else "" for row in exclusions]
    unique_excluded = set(excluded_ids)
    duplicate_ids = sorted(uid for uid in unique_excluded if excluded_ids.count(uid) > 1)
    reasons: dict[str, int] = defaultdict(int)
    excluded_train: set[str] = set()
    excluded_val: set[str] = set()
    unknown_original = []
    side_mismatch = []
    missing_uid = []
    missing_reason = []
    missing_metadata = {"source_video_id": [], "text": []}
    metadata_mismatch = {"source_video_id": [], "text": []}
    anchor_count_issues = []
    rejected_anchor_clip_count = 0
    rejected_clips_with_observed_anchors = 0
    exclusion_records = []
    for row in exclusions:
        if not isinstance(row, dict):
            missing_uid.append(repr(row))
            missing_reason.append(repr(row))
            continue
        uid = str(row.get("uid", ""))
        if not uid:
            missing_uid.append(uid or "<empty>")
        reason = str(row.get("reason", "")).strip()
        if not reason:
            missing_reason.append(uid or "<empty>")
            reason = "<missing>"
        reasons[reason] += 1
        original_side = row.get("original_split")
        # V3 writes counts as *_frames; accept the earlier *_frame_count
        # spelling too so archived diagnostic manifests remain readable.
        direct = row.get("direct_anchor_frames", row.get("direct_anchor_frame_count"))
        fallback = row.get("fallback_anchor_frames", row.get("fallback_anchor_frame_count"))
        interpolated = row.get("interpolated_anchor_frames", row.get("interpolated_anchor_frame_count"))
        unresolved = row.get("unresolved_anchor_frames", row.get("unresolved_anchor_frame_count"))
        total_anchors = row.get("total_anchor_frames", row.get("total_anchor_frame_count"))
        resampled_frames = row.get("resampled_frame_count")
        anchor_mode = row.get("anchor_mode")
        rejected_for_anchor_gate = (
            anchor_mode == "unusable"
            or reason == "fewer_than_two_reliable_nose_and_both_shoulder_frames"
        )
        exclusion_records.append({
            "uid": uid or None,
            "source_video_id": row.get(group_field) if group_field else None,
            "original_split": original_side,
            "reason": reason or None,
            "anchor_mode": anchor_mode,
            "direct_anchor_frames": direct,
            "fallback_anchor_frames": fallback,
            "interpolated_anchor_frames": interpolated,
            "unresolved_anchor_frames": unresolved,
            "total_anchor_frames": total_anchors,
            "observed_anchor_frames": total_anchors,
            "canonicalization_output_status": "rejected_unresolved" if rejected_for_anchor_gate else "not_canonicalized",
            "resampled_frame_count": resampled_frames,
        })
        if group_field and not row.get(group_field):
            missing_metadata["source_video_id"].append(uid or "<empty>")
        if not row.get("text"):
            missing_metadata["text"].append(uid or "<empty>")
        original_meta = original_train_meta if original_side == "train" else original_val_meta if original_side == "validation" else {}
        if uid not in original_train_meta and uid not in original_val_meta:
            unknown_original.append(uid)
        elif original_side == "train" and uid in original_train_meta:
            excluded_train.add(uid)
        elif original_side in ("validation", "val") and uid in original_val_meta:
            excluded_val.add(uid)
        else:
            side_mismatch.append(uid)
        if uid in original_meta:
            original_group, original_text = original_meta[uid]
            if row.get(group_field) is not None and original_group is not None and str(row[group_field]) != str(original_group):
                metadata_mismatch["source_video_id"].append(uid)
            if row.get("text") is not None and original_text is not None and _canonical_text(str(row["text"])) != _canonical_text(str(original_text)):
                metadata_mismatch["text"].append(uid)
        anchor_counts = [direct, fallback, interpolated, unresolved, total_anchors, resampled_frames]
        if any(not isinstance(value, int) or isinstance(value, bool) or value < 0 for value in anchor_counts):
            anchor_count_issues.append(uid or "<empty>")
        elif direct + fallback != total_anchors:
            anchor_count_issues.append(uid or "<empty>")
        elif rejected_for_anchor_gate:
            # On a clip rejected by the minimum-anchor gate, direct/fallback
            # count observed anchors while unresolved counts the entire
            # canonical output (which was never produced). Those values may
            # overlap by design; they are not a partition of source frames.
            rejected_anchor_clip_count += 1
            rejected_clips_with_observed_anchors += int(total_anchors > 0)
            if unresolved != resampled_frames or interpolated != 0:
                anchor_count_issues.append(uid or "<empty>")
        elif direct + fallback + interpolated + unresolved != resampled_frames:
            anchor_count_issues.append(uid or "<empty>")
    duplicate_orig_train = len(original_train_meta) != len(original_train)
    duplicate_orig_val = len(original_val_meta) != len(original_validation)
    original_uid_overlap = set(original_train_meta) & set(original_val_meta)
    original_group_overlap = (
        {group for group, _ in original_train_meta.values() if group is not None}
        & {group for group, _ in original_val_meta.values() if group is not None}
    )
    expected_train = set(original_train_meta) - excluded_train
    expected_val = set(original_val_meta) - excluded_val
    effective_membership_mismatch = sorted(
        (effective_train_ids - expected_train) | (expected_train - effective_train_ids)
        | (effective_val_ids - expected_val) | (expected_val - effective_val_ids)
    )
    excluded_in_effective = sorted(unique_excluded & (effective_train_ids | effective_val_ids | sample_ids | fit_ids | early_ids))
    fail = bool(
        duplicate_ids or duplicate_orig_train or duplicate_orig_val or original_uid_overlap or original_group_overlap
        or unknown_original or side_mismatch or effective_membership_mismatch or excluded_in_effective
        or missing_uid or missing_reason or metadata_mismatch["source_video_id"] or metadata_mismatch["text"]
        or missing_metadata["source_video_id"] or missing_metadata["text"] or anchor_count_issues
    )
    reasons_by_side = {
        "train": sum(1 for row in exclusions if isinstance(row, dict) and row.get("original_split") == "train"),
        "validation": sum(1 for row in exclusions if isinstance(row, dict) and row.get("original_split") in ("validation", "val")),
    }
    return {
        "status": "fail" if fail else "pass",
        "excluded_count": len(exclusions),
        "excluded_by_original_split": reasons_by_side,
        "exclusions_by_reason": dict(sorted(reasons.items())),
        "excluded_uid_reasons": exclusion_records,
        "original_train_count": len(original_train_meta),
        "original_validation_count": len(original_val_meta),
        "effective_train_count": len(effective_train_ids),
        "effective_validation_count": len(effective_val_ids),
        "duplicate_exclusion_uid_count": len(duplicate_ids),
        "exclusion_missing_uid_count": len(missing_uid),
        "exclusion_missing_reason_count": len(missing_reason),
        "exclusion_missing_source_video_metadata_count": len(missing_metadata["source_video_id"]),
        "exclusion_missing_text_metadata_count": len(missing_metadata["text"]),
        "excluded_uid_unknown_to_original_split_count": len(unknown_original),
        "excluded_original_side_mismatch_count": len(side_mismatch),
        "excluded_source_video_metadata_mismatch_count": len(metadata_mismatch["source_video_id"]),
        "excluded_text_metadata_mismatch_count": len(metadata_mismatch["text"]),
        "exclusion_anchor_count_inconsistency_count": len(anchor_count_issues),
        "rejected_anchor_gate_clip_count": rejected_anchor_clip_count,
        "rejected_anchor_gate_clips_with_observed_anchors": rejected_clips_with_observed_anchors,
        "anchor_count_semantics": (
            "direct/fallback are observed source-anchor counts. For a clip rejected by the minimum-anchor gate, "
            "unresolved_anchor_frames counts the full canonical output that was not produced and can overlap "
            "observed anchors; accepted canonical clips use a disjoint frame accounting."
        ),
        "effective_membership_mismatch_count": len(effective_membership_mismatch),
        "excluded_uid_still_in_effective_split_samples_or_fit_count": len(excluded_in_effective),
        "original_split_uid_overlap_count": len(original_uid_overlap),
        "original_split_source_group_overlap_count": len(original_group_overlap),
        "examples": {
            "unknown_original_uids": unknown_original[:10],
            "side_mismatch_uids": side_mismatch[:10],
            "missing_uid_rows": missing_uid[:10],
            "missing_reason_uids": missing_reason[:10],
            "missing_source_video_metadata_uids": missing_metadata["source_video_id"][:10],
            "missing_text_metadata_uids": missing_metadata["text"][:10],
            "source_video_metadata_mismatch_uids": metadata_mismatch["source_video_id"][:10],
            "text_metadata_mismatch_uids": metadata_mismatch["text"][:10],
            "anchor_count_issue_uids": anchor_count_issues[:10],
            "effective_membership_mismatch_uids": effective_membership_mismatch[:10],
            "excluded_still_present_uids": excluded_in_effective[:10],
        },
        "interpretation": "verifies exclusions preserve the original seeded split and no excluded UID enters training or evaluation",
    }


def _condition_summaries(condition_rows: dict[str, list[dict[str, Any]]],
                         per_sample: list[dict[str, Any]], groups: list[dict[str, Any]],
                         selected_ids: set[str] | None = None,
                         objective: dict[str, Any] | None = None) -> dict[str, Any]:
    def selected(row: dict[str, Any]) -> bool:
        return selected_ids is None or row.get("uid") in selected_ids
    return {
        name: {
            "overall": _aggregate([row for row in rows if selected(row)]),
            "groups": _aggregate_group_rows([row for row in per_sample if selected(row)], name, groups),
            "pooled_over_clips": _pooled_group_metrics(
                [row for row in per_sample if selected(row)], name, groups, objective
            ),
        }
        for name, rows in condition_rows.items()
    }


def _pooled_group_metrics(per_sample: list[dict[str, Any]], condition: str,
                          groups: list[dict[str, Any]],
                          objective: dict[str, Any] | None) -> dict[str, Any]:
    """Pool confidence-weighted errors over point-frames before balancing groups.

    This matches the run-level validation aggregation. The ordinary ``macro_mean``
    remains useful for clip-level paired comparisons, but it gives every clip equal
    weight and therefore is a different estimand.
    """
    pooled_groups: dict[str, Any] = {}
    for group in groups:
        metric_rows = [
            sample.get("conditions", {}).get(condition, {}).get("groups", {}).get(group["name"], {})
            for sample in per_sample
        ]

        def pooled(metric_name: str, weight_name: str) -> tuple[float | None, float, int]:
            numerator = 0.0
            denominator = 0.0
            supported = 0
            for metric in metric_rows:
                value = metric.get(metric_name)
                weight = metric.get(weight_name)
                if isinstance(value, (int, float)) and isinstance(weight, (int, float)) and weight > 0:
                    numerator += float(value) * float(weight)
                    denominator += float(weight)
                    supported += 1
            return (numerator / denominator if denominator else None, denominator, supported)

        position, position_weight, position_examples = pooled(
            "train_normalized_confidence_weighted_mse", "train_normalized_confidence_weight_sum"
        )
        velocity, velocity_weight, velocity_examples = pooled(
            "train_normalized_confidence_weighted_velocity_mse",
            "train_normalized_confidence_weighted_velocity_weight_sum",
        )
        group_summary: dict[str, Any] = {
            "normalized_position_mse": position,
            "normalized_velocity_mse": velocity,
            "position_confidence_weight_sum": position_weight,
            "velocity_confidence_weight_sum": velocity_weight,
            "position_supported_clips": position_examples,
            "velocity_supported_clips": velocity_examples,
        }
        if objective is not None and position is not None and velocity is not None:
            group_summary["selection_objective"] = position + objective["velocity_coefficient"] * velocity
        pooled_groups[group["name"]] = group_summary

    balanced_position = balanced_velocity = selection_score = None
    if objective is not None:
        group_position = {name: pooled_groups[name]["normalized_position_mse"] for name in objective["group_weights"]}
        group_velocity = {name: pooled_groups[name]["normalized_velocity_mse"] for name in objective["group_weights"]}
        if all(value is not None for value in group_position.values()):
            balanced_position = sum(objective["group_weights"][name] * group_position[name] for name in group_position)
        if all(value is not None for value in group_velocity.values()):
            balanced_velocity = sum(objective["group_weights"][name] * group_velocity[name] for name in group_velocity)
        if balanced_position is not None and balanced_velocity is not None:
            selection_score = balanced_position + objective["velocity_coefficient"] * balanced_velocity
    return {
        "aggregation": "confidence-weighted pooled point-frames within each component, then manifest component weights",
        "examples": len(per_sample),
        "groups": pooled_groups,
        "overall": {
            "group_balanced_normalized_position_mse": balanced_position,
            "group_balanced_normalized_velocity_mse": balanced_velocity,
            "group_balanced_selection_objective": selection_score,
        },
    }


def _fixed_set_audit(manifest: dict[str, Any], sample_ids: list[str]) -> dict[str, Any]:
    fixed = manifest.get("fixed_unseen_set")
    if not isinstance(fixed, dict) or not isinstance(fixed.get("uids"), list):
        return {"declared": False, "exact_manifest_coverage": False, "reproducible_selection_verified": False,
                "reason": "no fixed_unseen_set.uids list"}
    fixed_ids = [str(uid) for uid in fixed["uids"]]
    covered = set(fixed_ids).issubset(set(sample_ids)) and len(set(fixed_ids)) == len(fixed_ids)
    samples_equal_fixed = set(fixed_ids) == set(sample_ids) and len(fixed_ids) == len(sample_ids)
    selection_rule = fixed.get("selection_rule")
    seed = fixed.get("seed")
    split = manifest.get("split", {})
    universe_field = "original_validation" if fixed.get("selected_before_decode") and isinstance(split.get("original_validation"), list) else "validation"
    reproducible = None
    if selection_rule == "sha256_rank_by_uid" and seed is not None and isinstance(fixed.get("count"), int):
        val_rows = split.get(universe_field, []) or []
        val_uids = [str(row if isinstance(row, str) else row.get("uid", "")) for row in val_rows]
        val_uids = [uid for uid in val_uids if uid]
        ranked = sorted(val_uids, key=lambda uid: (hashlib.sha256(f"{seed}:{uid}".encode("utf-8")).hexdigest(), uid))
        expected = ranked[:fixed["count"]]
        reproducible = expected == fixed_ids
    val_rows = split.get(universe_field, []) or []
    validation_uids = [str(row if isinstance(row, str) else row.get("uid", "")) for row in val_rows]
    validation_uids = [uid for uid in validation_uids if uid]
    validation_universe_hash = hashlib.sha256("\n".join(sorted(validation_uids)).encode("utf-8")).hexdigest() if validation_uids else None
    declared_universe_count = fixed.get("selection_universe_count")
    declared_universe_hash = fixed.get("selection_universe_uid_sha256")
    universe_metadata_verified = None
    if declared_universe_count is not None or declared_universe_hash is not None:
        universe_metadata_verified = (
            declared_universe_count == len(validation_uids)
            and declared_universe_hash == validation_universe_hash
            and len(validation_uids) == len(set(validation_uids))
        )
        if universe_metadata_verified is False:
            reproducible = False
    effective_declared = fixed.get("effective_uids")
    missing_declared = fixed.get("missing_uids")
    actual_effective = sorted(set(fixed_ids) & set(sample_ids))
    actual_missing = sorted(set(fixed_ids) - set(sample_ids))
    effective_membership_verified = None
    if isinstance(effective_declared, list) and isinstance(missing_declared, list):
        effective_membership_verified = (
            sorted(str(uid) for uid in effective_declared) == actual_effective
            and sorted(str(uid) for uid in missing_declared) == actual_missing
            and set(str(uid) for uid in effective_declared).isdisjoint(str(uid) for uid in missing_declared)
            and set(str(uid) for uid in effective_declared) | set(str(uid) for uid in missing_declared) == set(fixed_ids)
        )
    return {
        "declared": True,
        "seed": seed,
        "selection_rule": selection_rule,
        "selection_universe_split_field": universe_field,
        "declared_count": len(fixed_ids),
        "requested_count": fixed.get("count"),
        "evaluated_count": len(sample_ids),
        "exact_manifest_coverage": covered,
        "sample_scope_is_fixed_subset_only": samples_equal_fixed,
        "additional_quantitative_examples": max(0, len(set(sample_ids) - set(fixed_ids))),
        "reproducible_selection_verified": reproducible,
        "selection_universe_count_declared": declared_universe_count,
        "selection_universe_count_computed": len(validation_uids),
        "selection_universe_uid_sha256_declared": declared_universe_hash,
        "selection_universe_uid_sha256_computed": validation_universe_hash,
        "selection_universe_metadata_verified": universe_metadata_verified,
        "effective_uids_declared": effective_declared,
        "missing_uids_declared": missing_declared,
        "effective_membership_verified": effective_membership_verified,
        "uid_sha256": hashlib.sha256("\n".join(fixed_ids).encode("utf-8")).hexdigest(),
        "missing_predictions": actual_missing,
        "additional_sample_uids": sorted(set(sample_ids) - set(fixed_ids))[:10],
    }


def evaluate(manifest_path: Path, topology_override: Path | None = None) -> dict[str, Any]:
    manifest_path = manifest_path.resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1:
        raise ValueError("Manifest schema_version must be 1")
    samples = manifest.get("samples")
    if not isinstance(samples, list) or not samples:
        raise ValueError("Manifest must contain a nonempty samples list")
    ids = [str(row.get("uid", "")) for row in samples]
    if any(not uid for uid in ids) or len(set(ids)) != len(ids):
        raise ValueError("Every sample needs a unique, nonempty uid")

    fixed_audit = _fixed_set_audit(manifest, ids)

    reference0, confidence0 = _load_reference(manifest_path.parent, samples[0]["reference"])
    groups = _load_groups(manifest_path.parent, topology_override or manifest.get("topology"), reference0.shape[1])
    normalizer = _load_normalizer(manifest_path.parent, manifest.get("normalizer"))
    objective = _objective_spec(manifest, groups)
    condition_rows: dict[str, list[dict[str, Any]]] = defaultdict(list)
    per_sample: list[dict[str, Any]] = []
    text_sensitivity: list[dict[str, Any]] = []

    for row in samples:
        uid = str(row["uid"])
        reference, confidence = _load_reference(manifest_path.parent, row["reference"])
        if reference.shape[1:] != reference0.shape[1:]:
            raise ValueError(f"Point/coordinate shape for {uid} differs from first sample: {reference.shape}")
        predictions = row.get("predictions")
        if not isinstance(predictions, dict) or "true_text" not in predictions:
            raise ValueError(f"Sample {uid} must have predictions.true_text")
        resample = bool(row.get("align_normalized_time", manifest.get("align_normalized_time", False)))
        sample_report: dict[str, Any] = {
            "uid": uid,
            "source_video_id": row.get("source_video_id"),
            "text": row.get("text"),
            "raw_frame_count": row.get("raw_frame_count"),
            "resampling_policy": row.get("resampling_policy"),
            "resampled_frame_count": row.get("resampled_frame_count", reference.shape[0]),
            "shape": list(reference.shape),
            "conditions": {},
        }
        for condition, pred_spec in predictions.items():
            prediction = _load_prediction(manifest_path.parent, pred_spec)
            alignment = "native"
            if prediction.shape != reference.shape:
                if not resample or prediction.shape[1:] != reference.shape[1:]:
                    raise ValueError(f"{uid}/{condition} shape mismatch {prediction.shape} vs {reference.shape}; enable normalized-time alignment only if intended")
                prediction = _resample(prediction, reference.shape[0])
                alignment = f"prediction resampled to {reference.shape[0]} frames over normalized clip time"
            confidence_use = confidence
            metrics_by_group = {}
            for group in groups:
                start, stop = group["start"], group["start"] + group["count"]
                cm = confidence_use[:, start:stop] if confidence_use is not None else None
                group_metrics = _pair_metrics(reference[:, start:stop], prediction[:, start:stop], cm, normalizer_for_group(normalizer, start, stop))
                group_weight = float(cm.sum()) if cm is not None else float(reference.shape[0] * group["count"])
                all_weight = float(confidence_use.sum()) if confidence_use is not None else float(reference.shape[0] * reference.shape[1])
                group_metrics["point_share"] = group["count"] / reference.shape[1]
                group_metrics["confidence_weight_share"] = group_weight / all_weight if all_weight else None
                metrics_by_group[group["name"]] = group_metrics
            all_metrics = _pair_metrics(reference, prediction, confidence_use, normalizer)
            if objective is not None and normalizer is not None:
                group_position = {
                    name: metrics_by_group[name].get("train_normalized_confidence_weighted_mse")
                    for name in objective["group_weights"]
                }
                group_velocity = {
                    name: metrics_by_group[name].get("train_normalized_confidence_weighted_velocity_mse")
                    for name in objective["group_weights"]
                }
                if all(value is not None for value in group_position.values()) and all(value is not None for value in group_velocity.values()):
                    balanced_position = sum(objective["group_weights"][name] * group_position[name] for name in group_position)
                    balanced_velocity = sum(objective["group_weights"][name] * group_velocity[name] for name in group_velocity)
                    all_metrics["group_balanced_normalized_position_mse"] = float(balanced_position)
                    all_metrics["group_balanced_normalized_velocity_mse"] = float(balanced_velocity)
                    all_metrics["group_balanced_selection_objective"] = float(
                        balanced_position + objective["velocity_coefficient"] * balanced_velocity
                    )
                    all_metrics["group_balanced_normalized_position_mse_by_group"] = group_position
                    all_metrics["group_balanced_normalized_velocity_mse_by_group"] = group_velocity
                    # This clip-level score supports paired clip/source-group bootstrap.
                    # The pooled run-level score is computed separately below.
                    all_metrics["group_balanced_selection_objective_per_clip"] = all_metrics["group_balanced_selection_objective"]
            result = {"overall": all_metrics, "groups": metrics_by_group, "alignment": alignment}
            sample_report["conditions"][condition] = result
            split_group_field = manifest.get("split", {}).get("group_field", "source_video_id")
            condition_rows[condition].append({
                "uid": uid,
                "source_video_id": row.get(split_group_field),
                **all_metrics,
                "confidence_weighted_motion_ratio_prediction_to_reference": all_metrics.get("motion", {}).get("confidence_weighted_motion_ratio_prediction_to_reference"),
            })
        if "shuffled_text" in predictions:
            counter_text = row.get("counterfactual_text")
            true_text = row.get("text")
            if not counter_text:
                sensitivity_status = "incomplete: counterfactual_text missing"
            elif true_text and _canonical_text(counter_text) == _canonical_text(str(true_text)):
                sensitivity_status = "invalid: counterfactual text equals true text"
            else:
                sensitivity_status = "measured"
            true_result = sample_report["conditions"]["true_text"]["overall"]
            shuffled_result = sample_report["conditions"]["shuffled_text"]["overall"]
            if objective is not None and normalizer is not None:
                metric_key = "group_balanced_selection_objective_per_clip"
            elif normalizer is not None:
                metric_key = "train_normalized_confidence_weighted_mse"
            else:
                metric_key = "confidence_weighted_raw_rmse"
            true_score, shuffled_score = true_result.get(metric_key), shuffled_result.get(metric_key)
            sensitivity = {
                "uid": uid,
                "status": sensitivity_status,
                "true_text": true_text,
                "counterfactual_text": counter_text,
                "comparison_metric": metric_key,
                "true_text_score": true_score,
                "shuffled_text_score": shuffled_score,
                "shuffled_minus_true_score": (shuffled_score - true_score) if true_score is not None and shuffled_score is not None else None,
                "true_text_better": bool(true_score < shuffled_score) if true_score is not None and shuffled_score is not None else None,
                "prediction_output_difference_by_group": {},
            }
            true_array = _load_prediction(manifest_path.parent, predictions["true_text"])
            shuffled_array = _load_prediction(manifest_path.parent, predictions["shuffled_text"])
            if true_array.shape != shuffled_array.shape and resample and true_array.shape[1:] == shuffled_array.shape[1:]:
                shuffled_array = _resample(shuffled_array, true_array.shape[0])
            if true_array.shape == shuffled_array.shape:
                for group in groups:
                    start, stop = group["start"], group["start"] + group["count"]
                    sensitivity["prediction_output_difference_by_group"][group["name"]] = float(np.sqrt(np.mean(np.square(true_array[:, start:stop] - shuffled_array[:, start:stop]))))
            text_sensitivity.append(sensitivity)
        per_sample.append(sample_report)

    split_audit = _split_audit(manifest, samples)
    exclusion_audit = _canonicalization_exclusion_audit(manifest, samples)
    split_audit["canonicalization_exclusion_audit_status"] = exclusion_audit.get("status", "unverified")
    if exclusion_audit.get("status") == "fail":
        split_audit["status"] = "fail"
    elif exclusion_audit.get("status") == "unverified" and exclusion_audit.get("excluded_count", 0) > 0:
        if split_audit.get("status") == "pass":
            split_audit["status"] = "partial"
    counterfactual_audit = _counterfactual_audit(manifest, samples)
    fixed_ids = [str(uid) for uid in manifest.get("fixed_unseen_set", {}).get("uids", [])]
    sample_texts = [_canonical_text(str(row["text"])) for row in samples if row.get("text")]
    text_by_uid = {str(row["uid"]): _canonical_text(str(row["text"])) for row in samples if row.get("uid") and row.get("text")}
    fixed_texts = [text_by_uid[uid] for uid in fixed_ids if uid in text_by_uid]
    validation_rows = manifest.get("split", {}).get("validation", []) or []
    validation_texts = [
        _canonical_text(str(row.get("text", ""))) for row in validation_rows
        if isinstance(row, dict) and row.get("text")
    ]
    raw_frame_counts = [row.get("raw_frame_count") for row in samples if isinstance(row.get("raw_frame_count"), int)]
    resampling_policies = sorted({str(row.get("resampling_policy")) for row in samples if row.get("resampling_policy")})
    model_condition = condition_rows.get("true_text", [])
    seed_value = fixed_audit.get("seed")
    if not isinstance(seed_value, int):
        seed_value = int(hashlib.sha256(manifest_path.read_bytes()).hexdigest()[:8], 16)
    if objective is not None and normalizer is not None:
        metric = "group_balanced_selection_objective_per_clip"
        if split_audit.get("source_video_disjointness_status") == "pass":
            metric_status = "per-clip confidence-weighted group-balanced position + velocity objective; paired effects resample source-video groups. The pooled run-level metric is reported separately."
        elif split_audit.get("source_video_disjointness_status") == "fail":
            metric_status = "per-clip confidence-weighted group-balanced position + velocity objective; paired effects cluster by inferred candidate video ID because the declared split grouping failed audit, so intervals are descriptive only. The pooled run-level metric is reported separately."
        else:
            metric_status = "per-clip confidence-weighted group-balanced position + velocity objective; paired effects resample declared UID-derived source groups, but official video identity is unavailable, so intervals are descriptive only. The pooled run-level metric is reported separately."
    elif normalizer is not None:
        metric = "train_normalized_confidence_weighted_mse"
        metric_status = "fallback all-point normalized MSE; objective metadata unavailable, so this is not the training selection score"
    else:
        metric = "confidence_weighted_raw_rmse"
        metric_status = "raw-space fallback; train normalizer/objective unavailable"
    fixed_id_set = set(fixed_ids)

    def baseline_comparison(selected_ids: set[str] | None, seed_offset: int) -> dict[str, Any]:
        selected_model = [row for row in model_condition if selected_ids is None or row["uid"] in selected_ids]
        result = {}
        baseline_aliases = (
            ("zero_pose", ("zero_pose",)),
            ("train_frame_mean", ("train_frame_mean",)),
            ("semantic_retrieval", ("semantic_retrieval", "retrieval", "semantic_nearest_training_clip")),
        )
        for baseline_index, (baseline_name, aliases) in enumerate(baseline_aliases):
            rows = []
            for alias in aliases:
                if condition_rows.get(alias):
                    rows = [row for row in condition_rows[alias] if selected_ids is None or row["uid"] in selected_ids]
                    break
            if rows and selected_model:
                result[baseline_name] = _paired_difference(selected_model, rows, metric, seed_value + seed_offset + baseline_index, split_audit.get("status", "unverified"))
            else:
                result[baseline_name] = {"available": False}
        return result

    def text_sensitivity_summary(selected_ids: set[str] | None, seed_offset: int) -> dict[str, Any]:
        relevant = [row for row in text_sensitivity if selected_ids is None or row["uid"] in selected_ids]
        valid = [row for row in relevant if row["status"] == "measured" and row["true_text_better"] is not None]
        selected_model = [row for row in model_condition if selected_ids is None or row["uid"] in selected_ids]
        selected_shuffle = [row for row in condition_rows.get("shuffled_text", []) if selected_ids is None or row["uid"] in selected_ids]
        return {
            "measured_examples": len(valid),
            "paired_comparison": _paired_difference(selected_model, selected_shuffle, metric, seed_value + seed_offset, split_audit.get("status", "unverified")),
            "examples": relevant,
        }

    paired_condition_results = []
    comparison_specs = manifest.get("paired_condition_comparisons", [])
    if comparison_specs and not isinstance(comparison_specs, list):
        raise ValueError("paired_condition_comparisons must be a list")
    for index, spec in enumerate(comparison_specs):
        if not isinstance(spec, dict):
            raise ValueError(f"paired_condition_comparisons[{index}] must be an object")
        left_name = str(spec.get("left_condition", ""))
        right_name = str(spec.get("right_condition", ""))
        if not left_name or not right_name or left_name == right_name:
            raise ValueError(f"paired_condition_comparisons[{index}] needs distinct left_condition and right_condition")
        if left_name not in condition_rows or right_name not in condition_rows:
            raise ValueError(f"Paired comparison references missing conditions: {left_name!r}, {right_name!r}")
        scope = str(spec.get("scope", "all_samples"))
        if scope not in ("all_samples", "fixed_unseen_set"):
            raise ValueError(f"Unknown paired comparison scope {scope!r}")
        selected_compare_ids = fixed_id_set if scope == "fixed_unseen_set" else None
        comparison_metrics = [
            "group_balanced_selection_objective_per_clip",
            "confidence_weighted_motion_ratio_prediction_to_reference",
        ]
        if objective is None or normalizer is None:
            comparison_metrics = ["train_normalized_confidence_weighted_mse", "confidence_weighted_motion_ratio_prediction_to_reference"] if normalizer else ["confidence_weighted_raw_rmse", "confidence_weighted_motion_ratio_prediction_to_reference"]
        paired_metrics = {}
        for metric_index, metric_name in enumerate(comparison_metrics):
            left_rows = [row for row in condition_rows[left_name] if selected_compare_ids is None or row["uid"] in selected_compare_ids]
            right_rows = [row for row in condition_rows[right_name] if selected_compare_ids is None or row["uid"] in selected_compare_ids]
            paired_metrics[metric_name] = _paired_difference(
                left_rows, right_rows, metric_name,
                seed_value + 2000 + index * 10 + metric_index,
                split_audit.get("status", "unverified"),
            )
        paired_condition_results.append({
            "name": str(spec.get("name", f"{left_name}_vs_{right_name}")),
            "left_condition": left_name,
            "right_condition": right_name,
            "scope": scope,
            "difference_direction": "positive means right_condition has a larger metric than left_condition; for error metrics that means worse fit, for motion ratio it means more motion",
            "metrics": paired_metrics,
        })

    baseline_results = baseline_comparison(None, 0)
    fixed_baselines = baseline_comparison(fixed_id_set, 101) if fixed_id_set else {}
    shuffle_summary = text_sensitivity_summary(None, 17)
    fixed_shuffle_summary = text_sensitivity_summary(fixed_id_set, 117) if fixed_id_set else {}
    fit_ids_raw = manifest.get("training_uids_used")
    train_ids = sorted(str(row if isinstance(row, str) else row.get("uid", "")) for row in fit_ids_raw or [])
    train_ids = [uid for uid in train_ids if uid]
    normalizer_spec = manifest.get("normalizer")
    normalizer_audit = {"status": "not_provided"}
    if normalizer is not None:
        if not isinstance(normalizer_spec, dict) or normalizer_spec.get("fit_split") != "train":
            normalizer_audit = {"status": "unverified", "reason": "normalizer manifest does not declare fit_split=train"}
        elif normalizer_spec.get("fit_uid_sha256") and train_ids:
            actual_train_hash = hashlib.sha256("\n".join(train_ids).encode("utf-8")).hexdigest()
            declared_train_hash = str(normalizer_spec["fit_uid_sha256"])
            normalizer_audit = {
                "status": "pass" if train_ids and declared_train_hash == actual_train_hash else "fail",
                "fit_split": "train",
                "declared_train_uid_sha256": declared_train_hash,
                "manifest_train_uid_sha256": actual_train_hash,
                "train_uid_count": len(train_ids),
            }
        else:
            normalizer_audit = {"status": "unverified", "fit_split": "train", "reason": "training UID list or normalizer UID hash not supplied"}
    return {
        "title": "Fixed-set ISL text-to-pose evaluation",
        "manifest": str(manifest_path),
        "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "dataset": manifest.get("dataset"),
        "model_arm": manifest.get("model_arm"),
        "evaluation_status": manifest.get("evaluation_status", "unspecified in manifest"),
        "selected_for_follow_up": manifest.get("selected_for_follow_up"),
        "sample_count": len(samples),
        "sentence_coverage": {
            "quantitative_sample_unique_sentence_count": len(set(sample_texts)),
            "quantitative_sample_duplicate_sentence_count": len(sample_texts) - len(set(sample_texts)),
            "fixed_subset_unique_sentence_count": len(set(fixed_texts)),
            "fixed_subset_duplicate_sentence_count": len(fixed_texts) - len(set(fixed_texts)),
            "outer_validation_unique_sentence_count": len(set(validation_texts)),
            "outer_validation_duplicate_sentence_count": len(validation_texts) - len(set(validation_texts)),
        },
        "temporal_metadata_coverage": {
            "raw_frame_count_known": len(raw_frame_counts),
            "sample_count": len(samples),
            "raw_frame_count_min": min(raw_frame_counts) if raw_frame_counts else None,
            "raw_frame_count_max": max(raw_frame_counts) if raw_frame_counts else None,
            "resampling_policies": resampling_policies,
        },
        "conditions": _condition_summaries(condition_rows, per_sample, groups, objective=objective),
        "fixed_unseen_subset": {
            "uids": fixed_ids,
            "sample_count": sum(uid in {row["uid"] for row in per_sample} for uid in fixed_ids),
            "conditions": _condition_summaries(condition_rows, per_sample, groups, fixed_id_set, objective),
            "text_sensitivity": fixed_shuffle_summary,
            "baseline_comparison": fixed_baselines,
        },
        "fixed_unseen_set": fixed_audit,
        "split_audit": split_audit,
        "canonicalization_exclusion_audit": exclusion_audit,
        "counterfactual_caption_audit": counterfactual_audit,
        "normalizer_audit": normalizer_audit,
        "paired_comparison_metric": {"name": metric, "status": metric_status, "objective": objective},
        "text_sensitivity": {
            "metric": metric,
            **shuffle_summary,
            "interpretation": "tests whether true text changes the pose output and improves pose fit against shuffled text; it does not establish sign correctness",
        },
        "baseline_comparison": baseline_results,
        "paired_condition_comparisons": paired_condition_results,
        "human_intelligibility": {"status": "not assessed", "required_evidence": "multiple fluent ISL signers independently review randomized clips without seeing source text; capture meaning recovery, lexical correctness, grammar/naturalness, and comprehension agreement"},
        "per_sample": per_sample,
        "notes": [
            "Raw coordinate errors across components can use different scales; inspect train-normalized metrics when the training normalizer is supplied.",
            "Motion values describe movement amount and framewise motion fit. They do not establish that the correct ISL signs were produced.",
            "A source-video-disjoint split does not prove signer-disjoint generalization unless signer IDs are included and checked.",
        ],
    }


def normalizer_for_group(normalizer: tuple[np.ndarray, np.ndarray] | None, start: int, stop: int):
    if normalizer is None:
        return None
    mean, std = normalizer
    if mean.ndim >= 2 and mean.shape[-2] >= stop:
        return mean[start:stop], std[start:stop]
    return normalizer


def _aggregate_group_rows(per_sample: list[dict[str, Any]], condition: str,
                          groups: list[dict[str, Any]]) -> dict[str, Any]:
    result = {}
    for group in groups:
        rows = []
        for sample in per_sample:
            metric = sample.get("conditions", {}).get(condition, {}).get("groups", {}).get(group["name"])
            if metric:
                rows.append({"uid": sample["uid"], **metric})
        result[group["name"]] = _aggregate(rows)
    return result


def _paired_difference(true_rows: list[dict[str, Any]], other_rows: list[dict[str, Any]],
                       metric: str, seed: int, source_audit_status: str = "unverified") -> dict[str, Any]:
    true_by_id = {row["uid"]: row for row in true_rows}
    other_by_id = {row["uid"]: row for row in other_rows}
    common = sorted(set(true_by_id) & set(other_by_id))
    # Positive values mean the true-text model's error is lower.
    paired = [
        (uid, float(other_by_id[uid][metric] - true_by_id[uid][metric]),
         other_by_id[uid].get("source_video_id") or true_by_id[uid].get("source_video_id"))
        for uid in common
        if other_by_id[uid].get(metric) is not None and true_by_id[uid].get(metric) is not None
    ]
    differences = np.asarray([delta for _, delta, _ in paired], dtype=np.float64)
    if differences.size == 0:
        return {"metric": metric, "paired_examples": 0, "mean_other_minus_true": None,
                "median_other_minus_true": None, "true_text_better_count": 0,
                "true_text_better_fraction": None, "bootstrap_95pct_ci_mean": None,
                "independent_source_groups": 0, "bootstrap_cluster_field": None,
                "generalization_ci_status": "unverified"}
    has_groups = all(group is not None for _, _, group in paired)
    inferred_bases = {uid: _uid_video_base(uid) for uid, _, _ in paired}
    has_inferred_bases = all(value is not None for value in inferred_bases.values())
    if source_audit_status == "fail" and has_inferred_bases:
        cluster_field = "candidate UID video base (inferred; split audit failed)"
    elif source_audit_status != "pass" and has_groups:
        cluster_field = "source_video_id (UID-derived; provenance unverified)"
    else:
        cluster_field = "source_video_id" if has_groups else "uid (source IDs missing)"
    clusters: dict[str, list[float]] = defaultdict(list)
    for uid, delta, group in paired:
        if source_audit_status == "fail" and has_inferred_bases:
            cluster_key = str(inferred_bases[uid])
        else:
            cluster_key = str(group) if group is not None else uid
        clusters[cluster_key].append(delta)
    cluster_means = np.asarray([np.mean(values) for values in clusters.values()], dtype=np.float64)
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, cluster_means.size, size=(10000, cluster_means.size))
    means = cluster_means[draws].mean(axis=1)
    if source_audit_status == "pass" and has_groups:
        ci_status = "source-video-clustered; all supplied split checks passed; signer independence remains unverified"
    elif source_audit_status == "fail":
        ci_status = "descriptive only; leakage audit failed, so this interval cannot support unseen-sentence generalization"
    elif source_audit_status == "partial":
        ci_status = "descriptive only; declared source IDs are UID-inferred and not authoritatively verified, so this interval cannot support unseen-source generalization"
    else:
        ci_status = "descriptive only; leakage audit is incomplete, so this interval cannot support unseen-sentence generalization"
    return {
        "metric": metric,
        "paired_examples": int(differences.size),
        "independent_source_groups": int(cluster_means.size) if has_groups and source_audit_status == "pass" else None,
        "declared_bootstrap_cluster_count": int(cluster_means.size),
        "bootstrap_cluster_count": int(cluster_means.size),
        "bootstrap_cluster_field": cluster_field,
        "split_audit_status": source_audit_status,
        "generalization_ci_status": ci_status,
        "mean_other_minus_true": float(cluster_means.mean()),
        "median_other_minus_true": float(np.median(cluster_means)),
        "sample_macro_mean_other_minus_true": float(differences.mean()),
        "true_text_better_count": int((differences > 0).sum()),
        "true_text_better_fraction": float((differences > 0).mean()),
        "bootstrap_95pct_ci_mean": [float(value) for value in np.percentile(means, [2.5, 97.5])],
        "positive_delta_means": "true-text model has lower error than the comparison condition",
    }


def _markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Fixed-set ISL text-to-pose evaluation", "",
        f"- Samples: {report['sample_count']}",
        f"- Dataset: {report.get('dataset') or 'unspecified'}",
        f"- Evaluation status: {report.get('evaluation_status')}",
        f"- Model arm: {report.get('model_arm') or 'unspecified'}",
        f"- Fixed set exactly covered: {report['fixed_unseen_set'].get('exact_manifest_coverage', False)}",
        f"- Fixed qualitative cohort examples: {report['fixed_unseen_subset']['sample_count']}",
        f"- Distinct sentences in quantitative set: {report['sentence_coverage']['quantitative_sample_unique_sentence_count']}",
        f"- Distinct sentences in fixed cohort: {report['sentence_coverage']['fixed_subset_unique_sentence_count']}",
        f"- Original frame counts available: {report['temporal_metadata_coverage']['raw_frame_count_known']} / {report['temporal_metadata_coverage']['sample_count']}",
        f"- Resampling policies: {', '.join(report['temporal_metadata_coverage']['resampling_policies']) or 'not recorded'}",
        f"- Split audit: {report['split_audit'].get('status', 'unverified')}",
        f"- Human ISL intelligibility: {report['human_intelligibility']['status']}", "",
        "Pose and motion metrics are quantitative diagnostics. They do not establish that the generated signs are correct or understandable.", "",
        f"- Paired comparison metric: {report['paired_comparison_metric']['name']} ({report['paired_comparison_metric']['status']}).", "",
        "The condition table reports pooled confidence-weighted point-frame errors within each body/hand group, then applies the declared equal group weights. Paired tests use per-clip scores and resample the grouping described by the split audit.", "",
        "## Conditions", "",
        "| Condition | Group | Clips | Confidence coverage | Confidence weight share | Confidence weighted raw RMSE | Pooled normalized position MSE | Pooled normalized velocity MSE | Pooled balanced objective | Prediction motion median | Reference motion median | Pooled motion ratio |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for condition, detail in report["conditions"].items():
        for group, summary in [("overall", detail["overall"]), *detail["groups"].items()]:
            macro = summary.get("macro_mean", {})
            motion = summary.get("motion_macro_mean", {})
            pooled = detail.get("pooled_over_clips", {})
            pooled_row = pooled.get("overall", {}) if group == "overall" else pooled.get("groups", {}).get(group, {})
            pooled_motion = summary.get("motion_pooled", {})
            def fmt(value: Any) -> str:
                return "—" if value is None else f"{value:.5g}"
            if group == "overall":
                position_score = pooled_row.get("group_balanced_normalized_position_mse")
                velocity_score = pooled_row.get("group_balanced_normalized_velocity_mse")
                objective_score = pooled_row.get("group_balanced_selection_objective")
            else:
                position_score = pooled_row.get("normalized_position_mse")
                velocity_score = pooled_row.get("normalized_velocity_mse")
                objective_score = pooled_row.get("selection_objective")
            lines.append("| {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} |".format(
                condition, group, summary.get("examples", 0), fmt(macro.get("confidence_coverage_fraction")),
                fmt(macro.get("confidence_weight_share")),
                fmt(macro.get("confidence_weighted_raw_rmse")),
                fmt(position_score), fmt(velocity_score), fmt(objective_score),
                fmt(motion.get("prediction_median")), fmt(motion.get("reference_median")),
                fmt(pooled_motion.get("prediction_to_reference_mean_magnitude_ratio")),
            ))
    sensitivity = report["text_sensitivity"]
    if sensitivity["measured_examples"]:
        paired = sensitivity["paired_comparison"]
        ci = paired.get("bootstrap_95pct_ci_mean")
        sensitivity_line = f"- True text has lower error than shuffled text for {paired['true_text_better_count']} / {paired['paired_examples']} paired examples using `{paired['metric']}`."
        sensitivity_delta = f"- Mean shuffled minus true score: {paired.get('mean_other_minus_true')}; source-group bootstrap 95% CI: {ci}. {paired.get('generalization_ci_status')}"
    else:
        sensitivity_line = "- Not measured: this manifest has no valid true-text/shuffled-text prediction pairs."
        sensitivity_delta = ""
    lines += ["", "## Fixed set and split checks", "", f"- Fixed set: `{json.dumps(report['fixed_unseen_set'], ensure_ascii=False)}`", f"- Split audit: `{json.dumps(report['split_audit'], ensure_ascii=False)}`", f"- Canonicalization exclusions: `{json.dumps(report['canonicalization_exclusion_audit'], ensure_ascii=False)}`", f"- Counterfactual caption audit: `{json.dumps(report['counterfactual_caption_audit'], ensure_ascii=False)}`", f"- Normalizer audit: `{json.dumps(report['normalizer_audit'], ensure_ascii=False)}`", "", "## Text sensitivity", "", sensitivity_line, sensitivity_delta, "- This measures conditioning and pose fit only. It does not show that a fluent signer would understand the output.", "", "## Baselines", "", f"`{json.dumps(report['baseline_comparison'], ensure_ascii=False)}`", "", "## Limits", ""]
    lines.extend(f"- {note}" for note in report["notes"])
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path, help="JSON manifest describing a fixed held-out set and prediction files")
    parser.add_argument("--topology", type=Path, help="Override manifest topology with a JSON pose header")
    parser.add_argument("--out-json", type=Path, help="Output JSON report (default: <manifest stem>_evaluation.json)")
    parser.add_argument("--out-md", type=Path, help="Output Markdown report (default: <manifest stem>_evaluation.md)")
    args = parser.parse_args()
    report = evaluate(args.manifest, args.topology)
    base = args.manifest.resolve().parent
    json_path = args.out_json or base / f"{args.manifest.stem}_evaluation.json"
    md_path = args.out_md or base / f"{args.manifest.stem}_evaluation.md"
    json_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    md_path.write_text(_markdown(report), encoding="utf-8")
    print(json.dumps({"json_report": str(json_path.resolve()), "markdown_report": str(md_path.resolve()),
                      "sample_count": report["sample_count"], "conditions": sorted(report["conditions"]),
                      "fixed_set_exact": report["fixed_unseen_set"].get("exact_manifest_coverage"),
                      "split_audit": report["split_audit"].get("status")}, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, FileNotFoundError, json.JSONDecodeError) as exc:
        print(f"evaluation failed: {exc}", file=sys.stderr)
        raise SystemExit(2)
