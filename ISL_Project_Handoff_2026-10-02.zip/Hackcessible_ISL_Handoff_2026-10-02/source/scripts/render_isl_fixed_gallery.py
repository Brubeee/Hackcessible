"""Build a local animated gallery for the fixed ISL reference/prediction set.

The gallery gives each reference and prediction the same view and topology. It
is a visual inspection aid; it cannot determine whether an ISL signer would
understand the sequence.

Usage:
    python scripts/render_isl_fixed_gallery.py artifacts/manifest.json \
        --edges artifacts/skeleton_edges.npy --out artifacts/fixed_gallery.html
"""

from __future__ import annotations

import argparse
import base64
import html
import json
from pathlib import Path
from typing import Any

import numpy as np


def resolve(base: Path, value: str) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else (base / path).resolve()


def load_array(path: Path, key: str | None = None) -> np.ndarray:
    loaded = np.load(path, allow_pickle=False)
    if isinstance(loaded, np.lib.npyio.NpzFile):
        with loaded as archive:
            if key is None:
                if len(archive.files) != 1:
                    raise ValueError(f"Specify an array key for {path}; found {archive.files}")
                key = archive.files[0]
            if key not in archive.files:
                raise ValueError(f"{path} has keys {archive.files}; requested {key!r}")
            array = archive[key].copy()
    else:
        array = loaded
    array = np.asarray(array)
    if array.ndim == 2 and array.shape[-1] % 3 == 0:
        array = array.reshape(array.shape[0], array.shape[-1] // 3, 3)
    if array.ndim == 4 and array.shape[1] == 1:
        array = array[:, 0]
    if array.ndim != 3 or array.shape[-1] < 2 or not np.isfinite(array).all():
        raise ValueError(f"Expected finite (frames, points, coordinates>=2), got {array.shape} in {path}")
    return np.asarray(array, dtype="<f4")


def load_confidence(path: Path, pose_shape: tuple[int, ...], key: str | None = "confidence") -> np.ndarray:
    confidence = None
    loaded = np.load(path, allow_pickle=False)
    if isinstance(loaded, np.lib.npyio.NpzFile):
        with loaded as archive:
            if key and key in archive.files:
                confidence = archive[key].copy()
    if confidence is None:
        confidence = np.ones(pose_shape[:2], dtype=np.float32)
    confidence = np.asarray(confidence, dtype=np.float32)
    if confidence.ndim == 3 and confidence.shape[-1] == 1:
        confidence = confidence[..., 0]
    if confidence.shape != pose_shape[:2] or not np.isfinite(confidence).all():
        raise ValueError(f"Reference confidence must have shape {pose_shape[:2]}, got {confidence.shape} in {path}")
    return np.clip(confidence, 0.0, 1.0)


def encode_pose(array: np.ndarray) -> str:
    return base64.b64encode(np.ascontiguousarray(array, dtype="<f4").tobytes()).decode("ascii")


def js_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")


def _source_point_indices(point_count: int) -> np.ndarray:
    if point_count == 75:
        return np.asarray(list(range(33)) + list(range(501, 543)), dtype=np.int64)
    return np.arange(point_count, dtype=np.int64)


def _map_header_edges(header_path: Path, point_indices: np.ndarray) -> np.ndarray:
    header = json.loads(header_path.read_text(encoding="utf-8"))
    if not isinstance(header.get("components"), list):
        raise ValueError(f"Pose header has no components list: {header_path}")
    canonical_by_source = {int(source): index for index, source in enumerate(point_indices)}
    edge_pairs: set[tuple[int, int]] = set()
    component_aliases = {"POSE_LANDMARKS", "LEFT_HAND", "LEFT_HAND_LANDMARKS", "RIGHT_HAND", "RIGHT_HAND_LANDMARKS"}
    for component in header["components"]:
        if component.get("name") not in component_aliases:
            continue
        start = int(component.get("start", 0))
        count = int(component.get("count", 0))
        for limb in component.get("limbs", []):
            if not isinstance(limb, (list, tuple)) or len(limb) != 2:
                continue
            local_a, local_b = map(int, limb)
            if not (0 <= local_a < count and 0 <= local_b < count):
                continue
            source_a, source_b = start + local_a, start + local_b
            if source_a in canonical_by_source and source_b in canonical_by_source:
                edge_pairs.add(tuple(sorted((canonical_by_source[source_a], canonical_by_source[source_b]))))
    return np.asarray(sorted(edge_pairs), dtype=np.int64).reshape(-1, 2)


def _default_edges(point_count: int) -> np.ndarray:
    if point_count != 75:
        return np.empty((0, 2), dtype=np.int64)
    body = [(11, 12), (11, 13), (13, 15), (15, 17), (15, 19), (15, 21), (17, 19),
            (12, 14), (14, 16), (16, 18), (16, 20), (16, 22), (18, 20), (11, 23),
            (12, 24), (23, 24), (23, 25), (25, 27), (27, 29), (29, 31), (27, 31),
            (24, 26), (26, 28), (28, 30), (30, 32), (28, 32), (0, 1), (1, 2),
            (2, 3), (3, 7), (0, 4), (4, 5), (5, 6), (6, 8), (9, 10)]
    hand = [(0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6), (6, 7), (7, 8),
            (5, 9), (9, 10), (10, 11), (11, 12), (9, 13), (13, 14), (14, 15),
            (15, 16), (13, 17), (17, 18), (18, 19), (19, 20), (0, 17)]
    pairs = body + [(33 + a, 33 + b) for a, b in hand] + [(54 + a, 54 + b) for a, b in hand]
    return np.asarray(sorted({tuple(sorted(edge)) for edge in pairs}), dtype=np.int64)


def repair_edges(edges: np.ndarray, point_count: int, point_indices: np.ndarray,
                 header_path: Path | None) -> tuple[np.ndarray, list[str]]:
    notes: list[str] = []
    edge_pairs = {tuple(sorted(map(int, edge))) for edge in edges.tolist()}
    if header_path is not None:
        authoritative = _map_header_edges(header_path, point_indices)
        before = len(edge_pairs)
        edge_pairs.update(tuple(map(int, edge)) for edge in authoritative.tolist())
        if len(edge_pairs) > before:
            notes.append(f"added {len(edge_pairs) - before} connections mapped from PoseHeader limbs")
    default_pairs = {tuple(map(int, edge)) for edge in _default_edges(point_count).tolist()}
    ranges = ((0, 33, "body"), (33, 54, "left hand"), (54, 75, "right hand"))
    for start, stop, name in ranges:
        if stop > point_count:
            continue
        covered = any(start <= a < stop and start <= b < stop for a, b in edge_pairs)
        if not covered:
            fallback = {edge for edge in default_pairs if start <= edge[0] < stop and start <= edge[1] < stop}
            if fallback:
                edge_pairs.update(fallback)
                notes.append(f"restored {name} connections from standard 75-point topology because none were present")
    if any(index < 0 or index >= point_count for edge in edge_pairs for index in edge):
        raise ValueError(f"Topology index outside canonical point range 0..{point_count - 1}")
    return np.asarray(sorted(edge_pairs), dtype=np.int64).reshape(-1, 2), notes


def render_html(samples: list[dict[str, Any]], edges: np.ndarray, title: str, status: str) -> str:
    payload = js_json(samples)
    edge_payload = js_json(edges.astype(int).tolist())
    safe_title = title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return f'''<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{safe_title}</title>
<style>
:root{{color-scheme:light dark;font:15px system-ui,sans-serif}}body{{margin:0;padding:1rem;background:Canvas;color:CanvasText}}
h1{{font-size:1.2rem;margin:0 0 .4rem}}.note{{margin:.25rem 0 .8rem;color:CanvasText;opacity:.8}}.controls{{display:flex;gap:.75rem;align-items:center;flex-wrap:wrap;margin:.7rem 0}}
select,button{{font:inherit;padding:.35rem .55rem}}input[type=range]{{flex:1;min-width:180px}}output{{font-variant-numeric:tabular-nums}}
.panels{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem}}section{{min-width:0}}h2{{font-size:1rem;font-weight:500;margin:.3rem 0}}canvas{{width:100%;height:min(62vh,540px);display:block;background:color-mix(in srgb,CanvasText 5%,Canvas);border-radius:.4rem}}
.text{{padding:.6rem;border:1px solid color-mix(in srgb,CanvasText 20%,transparent);border-radius:.4rem;margin:.5rem 0;white-space:pre-wrap}}.text b{{display:block;font-size:.8rem;opacity:.7;margin-bottom:.2rem}}
@media(max-width:720px){{.panels{{grid-template-columns:1fr}}canvas{{height:46vh}}}}
</style>
<h1>{safe_title}</h1><p class="note">{html.escape(status)} · Visual pose comparison only; ISL meaning and grammar still need review by fluent signers.</p>
<div class="controls"><label for="sample">Fixed sample</label><select id="sample"></select><label for="condition">Prediction</label><select id="condition"><option value="true">True caption</option><option value="shuffled">Shuffled caption</option></select>
<button id="previous" type="button">Previous</button><button id="next" type="button">Next</button></div>
<div class="text"><b>Reference caption</b><span id="true-text"></span></div><div class="text"><b>Counterfactual caption</b><span id="counter-text"></span></div>
<div class="panels"><section><h2 id="reference-label">Reference</h2><canvas id="reference" aria-label="Reference skeleton"></canvas></section><section><h2 id="prediction-label">Prediction</h2><canvas id="prediction" aria-label="Predicted skeleton"></canvas></section></div>
<div id="metric-summary" class="note"></div><div class="controls"><button id="play" type="button">Play</button><label for="frame">Frame</label><input id="frame" type="range" min="0" max="0" value="0"><output id="frame-value" for="frame"></output><span id="shape"></span></div>
<script>
const samples={payload}, edges={edge_payload};
const samplePicker=document.getElementById('sample'), conditionPicker=document.getElementById('condition'), slider=document.getElementById('frame');
const frameValue=document.getElementById('frame-value'), shapeLabel=document.getElementById('shape');
const canvases=[document.getElementById('reference'),document.getElementById('prediction')];
const decoded=new Map();
function decode(text){{if(!decoded.has(text)){{const bytes=Uint8Array.from(atob(text),c=>c.charCodeAt(0));decoded.set(text,new Float32Array(bytes.buffer))}}return decoded.get(text)}}
for(let i=0;i<samples.length;i++){{const option=document.createElement('option');option.value=String(i);option.textContent=samples[i].uid;samplePicker.appendChild(option)}}
let timer=null;
function active(){{return samples[Number(samplePicker.value)||0]}}
function activePrediction(sample){{return conditionPicker.value==='shuffled'&&sample.shuffled?sample.shuffled:sample.prediction}}
function draw(canvas,sequence,frame,color,bounds,pointCount,coordCount,confidence){{
 const rect=canvas.getBoundingClientRect(),dpr=window.devicePixelRatio||1;if(!rect.width||!rect.height)return;
 canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);const c=canvas.getContext('2d');c.scale(dpr,dpr);
 const pad=24,w=rect.width-2*pad,h=rect.height-2*pad,rangeX=Math.max(bounds[2]-bounds[0],1e-8),rangeY=Math.max(bounds[3]-bounds[1],1e-8),s=Math.min(w/rangeX,h/rangeY);
 const pos=p=>{{const i=(frame*pointCount+p)*coordCount;return [pad+(sequence[i]-bounds[0])*s+(w-rangeX*s)/2,pad+h-((sequence[i+1]-bounds[1])*s+(h-rangeY*s)/2)]}};
 c.lineWidth=1.5;c.strokeStyle=color;c.globalAlpha=.72;
 for(const [a,b] of edges){{if(a>=pointCount||b>=pointCount||confidence[frame*pointCount+a]<.15||confidence[frame*pointCount+b]<.15)continue;const [x1,y1]=pos(a),[x2,y2]=pos(b);c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke()}}
 c.globalAlpha=1;c.fillStyle=color;for(let p=0;p<pointCount;p++){{if(confidence[frame*pointCount+p]<.15)continue;const [x,y]=pos(p);c.beginPath();c.arc(x,y,1.8,0,Math.PI*2);c.fill()}}
}}
function render(){{
 const sample=active();if(conditionPicker.value==='shuffled'&&!sample.shuffled)conditionPicker.value='true';
 const prediction=activePrediction(sample),reference=decode(sample.reference),pred=decode(prediction),confidence=decode(sample.confidence);
 const frameCount=sample.frames,pointCount=sample.points,coordCount=sample.coords,frame=Math.min(Number(slider.value)||0,frameCount-1);
 const bounds=[Infinity,Infinity,-Infinity,-Infinity];
 for(const seq of [reference,pred])for(let f=0;f<frameCount;f++)for(let p=0;p<pointCount;p++){{const k=(f*pointCount+p)*coordCount;bounds[0]=Math.min(bounds[0],seq[k]);bounds[1]=Math.min(bounds[1],seq[k+1]);bounds[2]=Math.max(bounds[2],seq[k]);bounds[3]=Math.max(bounds[3],seq[k+1])}}
 draw(canvases[0],reference,frame,'#2563eb',bounds,pointCount,coordCount,confidence);draw(canvases[1],pred,frame,'#e4572e',bounds,pointCount,coordCount,confidence);
 document.getElementById('true-text').textContent=sample.text||'Caption unavailable';document.getElementById('counter-text').textContent=sample.counterfactualText||'Counterfactual caption unavailable';
 document.getElementById('prediction-label').textContent=conditionPicker.value==='shuffled'?'Shuffled caption prediction':'True caption prediction';
 const m=sample.metrics||{{}},fmt=value=>Number.isFinite(value)?Number(value).toPrecision(4):'not supplied';
 document.getElementById('metric-summary').textContent=`Confidence mask: shared from reference at 0.15 · normalized position MSE: ${{fmt(m.group_balanced_normalized_position_mse)}} · normalized velocity MSE: ${{fmt(m.group_balanced_normalized_velocity_mse)}} · selection objective: ${{fmt(m.group_balanced_selection_objective)}}`;
 frameValue.value=`${{frame+1}} / ${{frameCount}}`;shapeLabel.textContent=`${{pointCount}} points · ${{edges.length}} connections · shared XY scale`;
}}
function selectSample(index){{samplePicker.value=String((index+samples.length)%samples.length);slider.value='0';render()}}
samplePicker.addEventListener('change',()=>{{slider.value='0';render()}});conditionPicker.addEventListener('change',render);slider.addEventListener('input',render);window.addEventListener('resize',render);
document.getElementById('previous').addEventListener('click',()=>selectSample(Number(samplePicker.value)-1));document.getElementById('next').addEventListener('click',()=>selectSample(Number(samplePicker.value)+1));
document.getElementById('play').addEventListener('click',event=>{{if(timer){{clearInterval(timer);timer=null;event.currentTarget.textContent='Play';return}}event.currentTarget.textContent='Pause';timer=setInterval(()=>{{slider.value=(Number(slider.value)+1)%active().frames;render()}},1000/12)}});
conditionPicker.disabled=!samples.some(sample=>sample.shuffled);slider.max=samples[0].frames-1;samplePicker.value='0';render();
</script></html>'''


def build_gallery(manifest_path: Path, edges_path: Path, evaluation_path: Path | None = None,
                  header_path: Path | None = None, point_indices_path: Path | None = None) -> tuple[str, list[str]]:
    manifest_path = manifest_path.resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    fixed = manifest.get("fixed_unseen_set", {}).get("uids", [])
    samples_by_uid = {str(row.get("uid")): row for row in manifest.get("samples", [])}
    if not fixed:
        raise ValueError("Manifest does not declare fixed_unseen_set.uids")
    missing = [str(uid) for uid in fixed if str(uid) not in samples_by_uid]
    if missing:
        raise ValueError(f"Fixed set predictions missing for {missing}")
    edges = np.asarray(np.load(edges_path, allow_pickle=False), dtype=np.int64)
    if edges.ndim != 2 or edges.shape[1] != 2 or np.any(edges < 0):
        raise ValueError(f"Expected an integer edge array shaped (E,2); got {edges.shape}")

    report_by_uid: dict[str, Any] = {}
    if evaluation_path:
        evaluation = json.loads(evaluation_path.read_text(encoding="utf-8"))
        report_by_uid = {str(row.get("uid")): row for row in evaluation.get("per_sample", [])}
    output_samples = []
    point_count = None
    frame_count = None
    point_indices = None
    for uid in map(str, fixed):
        row = samples_by_uid[uid]
        ref_spec = row["reference"]
        ref_path = resolve(manifest_path.parent, ref_spec["path"])
        reference = load_array(ref_path, ref_spec.get("pose_key", "pose"))
        confidence = load_confidence(ref_path, reference.shape, ref_spec.get("confidence_key", "confidence"))
        prediction_spec = row["predictions"]["true_text"]
        prediction_path = resolve(manifest_path.parent, prediction_spec if isinstance(prediction_spec, str) else prediction_spec["path"])
        prediction = load_array(prediction_path, None if isinstance(prediction_spec, str) else prediction_spec.get("key"))
        if prediction.shape != reference.shape:
            raise ValueError(f"{uid} reference/prediction shape mismatch: {reference.shape} vs {prediction.shape}")
        if point_count is None:
            point_count = reference.shape[1]
            index_path = point_indices_path
            if index_path is None and (manifest_path.parent / "point_indices.npy").is_file():
                index_path = manifest_path.parent / "point_indices.npy"
            point_indices = np.asarray(np.load(index_path, allow_pickle=False), dtype=np.int64) if index_path else _source_point_indices(point_count)
            if point_indices.shape != (point_count,):
                raise ValueError(f"point_indices must have shape ({point_count},), got {point_indices.shape}")
        elif reference.shape[1] != point_count:
            raise ValueError("All fixed samples must use the same number of points")
        if frame_count is None:
            frame_count = reference.shape[0]
        elif reference.shape[0] != frame_count:
            raise ValueError("All fixed samples must use the same number of frames")
        if edges.size and int(edges.max()) >= point_count:
            raise ValueError(f"Skeleton edge index {int(edges.max())} exceeds point count {point_count}")
        shuffled_encoded = None
        shuffled_spec = row["predictions"].get("shuffled_text")
        if shuffled_spec:
            shuffled_path = resolve(manifest_path.parent, shuffled_spec if isinstance(shuffled_spec, str) else shuffled_spec["path"])
            shuffled = load_array(shuffled_path, None if isinstance(shuffled_spec, str) else shuffled_spec.get("key"))
            if shuffled.shape != reference.shape:
                raise ValueError(f"{uid} shuffled prediction shape mismatch: {shuffled.shape} vs {reference.shape}")
            shuffled_encoded = encode_pose(shuffled)
        output_samples.append({
            "uid": uid,
            "text": row.get("text", ""),
            "counterfactualText": row.get("counterfactual_text", ""),
            "frames": int(reference.shape[0]),
            "points": int(reference.shape[1]),
            "coords": int(reference.shape[2]),
            "reference": encode_pose(reference),
            "confidence": encode_pose(confidence[..., None]),
            "prediction": encode_pose(prediction),
            "shuffled": shuffled_encoded,
            "metrics": report_by_uid.get(uid, {}).get("conditions", {}).get("true_text", {}).get("overall", {}),
        })
    edges, repair_notes = repair_edges(edges, int(point_count), point_indices, header_path)
    status = manifest.get("evaluation_status", "Evaluation status not supplied")
    if repair_notes:
        status += " · Topology repair: " + "; ".join(repair_notes)
    title = f"iSign fixed unseen set · {manifest.get('model_arm', 'model')}"
    return render_html(output_samples, edges, title, status), repair_notes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path, help="V3 manifest for one model arm")
    parser.add_argument("--edges", type=Path, required=True, help="skeleton_edges.npy from the V3 export")
    parser.add_argument("--header", type=Path, help="Authoritative pose_header.json used to restore source topology")
    parser.add_argument("--point-indices", type=Path, help="point_indices.npy mapping canonical output points to source points")
    parser.add_argument("--evaluation", type=Path, help="Optional evaluation JSON used for inspectable metrics metadata")
    parser.add_argument("--out", type=Path, required=True, help="Output standalone HTML gallery")
    args = parser.parse_args()
    html, repair_notes = build_gallery(args.manifest, args.edges, args.evaluation, args.header, args.point_indices)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(html, encoding="utf-8")
    print(json.dumps({"html": str(args.out.resolve()), "bytes": args.out.stat().st_size, "topology_repairs": repair_notes}, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, FileNotFoundError, json.JSONDecodeError) as exc:
        print(f"gallery failed: {exc}", file=__import__("sys").stderr)
        raise SystemExit(2)
