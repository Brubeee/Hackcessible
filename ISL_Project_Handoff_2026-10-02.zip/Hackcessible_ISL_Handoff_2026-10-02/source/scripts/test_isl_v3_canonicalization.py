"""Small NumPy checks for the confidence-guarded V3 anchor transform."""

from __future__ import annotations

import numpy as np

from isl_v3_canonicalization import canonicalize_one


def sample():
    pose = np.zeros((48, 576, 3), dtype=np.float32)
    confidence = np.ones((48, 576), dtype=np.float32)
    pose[:, 0] = [150.0, 50.0, 0.0]
    pose[:, 11] = [100.0, 100.0, 0.0]
    pose[:, 12] = [200.0, 100.0, 0.0]
    pose[:, 23] = [110.0, 250.0, 0.0]
    pose[:, 24] = [190.0, 250.0, 0.0]
    pose[:, 501] = [75.0, 160.0, 0.0]
    return pose, confidence


def run() -> None:
    pose, confidence = sample()
    canonical, canonical_conf, detail = canonicalize_one(pose, confidence)
    assert canonical.shape == (48, 75, 3) and canonical_conf.shape == (48, 75)
    assert detail["anchor_mode"] == "nose_shoulders"
    assert detail["direct_anchor_frames"] == 48
    assert detail["interpolated_anchor_frames"] == 0
    assert np.isfinite(canonical).all() and np.allclose(canonical[:, 0, 1], -1.0)
    assert np.allclose(canonical_conf[:, 0], 1.0)

    pose, confidence = sample()
    confidence[:, 0] = 0.0
    canonical, canonical_conf, detail = canonicalize_one(pose, confidence)
    assert detail["anchor_mode"] == "shoulder_width"
    assert detail["fallback_anchor_frames"] == 48
    assert np.allclose(canonical_conf[:, 0], 0.0)
    assert np.allclose(canonical_conf[:, 11], 0.75)

    pose, confidence = sample()
    confidence[:, 12] = 0.0
    canonical, _, detail = canonicalize_one(pose, confidence)
    assert detail["anchor_mode"] == "nose_left_shoulder"
    assert np.isfinite(canonical).all()

    pose, confidence = sample()
    confidence[:, [0, 11, 12]] = 0.0
    confidence[:, 23:25] = 1.0
    canonical, _, detail = canonicalize_one(pose, confidence)
    assert detail["anchor_mode"] == "hip_width"
    assert np.isfinite(canonical).all()

    pose, confidence = sample()
    confidence[:] = 0.0
    canonical, canonical_conf, detail = canonicalize_one(pose, confidence)
    assert canonical is None and canonical_conf is None
    assert detail["reason"] == "fewer_than_two_frames_with_any_consistent_confident_anchor_mode"

    pose, confidence = sample()
    confidence[:10, [0, 11, 12]] = 1.0
    confidence[10:, [0, 11, 12]] = 0.0
    canonical, canonical_conf, detail = canonicalize_one(pose, confidence)
    assert detail["anchor_mode"] == "nose_shoulders"
    assert detail["interpolated_anchor_frames"] == 38
    assert np.allclose(canonical_conf[10:, 33], 0.5)
    assert np.isfinite(canonical).all()

    print("V3 canonicalization checks passed: primary, shoulder fallback, one-shoulder fallback, hip fallback, exclusion, and interpolation.")


if __name__ == "__main__":
    run()
