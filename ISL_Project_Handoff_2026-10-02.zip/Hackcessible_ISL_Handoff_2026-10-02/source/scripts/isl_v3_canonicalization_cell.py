# Canonicalize body and hands, preserving the original V2 split before exclusions.
POINT_INDICES = np.asarray(list(range(33)) + list(range(501, 543)), dtype=np.int64)
assert len(POINT_INDICES) == 75 and len(set(POINT_INDICES.tolist())) == 75
TMAX, POINTS = 48, 75
MIN_ANCHOR_CONF = 0.15

# Freeze the exact V2 partition over all cached examples before canonicalization.
original_rows = rows.copy().reset_index(drop=True)
original_permutation = np.random.default_rng(SEED).permutation(len(original_rows))
original_val_count = max(1, int(round(len(original_rows) * 0.10)))
original_val_ix = original_permutation[:original_val_count]
original_train_ix = original_permutation[original_val_count:]
assert len(original_train_ix) == 1841 and len(original_val_ix) == 205
original_split_by_index = {int(i): 'validation' for i in original_val_ix}
original_split_by_index.update({int(i): 'train' for i in original_train_ix})

def canonicalize_one(raw_pose, raw_confidence, min_anchor_conf=MIN_ANCHOR_CONF):
    raw_pose = np.asarray(raw_pose, dtype=np.float32)
    raw_confidence = np.asarray(raw_confidence, dtype=np.float32)
    valid_coords = np.isfinite(raw_pose).all(axis=-1)
    safe_pose = np.nan_to_num(raw_pose, nan=0.0, posinf=0.0, neginf=0.0)
    point_conf = np.clip(np.nan_to_num(raw_confidence, nan=0.0, posinf=0.0, neginf=0.0), 0.0, 1.0)
    selected_pose = safe_pose[:, POINT_INDICES, :].copy()
    selected_conf = point_conf[:, POINT_INDICES].copy() * valid_coords[:, POINT_INDICES]
    center = (safe_pose[:, 11, :] + safe_pose[:, 12, :]) * 0.5
    nose = safe_pose[:, 0, :]
    scale = np.linalg.norm(nose[:, :2] - center[:, :2], axis=-1)
    anchors_ok = (point_conf[:, 0] >= min_anchor_conf) & (point_conf[:, 11] >= min_anchor_conf) & (point_conf[:, 12] >= min_anchor_conf)
    anchors_ok &= valid_coords[:, 0] & valid_coords[:, 11] & valid_coords[:, 12] & np.isfinite(scale) & (scale > 1e-4)
    good = np.flatnonzero(anchors_ok)
    anchor_names = {'nose': 0, 'left_shoulder': 11, 'right_shoulder': 12}
    finite_anchor_counts = {name: int(valid_coords[:, point].sum()) for name, point in anchor_names.items()}
    confident_anchor_counts = {
        name: int((valid_coords[:, point] & (point_conf[:, point] >= min_anchor_conf)).sum())
        for name, point in anchor_names.items()
    }
    anchor_info = {
        'anchor_mode': 'nose_both_shoulders',
        'threshold': float(min_anchor_conf),
        'finite_anchor_counts': finite_anchor_counts,
        'confident_anchor_counts': confident_anchor_counts,
        'primary_scale_valid_count': int(len(good)),
        'direct_anchor_frames': int(len(good)),
        'fallback_anchor_frames': 0,
        'interpolated_anchor_frames': 0,
        'unresolved_anchor_frames': int(TMAX),
        'total_anchor_frames': int(len(good)),
        'resampled_frame_count': int(raw_pose.shape[0]),
    }
    if len(good) < 2:
        anchor_info['anchor_mode'] = 'unusable'
        anchor_info['reason'] = 'fewer_than_two_reliable_nose_and_both_shoulder_frames'
        return None, None, anchor_info
    frame_ix = np.arange(raw_pose.shape[0])
    center_interp = np.stack([np.interp(frame_ix, good, center[good, axis]) for axis in range(3)], axis=-1)
    scale_interp = np.exp(np.interp(frame_ix, good, np.log(scale[good].clip(1e-4))))
    reliability = np.where(anchors_ok, 1.0, 0.5).astype(np.float32)
    canonical = (selected_pose - center_interp[:, None, :]) / scale_interp[:, None, None]
    selected_conf *= reliability[:, None]
    canonical = np.nan_to_num(canonical, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
    anchor_info['interpolated_anchor_frames'] = int(raw_pose.shape[0] - len(good))
    anchor_info['unresolved_anchor_frames'] = 0
    anchor_info['resampled_frame_count'] = int(raw_pose.shape[0])
    return canonical, selected_conf.astype(np.float32), anchor_info

canonical_rows, canonical_conf_rows, kept_original_indices = [], [], []
canonicalization_by_original_index, canonicalization_exclusions = {}, []
for original_i, (pose, confidence) in enumerate(zip(poses, confs)):
    canonical, canonical_conf, anchor_info = canonicalize_one(pose, confidence)
    if canonical is None:
        source = original_rows.iloc[original_i]
        exclusion = {
            'uid': str(source.uid),
            'source_video_id': str(source.video_id),
            'text': str(source.text),
            'original_split': original_split_by_index[original_i],
            **anchor_info,
        }
        canonicalization_exclusions.append(exclusion)
        canonicalization_by_original_index[original_i] = anchor_info
        continue
    kept_original_indices.append(original_i)
    canonical_rows.append(canonical); canonical_conf_rows.append(canonical_conf)
    canonicalization_by_original_index[original_i] = anchor_info

if len(canonicalization_exclusions) != 1:
    raise RuntimeError(f'Expected one canonicalization exclusion; got {len(canonicalization_exclusions)}')
old_to_new = {old_i: new_i for new_i, old_i in enumerate(kept_original_indices)}
outer_train_ix = np.asarray([old_to_new[int(i)] for i in original_train_ix if int(i) in old_to_new], dtype=np.int64)
val_ix = np.asarray([old_to_new[int(i)] for i in original_val_ix if int(i) in old_to_new], dtype=np.int64)
rows = original_rows.iloc[kept_original_indices].reset_index(drop=True)
canonical_poses = np.stack(canonical_rows).astype(np.float32)
canonical_confs = np.stack(canonical_conf_rows).astype(np.float32)
del canonical_rows, canonical_conf_rows, poses, confs; gc.collect()
assert len(rows) == 2045 and len(outer_train_ix) + len(val_ix) == len(rows)
assert len(outer_train_ix) + len(val_ix) + len(canonicalization_exclusions) == len(original_rows)
assert set(rows.iloc[outer_train_ix].video_id).isdisjoint(set(rows.iloc[val_ix].video_id))
assert len(val_ix) > 0, 'Validation partition must be non-empty.'

token_pattern = re.compile(r"[a-z0-9]+(?:'[a-z0-9]+)?|[^\w\s]", re.IGNORECASE)
def text_key(text): return ' '.join(token_pattern.findall(str(text).lower()))

# Keep captions from every original validation row held out, including any row excluded from pose fitting.
validation_text_keys = {text_key(original_rows.iloc[int(i)].text) for i in original_val_ix}
caption_overlap_ix = [int(i) for i in outer_train_ix if text_key(rows.iloc[i].text) in validation_text_keys]
train_pool_ix = [int(i) for i in outer_train_ix if text_key(rows.iloc[i].text) not in validation_text_keys]
grouped_by_text = defaultdict(list)
for i in train_pool_ix: grouped_by_text[text_key(rows.iloc[i].text)].append(i)
caption_groups = list(grouped_by_text)
np.random.default_rng(SEED + 41).shuffle(caption_groups)
early_target = max(1, int(round(len(train_pool_ix) * 0.10)))
early_stop_ix, early_keys = [], set()
for key in caption_groups:
    if len(early_stop_ix) >= early_target: break
    early_stop_ix.extend(grouped_by_text[key]); early_keys.add(key)
fit_ix = [i for i in train_pool_ix if text_key(rows.iloc[i].text) not in early_keys]
assert fit_ix and early_stop_ix and set(fit_ix).isdisjoint(early_stop_ix)
assert not ({text_key(rows.iloc[i].text) for i in fit_ix} & validation_text_keys)
assert not ({text_key(rows.iloc[i].text) for i in fit_ix} & early_keys)
assert set(rows.iloc[fit_ix].video_id).isdisjoint(set(rows.iloc[early_stop_ix].video_id))

print(f'Canonical points: body 0:33, left hand 33:54, right hand 54:75; scale is 2D nose-to-shoulder-midpoint distance in x/y, applied to x/y/z.')
print(f'Canonicalization exclusions: {len(canonicalization_exclusions)}; original split retained: {len(outer_train_ix)} train / {len(val_ix)} validation; exclusions={[(x["uid"],x["original_split"],x["reason"]) for x in canonicalization_exclusions]}')
print(f'Outer V2 development split: {len(outer_train_ix)} train / {len(val_ix)} validation; exact train captions removed={len(caption_overlap_ix)}')
print(f'Effective gradient fit: {len(fit_ix)}; text-group early stop: {len(early_stop_ix)}; final holdout remains untouched for model selection.')
