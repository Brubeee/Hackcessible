# Evaluate all effective held-out videos under true and shuffled text; export model and evaluator bundles.
EXPORT_ROOT = Path('/kaggle/working/isl_v3_export')
if EXPORT_ROOT.exists(): shutil.rmtree(EXPORT_ROOT)
(EXPORT_ROOT / 'references').mkdir(parents=True)
(EXPORT_ROOT / 'baselines').mkdir(parents=True)
(EXPORT_ROOT / 'predictions').mkdir(parents=True)
(EXPORT_ROOT / 'checkpoints').mkdir(parents=True)
(EXPORT_ROOT / 'diagnostics').mkdir(parents=True)

val_unique = {}
for i in val_ix:
    val_unique.setdefault(text_key(rows.iloc[int(i)].text), int(i))
unique_val_keys = sorted(val_unique)
assert len(unique_val_keys) >= 2, 'Need at least two distinct held-out caption groups for a text-shuffle counterfactual.'
counter_ix = []
for i in val_ix:
    uid = str(rows.iloc[int(i)].uid); own = text_key(rows.iloc[int(i)].text)
    choices = [key for key in unique_val_keys if key != own]
    rank = int(hashlib.sha256(f'{SEED}:{uid}'.encode()).hexdigest(), 16) % len(choices)
    counter_ix.append(val_unique[choices[rank]])
counter_ix = np.asarray(counter_ix, dtype=np.int64)
assert all(text_key(rows.iloc[int(i)].text) != text_key(rows.iloc[int(j)].text) for i,j in zip(val_ix,counter_ix))
fit_keys = {text_key(rows.iloc[int(i)].text) for i in fit_ix}
assert all(text_key(rows.iloc[int(j)].text) not in fit_keys for j in counter_ix), 'A counterfactual caption leaked into gradient-fit text.'

ranked_val = sorted((str(rows.iloc[int(i)].uid) for i in val_ix), key=lambda uid: (hashlib.sha256(f'{SEED}:{uid}'.encode()).hexdigest(), uid))
fixed_uids = ranked_val[:12]
assert len(fixed_uids) == 12
ref_dir = EXPORT_ROOT / 'references'; pred_root = EXPORT_ROOT / 'predictions'
safe_names = {}
for i in val_ix:
    uid = str(rows.iloc[int(i)].uid); slug = re.sub(r'[^A-Za-z0-9._-]+', '_', uid)
    safe_names[uid] = slug
    np.savez_compressed(ref_dir / (slug + '.npz'), pose=canonical_poses[int(i)], confidence=canonical_confs[int(i)])
np.save(EXPORT_ROOT / 'point_indices.npy', POINT_INDICES)

header = json.load(open('/kaggle/input/hackcessible-isign-pose-cache-v2/pose_header.json', encoding='utf-8')) if Path('/kaggle/input/hackcessible-isign-pose-cache-v2/pose_header.json').exists() else None
if header is None:
    local_headers = list(Path('/kaggle/input').rglob('*_header.json'))
    if local_headers: header = json.load(open(local_headers[0], encoding='utf-8'))
if header is None:
    try:
        header_path = Path('/kaggle/working/pose_header.json')
        header_url = hf_hub_download(repo_id=REPO_ID, filename='pose_header.json', repo_type='dataset', token=HF_TOKEN)
        header = json.load(open(header_url, encoding='utf-8'))
    except Exception:
        header = None
if header is not None:
    edges = []
    for component in header.get('components', []):
        name = component.get('name', '')
        if name == 'POSE_LANDMARKS': dst_start, source_start, count = 0, 0, 33
        elif name in {'LEFT_HAND', 'LEFT_HAND_LANDMARKS'}: dst_start, source_start, count = 33, 501, 21
        elif name in {'RIGHT_HAND', 'RIGHT_HAND_LANDMARKS'}: dst_start, source_start, count = 54, 522, 21
        else: continue
        for a,b in component.get('limbs', []):
            if 0 <= int(a) < count and 0 <= int(b) < count: edges.append((dst_start + int(a), dst_start + int(b)))
    edges = np.asarray(sorted(set(tuple(sorted(edge)) for edge in edges)), dtype=np.int64)
else:
    # MediaPipe body and hand landmark connections, matching the 75-point source topology.
    body_edges_local = [(11,12),(11,13),(13,15),(15,17),(15,19),(15,21),(17,19),(12,14),(14,16),(16,18),(16,20),(16,22),(18,20),(11,23),(12,24),(23,24),(23,25),(25,27),(27,29),(29,31),(27,31),(24,26),(26,28),(28,30),(30,32),(28,32),(0,1),(1,2),(2,3),(3,7),(0,4),(4,5),(5,6),(6,8),(9,10)]
    hand_edges_local = [(0,1),(1,2),(2,3),(3,4),(0,5),(5,6),(6,7),(7,8),(5,9),(9,10),(10,11),(11,12),(9,13),(13,14),(14,15),(15,16),(13,17),(17,18),(18,19),(19,20),(0,17)]
    edges = np.asarray(body_edges_local + [(33+a,33+b) for a,b in hand_edges_local] + [(54+a,54+b) for a,b in hand_edges_local], dtype=np.int64)
np.save(EXPORT_ROOT / 'skeleton_edges.npy', edges)

zero_pose = np.zeros((TMAX, POINTS, 3), dtype=np.float32)
np.save(EXPORT_ROOT / 'baselines' / 'zero_pose.npy', zero_pose)
np.save(EXPORT_ROOT / 'baselines' / 'train_frame_mean.npy', train_frame_mean)
np.savez_compressed(EXPORT_ROOT / 'normalizer.npz', mean=normalizer_mean, std=normalizer_std)

def predict_for_indices(core, model, arm, indices):
    inputs, masks = feature_arrays(arm)
    out = []
    for start in range(0, len(indices), BATCH):
        batch_ix = indices[start:start+BATCH]
        x=torch.from_numpy(inputs[batch_ix]).to(device); m=torch.from_numpy(masks[batch_ix]).to(device)
        with torch.no_grad(): y=model(x,m).cpu().numpy().reshape(len(batch_ix),TMAX,POINTS,3)
        out.append(y)
    normalized = np.concatenate(out, axis=0)
    return (normalized * normalizer_std[None,None] + normalizer_mean[None,None]).astype(np.float32)

def export_metrics(prediction, reference, confidence):
    z_pred=(prediction-normalizer_mean[None,None])/normalizer_std[None,None]
    z_ref=(reference-normalizer_mean[None,None])/normalizer_std[None,None]
    result={}
    for name,(start,end,weight) in GROUPS.items():
        conf=confidence[:,:,start:end,None]
        sq=(z_pred[:,:,start:end]-z_ref[:,:,start:end])**2
        raw_sq=(prediction[:,:,start:end]-reference[:,:,start:end])**2
        den=max(float(conf.sum()*3),1e-8)
        vconf=np.minimum(confidence[:,1:,start:end],confidence[:,:-1,start:end])
        pm=np.linalg.norm(np.diff(prediction[:,:,start:end],axis=1),axis=-1)
        rm=np.linalg.norm(np.diff(reference[:,:,start:end],axis=1),axis=-1)
        motion_den=max(float(vconf.sum()),1e-8)
        pred_motion=float((pm*vconf).sum()/motion_den); ref_motion=float((rm*vconf).sum()/motion_den)
        result[name]={'normalized_mse':float((sq*conf).sum()/den),'canonical_rmse':float(np.sqrt((raw_sq*conf).sum()/den)),'prediction_motion':pred_motion,'reference_motion':ref_motion,'motion_ratio':float(pred_motion/max(ref_motion,1e-8))}
    result['group_balanced_normalized_mse']=float(sum(GROUPS[name][2]*result[name]['normalized_mse'] for name in GROUPS))
    return result

reference_all=canonical_poses[val_ix]
confidence_all=canonical_confs[val_ix]
retrieval_train_ix=np.asarray(fit_ix,dtype=np.int64)
similarity=mini_features[val_ix] @ mini_features[retrieval_train_ix].T
retrieval_ix=retrieval_train_ix[similarity.argmax(axis=1)]
retrieval_all=canonical_poses[retrieval_ix]
retrieval_uid=[str(rows.iloc[int(i)].uid) for i in retrieval_ix]
for i,uid in enumerate([str(rows.iloc[int(j)].uid) for j in val_ix]):
    np.save(EXPORT_ROOT / 'baselines' / (safe_names[uid] + '_semantic_retrieval.npy'), retrieval_all[i])

def metadata_record(frame, i):
    raw_count=frame.iloc[int(i)].raw_frame_count
    return {'uid':str(frame.iloc[int(i)].uid),'source_video_id':str(frame.iloc[int(i)].video_id),'text':str(frame.iloc[int(i)].text),'raw_frame_count':None if pd.isna(raw_count) else int(raw_count),'resampled_frame_count':TMAX,'resampling_policy':'uniform_linear_48_endpoints_included' if not pd.isna(raw_count) else 'uniform_linear_48_endpoints_included; original_count_unavailable_in_v2_cache'}

def row_record(i):
    original_i=int(kept_original_indices[int(i)])
    record=metadata_record(rows, i)
    record['canonicalization_anchor_audit']=canonicalization_by_original_index[original_i]
    return record

outer_train_records=[row_record(i) for i in outer_train_ix]
outer_val_records=[row_record(i) for i in val_ix]
original_train_records=[metadata_record(original_rows, i) for i in original_train_ix]
original_val_records=[metadata_record(original_rows, i) for i in original_val_ix]
exclusion_counts_by_side={side:dict(Counter(item['reason'] for item in canonicalization_exclusions if item['original_split']==side)) for side in ('train','validation')}
validation_universe_uids=sorted(str(uid) for uid in rows.iloc[val_ix].uid)
validation_universe_sha256=hashlib.sha256('\n'.join(validation_universe_uids).encode()).hexdigest()
early_stop_uids=[str(rows.iloc[int(i)].uid) for i in early_stop_ix]
training_uids_used=[str(rows.iloc[int(i)].uid) for i in fit_ix]
topology={'components':[{'name':'body','start':0,'count':33},{'name':'left_hand','start':33,'count':21},{'name':'right_hand','start':54,'count':21}]}

all_metrics={'dataset':'Exploration-Lab/iSign v1.1','run_key':run_key,'usable_examples':len(rows),'original_cache_examples':len(original_rows),'canonicalization_exclusions':canonicalization_exclusions,'canonicalization_exclusion_counts_by_original_split':exclusion_counts_by_side,'outer_train':len(outer_train_ix),'final_validation':len(val_ix),'effective_fit':len(fit_ix),'internal_early_stop':len(early_stop_ix),'removed_exact_train_test_caption_rows':len(caption_overlap_ix),'fixed_qualitative_uids':fixed_uids,'selected_primary_arm':selected_arm,'candidate_selection':'Lowest common internal text-group validation score: group-balanced normalized position MSE + 0.05 times group-balanced normalized velocity MSE; the V2 outer holdout is development evidence because it has been inspected across arms.','counterfactual_text_rule':'For each held-out UID, choose a different normalized caption from the held-out caption set using SHA256(SEED:UID); no final-held-out caption text occurs in the gradient-fit set.','resampling':{'resampled_frame_count':TMAX,'policy':'uniform_linear_48_endpoints_included','raw_frame_count':'Unavailable for original V2 cached examples because the cache contains only already-resampled pose and confidence arrays. Raw count is recorded when ranged fallback decoding exposes it.'},'arms':{},'baselines':{}}
all_metrics['baselines']['zero_pose']=export_metrics(np.broadcast_to(zero_pose,(len(val_ix),TMAX,POINTS,3)),reference_all,confidence_all)
all_metrics['baselines']['train_frame_mean']=export_metrics(np.broadcast_to(train_frame_mean,(len(val_ix),TMAX,POINTS,3)),reference_all,confidence_all)
all_metrics['baselines']['semantic_nearest_training_clip']=export_metrics(retrieval_all,reference_all,confidence_all)

for arm_name, run in runs.items():
    config=run['config']; mode=config['mode']; state=run['best_state']
    model_core=TextToPose(mode,vocab_size=len(vocab)).to(device); model_core.load_state_dict(state); model=nn.DataParallel(model_core,device_ids=[0,1]).eval()
    true_all=predict_for_indices(model_core,model,mode,val_ix)
    shuffled_all=predict_for_indices(model_core,model,mode,counter_ix)
    arm_dir=pred_root / arm_name; arm_dir.mkdir(parents=True,exist_ok=True)
    counter_text_by_uid={}
    sample_records=[]
    for j,idx in enumerate(val_ix):
        uid=str(rows.iloc[int(idx)].uid); slug=safe_names[uid]; cf_idx=int(counter_ix[j])
        counter_text=str(rows.iloc[cf_idx].text); counter_text_by_uid[uid]=counter_text
        donor_uid=str(rows.iloc[cf_idx].uid)
        true_path=arm_dir / (slug + '_true.npy'); shuffled_path=arm_dir / (slug + '_shuffled.npy')
        np.save(true_path,true_all[j]); np.save(shuffled_path,shuffled_all[j])
        raw_count=rows.iloc[int(idx)].raw_frame_count
        sample_records.append({'uid':uid,'source_video_id':str(rows.iloc[int(idx)].video_id),'text':str(rows.iloc[int(idx)].text),'counterfactual_text':counter_text,'counterfactual_source_uid':donor_uid,'raw_frame_count':None if pd.isna(raw_count) else int(raw_count),'resampled_frame_count':TMAX,'resampling_policy':'uniform_linear_48_endpoints_included' if not pd.isna(raw_count) else 'uniform_linear_48_endpoints_included; original_count_unavailable_in_v2_cache','canonicalization_anchor_audit':canonicalization_by_original_index[int(kept_original_indices[int(idx)])],'semantic_retrieval_source_uid':retrieval_uid[j],'reference':{'path':'references/' + slug + '.npz','pose_key':'pose','confidence_key':'confidence'},'predictions':{'true_text':'predictions/' + arm_name + '/' + slug + '_true.npy','shuffled_text':'predictions/' + arm_name + '/' + slug + '_shuffled.npy','zero_pose':'baselines/zero_pose.npy','train_frame_mean':'baselines/train_frame_mean.npy','semantic_retrieval':'baselines/' + slug + '_semantic_retrieval.npy'}})
    true_metrics=export_metrics(true_all,reference_all,confidence_all)
    shuffled_metrics=export_metrics(shuffled_all,reference_all,confidence_all)
    mean_text_delta=np.mean(np.abs(true_all-shuffled_all),axis=(1,2,3))
    for j,sample in enumerate(sample_records): sample['true_vs_shuffled_mean_abs_delta']=float(mean_text_delta[j])
    best_history=next(item for item in run['history'] if item['epoch']==run['best_epoch'])
    all_metrics['arms'][arm_name]={'config':config,'best_epoch':run['best_epoch'],'best_internal_selection_score':run['best_internal_selection_score'],'best_internal_position':run['best_internal_position'],'best_internal_velocity':run['best_internal_velocity'],'best_internal_motion_ratio_by_group':best_history['early_motion_ratio_by_group'],'gpus_used':run['gpus_used'],'seconds':run['seconds'],'true_text':true_metrics,'shuffled_text':shuffled_metrics,'true_vs_shuffled_mean_abs_delta':{'median':float(np.median(mean_text_delta)),'mean':float(np.mean(mean_text_delta)),'per_uid':{sample_records[j]['uid']:float(mean_text_delta[j]) for j in range(len(sample_records))}},'text_sensitivity_gain_vs_shuffled_group_balanced_mse':float(shuffled_metrics['group_balanced_normalized_mse']-true_metrics['group_balanced_normalized_mse'])}
    checkpoint={'format':'Hackcessible iSign V3 compact body+hands','arm':arm_name,'config':config,'state_dict':state,'normalizer_mean':normalizer_mean,'normalizer_std':normalizer_std,'normalizer_fit_uid_sha256':normalizer_fit_uid_sha256,'point_indices':POINT_INDICES,'time_steps':TMAX,'topology':topology,'vocab':vocab if mode=='random' else None,'frozen_text_encoder':MINILM_NAME if mode=='minilm' else None,'license':'iSign CC-BY-NC-SA-4.0; research/non-commercial use only'}
    torch.save(checkpoint,EXPORT_ROOT / 'checkpoints' / (arm_name + '.pt'))
    manifest={'schema_version':1,'dataset':'Exploration-Lab/iSign v1.1','model_arm':arm_name,'evaluation_status':'development_evidence_not_final_test; the V2 outer holdout was inspected across candidate arms','selected_for_follow_up':arm_name==selected_arm,'selection_metric':'group-balanced normalized position MSE + 0.05 x group-balanced normalized velocity MSE on text-group internal validation','objective':{'group_weights':{'body':0.20,'left_hand':0.40,'right_hand':0.40},'velocity_coefficient':VELOCITY_WEIGHT,'training_velocity_coefficient':config['velocity_weight'],'confidence':'point confidence clipped to [0,1]; velocity confidence is the minimum adjacent-frame confidence','normalization':'train-only per-point/per-axis z-score fit on training_uids_used'},'training_uids_used':training_uids_used,'early_stop_uids':early_stop_uids,'split':{'strategy':'V2 seed 17 video-disjoint selection over the original 2,046 cache rows; one unusable pose excluded within its original partition; exact normalized-caption overlap removed from gradient fit; internal early-stop split by caption groups','group_field':'source_video_id','original_train':original_train_records,'original_validation':original_val_records,'train':outer_train_records,'validation':outer_val_records,'canonicalization_exclusions':canonicalization_exclusions,'canonicalization_exclusion_counts_by_original_split':exclusion_counts_by_side,'training_uids_used':training_uids_used,'early_stop_uids':early_stop_uids,'caption_overlap_removed_uids':[str(rows.iloc[int(i)].uid) for i in caption_overlap_ix]},'canonicalization':{'policy':'nose and both shoulders must be finite, have confidence >= 0.15, and define a nondegenerate 2D x/y scale; interpolate center and log-scale only when at least two valid anchors exist; no fallback anchor modes; exclude irrecoverable clips within their frozen original partition','threshold':MIN_ANCHOR_CONF,'resampled_frame_count':TMAX,'exclusion_count':len(canonicalization_exclusions),'exclusion_counts_by_original_split':exclusion_counts_by_side,'exclusions':canonicalization_exclusions},'fixed_unseen_set':{'seed':SEED,'count':len(fixed_uids),'selection_rule':'sha256_rank_by_uid','selection_universe_count':len(validation_universe_uids),'selection_universe_uid_sha256':validation_universe_sha256,'uids':fixed_uids},'topology':topology,'normalizer':{'path':'normalizer.npz','mean_key':'mean','std_key':'std','fit_split':'train','fit_uid_sha256':normalizer_fit_uid_sha256,'fit_uid_hash_rule':'sha256(sorted training UIDs joined by newline)'},'coordinate_space':'canonical shoulder-centered pose; scale is 2D nose-to-shoulder-midpoint distance in x/y and is applied to x/y/z; predictions are denormalized canonical values, not z-scores','resampling':all_metrics['resampling'],'samples':sample_records,'metrics_path':'metrics_summary.json','license':'iSign CC-BY-NC-SA-4.0; research/non-commercial use only'}
    (EXPORT_ROOT / ('manifest_' + arm_name + '.json')).write_text(json.dumps(manifest,indent=2))
    del model, model_core; gc.collect(); torch.cuda.empty_cache()
    print(arm_name, '| internal best epoch', run['best_epoch'], '| true group-balanced MSE', round(true_metrics['group_balanced_normalized_mse'],5), '| shuffled', round(shuffled_metrics['group_balanced_normalized_mse'],5), '| text delta', round(float(np.mean(mean_text_delta)),5))

(EXPORT_ROOT / 'metrics_summary.json').write_text(json.dumps(all_metrics,indent=2))
tiny_src=Path('/kaggle/working/isl_v3_tiny_overfit.npz')
tiny_json_src=Path('/kaggle/working/isl_v3_tiny_overfit.json')
if tiny_src.exists(): shutil.copy2(tiny_src,EXPORT_ROOT/'diagnostics'/'tiny_overfit.npz')
if tiny_json_src.exists(): shutil.copy2(tiny_json_src,EXPORT_ROOT/'diagnostics'/'tiny_overfit.json')
readme_text = (
    'V3 outputs contain canonicalized body and hands only (75 points; 48 frames). '
    'Face mesh and nonmanual facial grammar are not modeled. Predictions are denormalized canonical coordinates. '
    f'The {len(rows)} usable videos retain their original membership in the V2 seed-17 partition after '
    f'excluding {len(canonicalization_exclusions)} irrecoverable pose record(s); the frozen original cache roster had {len(original_rows)} videos. '
    f'The {len(fixed_uids)} SHA-ranked fixed unseen UIDs are a subset of the {len(val_ix)} effective held-out videos. '
    'Motion and coordinate scores do not demonstrate sign intelligibility; have an ISL-fluent signer review rendered outputs. '
    'Dataset license: CC-BY-NC-SA-4.0, research/non-commercial use only.\n'
)
(EXPORT_ROOT / 'README.txt').write_text(readme_text)
archive_path=shutil.make_archive('/kaggle/working/hackcessible_isl_v3_artifacts','zip',root_dir=EXPORT_ROOT)
print('V3 artifacts:',archive_path,'| bytes:',Path(archive_path).stat().st_size)
print('Selected by internal validation:',selected_arm,'| all held-out rows scored:',len(val_ix),'| fixed qualitative set:',len(fixed_uids))
