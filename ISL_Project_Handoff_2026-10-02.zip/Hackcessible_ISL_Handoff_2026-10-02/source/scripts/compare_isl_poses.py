"""Render and measure an aligned reference/prediction pair of ISL poses.

Inputs are .npy arrays shaped (frames, points, coordinates), plus an optional
JSON topology file containing a `connections` list of [point_a, point_b] pairs.
The HTML output is self-contained and keeps the two sequences on identical axes.
"""

from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path
from typing import Any

import numpy as np


def load_array(path: Path, key: str = "pose") -> tuple[np.ndarray, np.ndarray | None]:
    loaded = np.load(path, allow_pickle=False)
    confidence = None
    if isinstance(loaded, np.lib.npyio.NpzFile):
        with loaded as data:
            if key not in data.files:
                raise ValueError(f"{path} has keys {data.files}; requested pose key {key!r}")
            array = data[key].copy()
            if "confidence" in data.files:
                confidence = data["confidence"].copy()
    else:
        array = loaded
    if array.ndim == 2 and array.shape[-1] % 3 == 0:
        array = array.reshape(array.shape[0], array.shape[-1] // 3, 3)
    if array.ndim == 4 and array.shape[1] == 1:
        array = array[:, 0]
    if array.ndim != 3 or array.shape[-1] < 2:
        raise ValueError(f"Expected (frames, points, coordinates>=2), got {array.shape} from {path}")
    if not np.issubdtype(array.dtype, np.number) or not np.isfinite(array).all():
        raise ValueError(f"{path} must contain only finite numeric coordinates")
    if confidence is not None:
        if confidence.ndim == 3 and confidence.shape[1] == 1:
            confidence = confidence[:, 0]
        if confidence.shape != array.shape[:2] or not np.isfinite(confidence).all():
            raise ValueError(f"Confidence array must be finite with shape {array.shape[:2]}, got {confidence.shape}")
        confidence = np.clip(confidence.astype(np.float32), 0.0, 1.0)
    return np.asarray(array, dtype="<f4"), confidence


def load_connections(path: Path | None, point_count: int) -> list[list[int]]:
    if path is None:
        return []
    raw: Any = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(raw, dict):
        raw = raw.get("connections")
    if not isinstance(raw, list):
        raise ValueError("Topology JSON must be a list or an object with a 'connections' list")
    result: list[list[int]] = []
    for item in raw:
        if isinstance(item, dict):
            pair = [item.get("start"), item.get("end")]
        elif isinstance(item, (list, tuple)) and len(item) == 2:
            pair = list(item)
        else:
            raise ValueError(f"Invalid connection entry: {item!r}")
        if any(not isinstance(index, int) or index < 0 or index >= point_count for index in pair):
            raise ValueError(f"Connection indexes must be integers from 0 to {point_count - 1}: {pair}")
        result.append(pair)
    return result


def metrics(reference: np.ndarray, prediction: np.ndarray,
            confidence: np.ndarray | None = None) -> dict[str, float]:
    error = prediction - reference
    model_rmse = float(np.sqrt(np.mean(error**2)))
    pred_motion = np.linalg.norm(np.diff(prediction, axis=0), axis=-1)
    ref_motion = np.linalg.norm(np.diff(reference, axis=0), axis=-1)
    result = {
        "reference_prediction_rmse": model_rmse,
        "reference_prediction_mae": float(np.mean(np.abs(error))),
        "origin_baseline_rmse": float(np.sqrt(np.mean(reference**2))),
        "prediction_motion_median": float(np.median(pred_motion)) if pred_motion.size else 0.0,
        "reference_motion_median": float(np.median(ref_motion)) if ref_motion.size else 0.0,
        "prediction_motion_p90": float(np.percentile(pred_motion, 90)) if pred_motion.size else 0.0,
        "reference_motion_p90": float(np.percentile(ref_motion, 90)) if ref_motion.size else 0.0,
        "prediction_coordinate_min": float(prediction.min()),
        "prediction_coordinate_max": float(prediction.max()),
        "reference_coordinate_min": float(reference.min()),
        "reference_coordinate_max": float(reference.max()),
    }
    if confidence is not None:
        weights = np.broadcast_to(confidence[..., None], reference.shape)
        denominator = float(weights.sum())
        if denominator > 0:
            result["confidence_weighted_rmse"] = float(np.sqrt((error**2 * weights).sum() / denominator))
            result["confidence_weighted_mae"] = float((np.abs(error) * weights).sum() / denominator)
    return result


def align_temporal(reference: np.ndarray, prediction: np.ndarray) -> tuple[np.ndarray, np.ndarray, str]:
    """Resample the longer clip to the shorter frame count on normalized time."""
    if reference.shape[0] == prediction.shape[0]:
        return reference, prediction, "native frame counts (no temporal resampling)"
    target = min(reference.shape[0], prediction.shape[0])

    def resample(sequence: np.ndarray, frames: int) -> np.ndarray:
        old_time = np.linspace(0.0, 1.0, sequence.shape[0])
        new_time = np.linspace(0.0, 1.0, frames)
        flat = sequence.reshape(sequence.shape[0], -1)
        output = np.empty((frames, flat.shape[1]), dtype=np.float32)
        for column in range(flat.shape[1]):
            output[:, column] = np.interp(new_time, old_time, flat[:, column])
        return output.reshape((frames, *sequence.shape[1:]))

    note = f"normalized-time linear alignment to {target} frames; longer sequence resampled"
    return resample(reference, target), resample(prediction, target), note


def align_confidence(confidence: np.ndarray | None, frames: int) -> np.ndarray | None:
    if confidence is None or confidence.shape[0] == frames:
        return confidence
    old_time = np.linspace(0.0, 1.0, confidence.shape[0])
    new_time = np.linspace(0.0, 1.0, frames)
    return np.stack([np.interp(new_time, old_time, confidence[:, point])
                     for point in range(confidence.shape[1])], axis=1).astype(np.float32)


def render_html(reference: np.ndarray, prediction: np.ndarray, connections: list[list[int]],
                reference_name: str, prediction_name: str, title: str,
                alignment: str) -> str:
    # Float32 base64 keeps the file compact while retaining exact input values.
    ref64 = base64.b64encode(reference.tobytes(order="C")).decode("ascii")
    pred64 = base64.b64encode(prediction.tobytes(order="C")).decode("ascii")
    edges = json.dumps(connections, separators=(",", ":"))
    labels = json.dumps([reference_name, prediction_name], ensure_ascii=True).replace("</", "<\\/")
    alignment_json = json.dumps(alignment, ensure_ascii=True).replace("</", "<\\/")
    safe_title = title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return f'''<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{safe_title}</title>
<style>
:root{{color-scheme:light dark;font:16px system-ui,sans-serif}}body{{margin:0;padding:1rem;background:Canvas;color:CanvasText}}
h1{{font-size:1.15rem;margin:0 0 .75rem}}.panels{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem}}
section{{min-width:0}}h2{{font-size:1rem;font-weight:500;margin:.25rem 0}}canvas{{width:100%;height:min(62vh,520px);display:block;background:color-mix(in srgb,CanvasText 4%,Canvas);border-radius:.4rem}}
.controls{{display:flex;align-items:center;gap:.65rem;flex-wrap:wrap;margin:.8rem 0}}input[type=range]{{flex:1;min-width:160px}}button{{font:inherit;padding:.4rem .8rem}}output{{font-variant-numeric:tabular-nums}}#status{{min-height:1.5em}}
@media(max-width:680px){{.panels{{grid-template-columns:1fr}}canvas{{height:48vh}}}}
</style>
<h1>{safe_title}</h1><div class="panels">
<section><h2 id="ref-name"></h2><canvas id="reference" aria-label="Reference pose skeleton"></canvas></section>
<section><h2 id="pred-name"></h2><canvas id="prediction" aria-label="Predicted pose skeleton"></canvas></section>
</div><div class="controls"><button id="play" type="button">Play</button><label for="frame">Frame</label><input id="frame" type="range" min="0" max="{reference.shape[0]-1}" value="0"><output id="frame-value" for="frame">1 / {reference.shape[0]}</output></div>
<div id="status" role="status" aria-live="polite"></div>
<script>
const frameCount={reference.shape[0]}, pointCount={reference.shape[1]}, coordCount={reference.shape[2]};
const labels={labels}, edges={edges}, alignment={alignment_json};
function decode(text){{const bytes=Uint8Array.from(atob(text),c=>c.charCodeAt(0));return new Float32Array(bytes.buffer)}}
const sequences=[decode('{ref64}'),decode('{pred64}')];
document.getElementById('ref-name').textContent=labels[0];document.getElementById('pred-name').textContent=labels[1];
const canvases=[document.getElementById('reference'),document.getElementById('prediction')];
const slider=document.getElementById('frame'), frameValue=document.getElementById('frame-value');
const bounds=[Infinity,Infinity,-Infinity,-Infinity];
for(const seq of sequences)for(let f=0;f<frameCount;f++)for(let p=0;p<pointCount;p++){{const i=(f*pointCount+p)*coordCount;bounds[0]=Math.min(bounds[0],seq[i]);bounds[1]=Math.min(bounds[1],seq[i+1]);bounds[2]=Math.max(bounds[2],seq[i]);bounds[3]=Math.max(bounds[3],seq[i+1])}}
function draw(canvas,seq,frame,color){{const rect=canvas.getBoundingClientRect(),scale=window.devicePixelRatio||1;if(!rect.width||!rect.height)return;canvas.width=Math.round(rect.width*scale);canvas.height=Math.round(rect.height*scale);const c=canvas.getContext('2d');c.scale(scale,scale);const pad=20,w=rect.width-2*pad,h=rect.height-2*pad;const rangeX=Math.max(bounds[2]-bounds[0],1e-8),rangeY=Math.max(bounds[3]-bounds[1],1e-8),s=Math.min(w/rangeX,h/rangeY);const pos=p=>{{const i=(frame*pointCount+p)*coordCount;return [pad+(seq[i]-bounds[0])*s+(w-rangeX*s)/2,pad+h-((seq[i+1]-bounds[1])*s+(h-rangeY*s)/2)]}};c.lineWidth=1.5;c.strokeStyle=color;c.globalAlpha=.72;for(const [a,b] of edges){{if(a>=pointCount||b>=pointCount)continue;const [x1,y1]=pos(a),[x2,y2]=pos(b);c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke()}}c.globalAlpha=1;c.fillStyle=color;for(let p=0;p<pointCount;p++){{const [x,y]=pos(p);c.beginPath();c.arc(x,y,1.7,0,Math.PI*2);c.fill()}}}}
function render(){{const f=Number(slider.value);frameValue.value=`${{f+1}} / ${{frameCount}}`;draw(canvases[0],sequences[0],f,'#2563eb');draw(canvases[1],sequences[1],f,'#e4572e')}}
slider.addEventListener('input',render);window.addEventListener('resize',render);render();
let timer=null;document.getElementById('play').addEventListener('click',e=>{{if(timer){{clearInterval(timer);timer=null;e.currentTarget.textContent='Play';return}}e.currentTarget.textContent='Pause';timer=setInterval(()=>{{slider.value=(Number(slider.value)+1)%frameCount;render()}},1000/12)}});
document.getElementById('status').textContent=`${{frameCount}} aligned frames · ${{pointCount}} points · ${{edges.length}} supplied connections · shared XY scale · ${{alignment}}`;
</script></html>'''


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", type=Path, help="Held-out reference .npy")
    parser.add_argument("prediction", type=Path, help="Model prediction .npy")
    parser.add_argument("--topology", type=Path, help="JSON containing authoritative connections")
    parser.add_argument("--out", type=Path, required=True, help="Self-contained comparison HTML path")
    parser.add_argument("--title", default="ISL pose: reference vs prediction")
    parser.add_argument("--reference-key", default="pose", help="Array key when reference is an .npz (default: pose)")
    parser.add_argument("--prediction-key", default="pose", help="Array key when prediction is an .npz (default: pose)")
    parser.add_argument("--align-time", action="store_true",
                        help="Linearly align unequal frame counts over normalized clip time")
    args = parser.parse_args()

    reference, reference_confidence = load_array(args.reference, args.reference_key)
    prediction, prediction_confidence = load_array(args.prediction, args.prediction_key)
    source_shapes = {"reference": list(reference.shape), "prediction": list(prediction.shape)}
    if reference.shape[1:] != prediction.shape[1:]:
        parser.error(f"Point and coordinate shapes must match; got {reference.shape} vs {prediction.shape}")
    alignment = "native frame counts (no temporal resampling)"
    if reference.shape[0] != prediction.shape[0]:
        if not args.align_time:
            parser.error(f"Frame counts differ ({reference.shape[0]} vs {prediction.shape[0]}). "
                         "Pass --align-time to compare normalized clip progress explicitly.")
        reference, prediction, alignment = align_temporal(reference, prediction)
        reference_confidence = align_confidence(reference_confidence, reference.shape[0])
        prediction_confidence = align_confidence(prediction_confidence, prediction.shape[0])
    connections = load_connections(args.topology, reference.shape[1])
    args.out.parent.mkdir(parents=True, exist_ok=True)
    html = render_html(reference, prediction, connections, args.reference.stem,
                       args.prediction.stem, args.title, alignment)
    args.out.write_text(html, encoding="utf-8")
    report = {"reference": str(args.reference), "prediction": str(args.prediction),
              "source_shapes": source_shapes, "aligned_shape": list(reference.shape), "alignment": alignment,
              "connections": len(connections),
              "metrics": metrics(reference, prediction, reference_confidence), "html": str(args.out),
              "html_bytes": args.out.stat().st_size}
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
