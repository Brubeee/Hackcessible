# Hackcessible ISL project handoff — 2026-10-02

This archive collects the Hackcessible source and the ISL text-to-pose work completed so far. It is a source and status handoff, not a deployable translator or a redistributable iSign data package.

## Project state

The main application is a local React/FastAPI accessibility prototype. The tracked source and validation report cover English captions, session-level speaker labels, acoustic prosody cues, and an experimental overlap heuristic. Automated local checks and controlled-noise replay results are documented in `source/docs/VALIDATION.md`. They do not establish microphone performance in a real room, clinical accuracy, or formal accessibility conformance.

The current best measured ISL candidate is the V5 MiniLM-conditioned pose model from Kaggle run `354226633`. It shows a modest text effect against shuffled captions, but its predicted motion is only about 4.8% of the reference motion and is close to a frame-mean baseline. No fluent ISL signer evaluated the output. Treat this as an experimental, motion-collapsed candidate, not a working translator. Aggregate scores and caveats are in `reports/AGGREGATE_METRICS.json`.

The progressive V6 experiment passed data/cache and CPU-contract preflight, then failed its first synchronized GPU free-generation probe with a CUDA misaligned-address error in PyTorch Transformer attention mask handling. The current Kaggle page showed Version 1 of 1 and a failed run; the later reviewed CUDA repair source is commit `fb44188ffae7d09f96b3fb9fd1de419262c0ec52`, notebook SHA `AA1525331AE2CE985FFC52FC3F74B046CA3D5DCC5C89EB00722C0447EDD2AEA8`. No successful GPU rerun or training epoch was visible in the 2026-10-02 check. V5 remains the best measured candidate; the V6 repair is untrained and unverified.

## Recommended next steps

1. Import the reviewed V6 repair into the private Kaggle notebook and attach the existing V2 cache plus the successful V5 notebook output. The source uses cached poses and public MiniLM weights; it does not need the gated HF token when those inputs are present.
2. Verify the imported notebook digest and repeat the V5 checkpoint, cache coverage, role, reference, and normalizer checks. Run the synchronized GPU probe in a fresh process before any training; address any failure before training.
3. If the probe passes, train and compare true-text, shuffled-text, frame-mean, and frozen V5 outputs on the same cohort. Preserve an independent, authoritatively source-video-disjoint test split before making generalization claims.
4. Have fluent ISL signers assess randomized outputs for meaning, lexical correctness, grammar/naturalness, and comprehension before calling this a translator or integrating it into the app.

## Archive contents and provenance

- `source/` contains the Git-tracked application, docs, notebooks, and the allowlisted local ISL research helpers.
- `reports/AGGREGATE_METRICS.json` contains only aggregate counts and scores; it has no per-clip rows, captions, UIDs, source aliases, poses, predictions, or model weights.
- `provenance/SOURCE_PROVENANCE.json` records the repository commit, original source SHA-256 values, archive-copy SHA-256 values, and sanitization applied to each changed source copy.
- `INVENTORY.txt` lists archive member sizes and SHA-256 values. `SHA256SUMS.txt` provides file checksums.

Archive copies of the V3/V5 notebooks and builders have been sanitized: example-specific UID fixtures and a topology filename containing an example video ID were replaced by generic guards/placeholders. The original repository files were not modified by packaging. These archive copies remain parseable; identity-specific smoke assertions are intentionally generic in the bundle.

## Data and license boundary

The official [Exploration-Lab/iSign dataset card](https://huggingface.co/datasets/Exploration-Lab/iSign) identifies the dataset as gated and lists CC BY-NC-SA 4.0. The raw videos, captions, clip-level pose caches, selected UID/alias manifests, per-example metrics, reference/prediction arrays, checkpoint weights, and example contact sheets are excluded from this public archive. The dataset terms and access gate do not provide permission to rehost those records in a public GitHub ZIP.

A root `LICENSE` file was not present in the checked-out repository. This archive does not grant a license to the iSign dataset or to third-party model weights.

### Excluded local/private artifacts

The entire local `artifacts/` directory was excluded because it contains per-clip and dataset-derived content: 5,701 files, 368,717,686 bytes (351.6 MiB). This includes the local V4 and V5 output extracts, pose arrays, captions/UID maps, checkpoint files, reference/prediction examples, and contact sheets. No raw video or reusable pose cache was found in the local workspace. The private V2 cache remains a Kaggle input dataset; the successful V5 output is a Kaggle notebook output. Do not make either public.

For authorized continuation, attach the private [V2 cache dataset](https://www.kaggle.com/datasets/brubee/hackcessible-isign-pose-cache-v2) and the saved [V5 notebook output](https://www.kaggle.com/code/brubee/hackcessible-isl-text-to-pose?scriptVersionId=354226633) through Kaggle **Add Input**. The failed V6 output is at [the progressive notebook](https://www.kaggle.com/code/brubee/hackcessible-isl-text-to-pose-progressive-v6); its run output was shown as 137.54 MB but was not copied into this archive. No credential values are stored here.

## Repository provenance

Built from branch `codex/isl-v3` at commit `fb44188ffae7d09f96b3fb9fd1de419262c0ec52`. Packaging modified archive copies only. The Git working tree and original notebook sources were left unchanged; only the ZIP itself is intended for the next Git commit.
