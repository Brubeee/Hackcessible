"""Temporary Kaggle notebook cell for auditing cached iSign anchor coverage.

Run after V3 cell 2 defines `usable_records`, `poses`, `confs`, and `np`.
This prints evidence only; it does not mutate the arrays or train a model.
"""

anchor_min_conf = 0.15
anchor_indices = {"nose": 0, "left_shoulder": 11, "right_shoulder": 12,
                   "left_hip": 23, "right_hip": 24}
anchor_counts = {name: 0 for name in (
    "primary_nose_shoulders", "shoulder_width_fallback", "nose_one_shoulder_fallback",
    "hip_width_fallback", "no_valid_scale_anchor")}
diagnostic_rows = []

for record, pose, confidence in zip(usable_records, poses, confs):
    pose = np.asarray(pose, dtype=np.float32)
    confidence = np.asarray(confidence, dtype=np.float32)
    finite = np.isfinite(pose).all(axis=-1)
    confidence = np.clip(np.nan_to_num(confidence, nan=0.0, posinf=0.0, neginf=0.0), 0.0, 1.0)
    valid = {
        name: (confidence[:, index] >= anchor_min_conf) & finite[:, index]
        for name, index in anchor_indices.items()
    }
    shoulder_pair = valid["left_shoulder"] & valid["right_shoulder"]
    nose_pair = valid["nose"] & shoulder_pair
    shoulder_width = np.linalg.norm(pose[:, 11, :2] - pose[:, 12, :2], axis=-1)
    shoulder_center = (pose[:, 11, :2] + pose[:, 12, :2]) * 0.5
    nose_scale = np.linalg.norm(pose[:, 0, :2] - shoulder_center, axis=-1)
    primary = nose_pair & np.isfinite(nose_scale) & (nose_scale > 1e-4)
    shoulder_fallback = shoulder_pair & np.isfinite(shoulder_width) & (shoulder_width > 1e-4)
    one_shoulder = valid["nose"] & (valid["left_shoulder"] ^ valid["right_shoulder"])
    one_shoulder_ix = np.where(valid["left_shoulder"], 11, 12)
    one_shoulder_scale = np.linalg.norm(pose[np.arange(len(pose)), one_shoulder_ix, :2] - pose[:, 0, :2], axis=-1)
    one_shoulder &= np.isfinite(one_shoulder_scale) & (one_shoulder_scale > 1e-4)
    hip_pair = valid["left_hip"] & valid["right_hip"]
    hip_width = np.linalg.norm(pose[:, 23, :2] - pose[:, 24, :2], axis=-1)
    hip_fallback = hip_pair & np.isfinite(hip_width) & (hip_width > 1e-4)

    for mode, mask in (
        ("primary_nose_shoulders", primary),
        ("shoulder_width_fallback", shoulder_fallback & ~primary),
        ("nose_one_shoulder_fallback", one_shoulder & ~primary & ~shoulder_fallback),
        ("hip_width_fallback", hip_fallback & ~primary & ~shoulder_fallback & ~one_shoulder),
    ):
        anchor_counts[mode] += int(mask.sum())
    any_anchor = primary | shoulder_fallback | one_shoulder | hip_fallback
    anchor_counts["no_valid_scale_anchor"] += int((~any_anchor).sum())

    primary_n = int(primary.sum())
    if primary_n < 2:
        record_stats = {
            "uid": str(record.get("uid", "?")),
            "raw_frame_count": record.get("raw_frame_count"),
            "primary_frames": primary_n,
            "shoulder_pair_frames": int(shoulder_pair.sum()),
            "nose_left_shoulder_frames": int((valid["nose"] & valid["left_shoulder"]).sum()),
            "nose_right_shoulder_frames": int((valid["nose"] & valid["right_shoulder"]).sum()),
            "hip_pair_frames": int(hip_pair.sum()),
            "finite_anchor_coords": {name: int(finite[:, idx].sum()) for name, idx in anchor_indices.items()},
            "confidence_max": {name: float(confidence[:, idx].max()) for name, idx in anchor_indices.items()},
            "confidence_mean": {name: float(confidence[:, idx].mean()) for name, idx in anchor_indices.items()},
        }
        diagnostic_rows.append(record_stats)

print("V3 anchor confidence audit; threshold=0.15; frame counts sum across 2,046 cached clips:", anchor_counts)
print("Clips failing the original >=2 primary-frame gate:", len(diagnostic_rows))
for diagnostic in diagnostic_rows[:20]:
    print(diagnostic)
